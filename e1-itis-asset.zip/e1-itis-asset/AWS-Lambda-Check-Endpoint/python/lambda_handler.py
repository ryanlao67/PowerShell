def lambda_handler(event, context):
    from LambdaCWWriter import LambdaCWWriter
    lc = LambdaCWWriter()
    return lc.send_all_metrics_values()