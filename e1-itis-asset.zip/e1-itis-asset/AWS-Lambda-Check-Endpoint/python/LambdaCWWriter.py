# -*- encoding:utf-8 -*-
# LambdaCWWriter.py
# Using for calling the metrics data generation and post to CW endpoint
#
# ver-0.0.1, 2017/04/25, Author: bob.yeh@ef.com
# First init.
# ver-0.0.2, 2017/04/25, Author: bob.yeh@ef.com
# change from local to s3 bucket configuration files, easier to manage

import boto3
import requests
import json
#from multiprocessing import Process, Lock

_timeout = 6
_r_sg = 'ap-southeast-1'
_s3_bucket = 'e1-lambda-configs'
_config = 'lambda-endpoint-health-check-config.json'
_json_url = 'https://s3-ap-southeast-1.amazonaws.com/e1-lambda-configs/lambda-endpoint-health-check-config.json'

class LambdaCWWriter(object):

    CW_NAMESPACE = "APIEndpointHealthChecker"

    def __init__(self):
        region = _r_sg
        self.cw = boto3.client('cloudwatch',region_name=_r_sg)

    def send_metrics(self, metrics_data):
        if metrics_data is not None:
            self.cw.put_metric_data(Namespace=self.CW_NAMESPACE, MetricData=metrics_data)
        
    def send_all_metrics_values(self):
        #lock = Lock()
        items = self.get_config_from_s3()
        for item in items:
            #Process(target=self.request_endpoint_parallel, args=(lock, item)).start()
            self.request_endpoint_parallel(None, item)
        return True

    def request_endpoint_parallel(self, lock, item):
        #lock.acquire()
        try:
            rets = self.request_endpoint_metrics(item)
            if rets is not None:
                self.send_metrics(rets)
        finally:
            #lock.release()
            pass

    def request_endpoint_metrics(self, item):
        ret = None
        if item is not None and "product" in item and "url" in item:
            dimensions = [{ "Name":"product","Value":item["product"]},
                          { "Name":"url"   ,"Value":item["url"]}]
            headers = None
            body = None
            if "headers" in item:
                headers = item["headers"]
            if "body" in item:
                body = item["body"]
            res = self.request_item(url=item["url"], method=item["method"], headers=headers, body=body)
            ret = [{"Dimensions" : dimensions,
		       "MetricName": "status_code",
                       "Value" : res["status_code"],
                       "Unit": "None"},
		    {"Dimensions" : dimensions,
                       "MetricName": "latency",
                       "Value" : res["latency"],
                       "Unit": "Milliseconds"}
		  ]
        return ret

    def request_item(self, url, method, timeout=_timeout, headers=None, body=None):
        ret = None
        status_code = 0
        latency = 0
        if url is None:
            return ret
        if method is None:
            return ret
        if method == 'POST':
            res = self.request_post_item(url=url,headers=headers,body=body, timeout=timeout)
        elif method == 'GET':
            res = self.request_get_item(url=url,headers=headers, timeout=timeout)
        if res is not None:
            status_code = res.status_code
            latency = res.elapsed.microseconds/1000
        return {'status_code': status_code,
                'latency': latency}

    def request_get_item(self, url, headers=None, timeout=_timeout):
        ret = None
        if url is None:
            return ret
        try:
            ret = requests.get(url, headers=headers, timeout=timeout)
        except Exception as e:
            print e
            pass
        return ret

    def request_post_item(self, url, body, headers=None, timeout=_timeout):
        ret = None
        if url is None:
            return ret
        try:
            ret = requests.post(url, headers=headers, data=json.JSONEncoder().encode(body), timeout=timeout)
        except Exception as e:
            print e
            pass
        return ret

    def get_config_from_file(self):
        content = None
        with open(_config) as fp:
            content = fp.read()
        return self.parse_to_items(content)


    def get_config_from_url(self):
        content = requests.get(_json_url)._content
        return self.parse_to_items(content)


    def get_config_from_s3(self):
        s3_conn = boto3.client('s3')
        obj = s3_conn.get_object(Bucket=_s3_bucket,Key=_config)
        return self.parse_to_items(obj['Body'].read())

    def parse_to_items(self, content):
        items = None
        items_json = None

        try:
            items_json = json.JSONDecoder().decode(content)        
        except:
            print "parse JSON Failed:{}".format(content)
            pass

        if items_json is not None and "items" in items_json:
            items = items_json["items"]
        return items

