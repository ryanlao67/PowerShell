import LambdaCWWriter

if __name__  == "__main__":
    lc = LambdaCWWriter.LambdaCWWriter()
    lc.send_all_metrics_values()

