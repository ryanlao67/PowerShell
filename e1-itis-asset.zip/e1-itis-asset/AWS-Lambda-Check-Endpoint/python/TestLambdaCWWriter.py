# -*- encoding:utf-8 -*-
# CustomizedCWItems.py
# Using for calling the metrics data generation and post to CW endpoint
#
# ver-0.0.1, 2017/03/29, Author: bob.yeh@ef.com
# First init.
import unittest
from mock import MagicMock, patch, Mock
from LambdaCWWriter import LambdaCWWriter

class TestLambdaCWWriter(unittest.TestCase):

    CW_NAMESPACE = "APIEndpointHealthChecker"

    def test_send_metrics(self):
        self.lc = LambdaCWWriter()
        self.lc.connection.put_metric_data = MagicMock(return_value=True)
        dimensions = Mock() 
        metrics = Mock()
        self.lc.send_metrics(dimensions=dimensions,metrics=metrics)
        self.lc.connection.put_metric_data.assert_called_once()

    def test_send_all_metrics_values(self):        
        self.lc = LambdaCWWriter()
        item = Mock()
        self.lc.get_endpoint_urls_from_s3 = MagicMock(return_value=[item,item])
        self.lc.request_endpoint_metrics = MagicMock()
        self.lc.send_metrics = MagicMock()
        self.assertTrue(self.lc.send_all_metrics_values())

    def test_request_endpoint_metrics(self):
        self.lc = LambdaCWWriter()
        item = {"product":"aaa","url":"url","method":"method","headers":"headers","body":"body"}
        self.lc.request_item = MagicMock(return_value=Mock())
        self.assertIsNotNone(self.lc.request_endpoint_metrics(item))
        self.assertIsNone(self.lc.request_endpoint_metrics(None))

    def test_request_item(self):
        self.lc = LambdaCWWriter()
        res = Mock()
        res.status_code = 0
        res.elapsed = Mock()
        res.elapsed.microseconds = 0

        self.assertIsNone(self.lc.request_item(url=None, method=None))
        self.assertIsNone(self.lc.request_item(url="https://www.google.com/", method=None))

        self.lc.request_get_item = MagicMock(return_value=None)
        self.assertIsNotNone(self.lc.request_item(url="aaa",method="GET"))
        self.assertEqual(self.lc.request_item(url="aaa",method="GET")['status_code'],0)
        self.assertEqual(self.lc.request_item(url="aaa",method="GET")['latency'],0)

        self.lc.request_get_item = MagicMock(return_value=res)
        self.assertIsNotNone(self.lc.request_item(url="aaa",method="GET"))
        self.assertEqual(self.lc.request_item(url="aaa",method="GET")['status_code'],0)
        res.elapsed.microseconds = 15000
        self.lc.request_get_item = MagicMock(return_value=res)
        self.assertEqual(self.lc.request_item(url="aaa",method="GET")['latency'],15)

        self.lc.request_post_item = MagicMock(return_value=None)
        self.assertIsNotNone(self.lc.request_item(url="aaa",method="POST"))
        res.status_code = 200
        res.elapsed.microseconds = 18000
        self.lc.request_get_item = MagicMock(return_value=res)
        self.assertIsNotNone(self.lc.request_item(url="aaa",method="POST"))
        self.assertEqual(self.lc.request_item(url="aaa",method="GET")['status_code'],200)
        self.assertEqual(self.lc.request_item(url="aaa",method="GET")['latency'],18)

    def test_request_get_item(self):
        with patch("LambdaCWWriter.requests.get") as rget:
            rget = MagicMock(return_value=Mock())
            self.lc = LambdaCWWriter()
            self.assertIsNone(self.lc.request_get_item(url=None))
            self.assertIsNotNone(self.lc.request_get_item(url="abc"))
            self.assertIsNotNone(self.lc.request_get_item(url="abc",headers="def"))

    def test_request_post_item(self):
        with patch("LambdaCWWriter.requests.post") as rpost:
            rpost = MagicMock(return_value=Mock())
            self.lc = LambdaCWWriter()
            self.assertIsNone(self.lc.request_post_item(url=None,body=None))
            self.assertIsNotNone(self.lc.request_post_item(url="abc",body="def"))
            self.assertIsNotNone(self.lc.request_post_item(url="abc",body="def",headers="ijk"))

    def test_parse_to_items(self):
        self.lc = LambdaCWWriter()
        self.assertIsNotNone(self.lc.parse_to_items('{"items":"1234"}'))
        self.assertIsNone(self.lc.parse_to_items(''))

    def test_get_config_from_file(self):
        self.lc = LambdaCWWriter()
        self.assertIsNotNone(self.lc.get_config_from_file())

    def test_get_config_from_url(self):
        with patch("LambdaCWWriter.requests.get") as rget:
            rget = MagicMock(return_value=Mock())
            self.lc = LambdaCWWriter()
            self.lc.parse_to_items = MagicMock(return_value=None)
            self.assertIsNone(self.lc.get_config_from_url())
            self.lc.parse_to_items = MagicMock(return_value=Mock())
            self.assertIsNotNone(self.lc.get_config_from_url())
    
    def test_get_config_from_s3(self):
        with patch("LambdaCWWriter.boto.s3.connect_to_region") as bsc:
            bsc.get_bucket = MagicMock(return_value=Mock())
            bsc.get_bucket.get_key = MagicMock(return_value=Mock())
            bsc.get_bucket.get_key.get_contents_as_string = MagicMock(return_value=Mock)
            self.lc = LambdaCWWriter()
            self.lc.parse_to_items = MagicMock(return_value=Mock())
            self.assertIsNotNone(self.lc.get_config_from_s3())
            self.lc.parse_to_items.assert_called_once()

