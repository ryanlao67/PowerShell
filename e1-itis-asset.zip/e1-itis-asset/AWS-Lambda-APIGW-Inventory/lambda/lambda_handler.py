from __future__ import print_function

import boto3
import json
import re

print('Loading function')
ec2 = boto3.client('ec2', region_name='ap-southeast-1')

def respond(err, res=None):
    return {
        'statusCode': '400' if err else '200',
        'body': err.message if err else json.dumps(res),
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        },
    }

def lambda_handler(event, context):
    all_ec2 = ec2.describe_instances()
    new_ec2 = all_ec2['Reservations']
    new_ec2 = []
    for node in all_ec2['Reservations']:
        new_node = {}
        fn = node['Instances'][0]
        for k in fn.keys():
            if type(fn[k]) == str:
                new_node[k] = fn[k]
        for k in fn['Tags']:
            new_node[unicode(k['Key'])] = k['Value']
        new_node[u'AZ'] = fn['Placement']['AvailabilityZone']
        new_node[u'State'] = fn['State']['Name']
        new_node["Subnet"] = get_priip_net(fn['PrivateIpAddress'])
        new_ec2.append(new_node)
    operation = event['httpMethod']
    if event['httpMethod'] in ['GET']:
        return respond(None, new_ec2)
    else:
        return respond(ValueError('Unsupported method "{}"'.format(operation)))

def get_priip_net(private_ip):
    pt = re.compile("\d+\.\d+\.(\d+)\.\d")
    subnet = pt.findall(private_ip)
    ret = "Private"
    print(subnet)
    if len(subnet) == 1 and subnet[0] in ["130", "131", "114", "115"]:
        ret = "Public"
    return ret
