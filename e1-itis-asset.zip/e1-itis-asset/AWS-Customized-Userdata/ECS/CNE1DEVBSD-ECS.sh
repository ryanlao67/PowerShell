#!/bin/bash
echo ECS_CLUSTER=CNE1DEVBSD-ECS-CLUSTER >> /etc/ecs/ecs.config
yum -y install aws-cli && mkdir /opt/app-certs/efpv2 -p
aws s3 cp s3://efpv2-certs-staging/ /opt/app-certs/efpv2/ --recursive --region cn-north-1