# -*- encoding:utf-8 -*-
import requests

if __name__ == "__main__":
	ngx_health = requests.get("http://e1athena-staging.ef.com/health")
	var_health = requests.get("http://e1athena-staging.ef.com/api/davinci.iwb")

	print "nginx service check: {}".format( ngx_health.status_code )
	print "varnish service check: {}".format(var_health.status_code )
	print "davinci data length: {}".format( len(var_health.content) )

	if ngx_health.status_code == 200 and var_health.status_code and len(var_health.content):
		print "service available"
		exit(0)
	else:
		exit(1)