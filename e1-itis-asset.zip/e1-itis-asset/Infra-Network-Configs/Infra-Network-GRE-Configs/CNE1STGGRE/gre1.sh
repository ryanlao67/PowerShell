
ip tunnel add gre1 mode gre remote 10.160.135.21 local 10.163.27.20
ip link set gre1 up mtu 1400
ip addr add 192.168.172.21 peer 192.168.172.22 dev gre1
ip route add 10.160.134.12/32 dev gre1
ip route add 10.96.16.0/20 dev gre1
ip route add 10.96.32.0/20 dev gre1
ip route add 10.96.48.0/20 dev gre1
ip route add 10.160.128.0/24 dev gre1
ip route add 10.160.129.0/24 dev gre1
ip route add 10.160.130.0/24 dev gre1
ip route add 10.160.131.0/24 dev gre1
ip route add 10.160.132.0/24 dev gre1
ip route add 10.160.133.0/24 dev gre1
ip route add 10.160.134.0/24 dev gre1
ip route add 10.160.135.7/32 dev gre1


