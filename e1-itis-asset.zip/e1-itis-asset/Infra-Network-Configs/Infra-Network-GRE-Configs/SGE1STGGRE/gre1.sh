
ip tunnel add gre1 mode gre remote 10.163.27.20 local 10.160.135.21
ip link set gre1 up mtu 1400
ip addr add 192.168.172.22 peer 192.168.172.21 dev gre1
ip route add 10.163.24.0/24 dev gre1
ip route add 10.163.25.0/24 dev gre1
ip route add 10.163.26.0/24 dev gre1
ip route add 10.163.28.0/24 dev gre1
ip route add 10.163.29.0/24 dev gre1
ip route add 10.163.30.0/24 dev gre1
ip route add 10.17.0.0/16 dev gre1
ip route add 10.128.32.0/19 dev gre1
ip route add 192.168.64.0/23 dev gre1
