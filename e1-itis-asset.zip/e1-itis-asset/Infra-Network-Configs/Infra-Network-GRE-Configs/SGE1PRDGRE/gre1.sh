
#!/bin/sh
ip tunnel add gre1 mode gre remote 10.163.11.20 local 10.160.119.13 ttl 255
ip link set gre1 up mtu 1400
ip addr add 192.168.178.22 peer 192.168.178.21 dev gre1
ip route add 10.17.0.1/32 dev gre1
ip route add 10.163.8.0/24 dev gre1
ip route add 10.163.9.0/24 dev gre1
ip route add 10.163.10.0/24 dev gre1
ip route add 10.163.12.0/24 dev gre1
ip route add 10.163.13.0/24 dev gre1
ip route add 10.163.14.0/24 dev gre1
ip route add 10.163.15.0/24 dev gre1
ip route add 10.17.0.0/16 dev gre1
ip route add 192.168.64.0/23 dev gre1
ip route add 10.128.32.0/19 dev gre1
