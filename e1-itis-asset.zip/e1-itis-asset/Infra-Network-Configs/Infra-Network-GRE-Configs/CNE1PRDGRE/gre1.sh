
#!/bin/sh
ip tunnel add gre1 mode gre remote 10.160.119.13 local 10.163.11.20 ttl 255
ip link set gre1 up mtu 1400
ip addr add 192.168.178.21 peer 192.168.178.22 dev gre1
ip route add 10.160.119.40/32 dev gre1
ip route add 10.160.112.0/24 dev gre1
ip route add 10.160.113.0/24 dev gre1
ip route add 10.160.114.0/24 dev gre1
ip route add 10.160.115.0/24 dev gre1
ip route add 10.160.116.0/24 dev gre1
ip route add 10.160.117.0/24 dev gre1
ip route add 10.160.118.0/24 dev gre1
ip route add 10.96.16.0/20 dev gre1
ip route add 10.96.32.0/20 dev gre1
ip route add 10.96.48.0/20 dev gre1
ip route add 10.160.119.22/32 dev gre1
