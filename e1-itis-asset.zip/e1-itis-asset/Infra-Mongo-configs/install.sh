sudo apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv 0C49F3730359A14518585931BC711F9BA15703C6
echo "deb [ arch=amd64 ] http://repo.mongodb.org/apt/ubuntu trusty/mongodb-org/3.4 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-3.4.list
sudo apt-get update
sudo apt-get install -y mongodb-org

sudo mkdir /opt/mongodb

# do extra work if you want to put /opt/mongodb onto single drive
# sudo fdisk /dev/xvdb
# sudo mkfs.ext4 /dev/xvdb1
# echo /dev/xvdb1 /opt/mongodb ext4 defaults,discard 0 0 >> /etc/fstab
# sudo mount -a

sudo service mongod start