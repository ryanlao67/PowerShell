#/bin/sh
sudo /etc/init.d/collectd stop
sudo cp collectd-curl-aem-stg.conf /etc/collectd/collectd.conf.d/
sudo cat whitelist.aem-stg.conf >> /opt/collectd-plugins/cloudwatch/config/whitelist.conf
sudo /etc/init.d/collectd start
