#/bin/sh
sudo /etc/init.d/collectd stop
sudo cp processes-squid.conf /etc/collectd/collectd.conf.d/
sudo cat whitelist.squid.conf >> /opt/collectd-plugins/cloudwatch/config/whitelist.conf
sudo /etc/init.d/collectd start
