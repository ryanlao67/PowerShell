#/bin/sh
sudo apt-get update
sudo apt-get install -y collectd
sudo python ./setup.py
sudo cp collectd-cloudwatch.conf /etc/collectd/collectd.conf.d/
sudo cp collectd.conf.proxy /etc/collectd/collectd.conf
sudo cp processes-squid.conf /etc/collectd/collectd.conf.d/
sudo cp whitelist.conf /opt/collectd-plugins/cloudwatch/config/
sudo /etc/init.d/collectd restart
