#/bin/sh
sudo /etc/init.d/nginx stop
sudo cp nginx-status-conf /etc/nginx/sites-enabled/
sudo /etc/init.d/nginx start
sudo /etc/init.d/collectd stop
sudo cp collectd.nginx.conf /etc/collectd/collectd.conf.d/
sudo cp processes-nginx.conf /etc/collectd/collectd.conf.d/
sudo cat whitelist.nginx.conf >> /opt/collectd-plugins/cloudwatch/config/whitelist.conf
sudo /etc/init.d/collectd start
