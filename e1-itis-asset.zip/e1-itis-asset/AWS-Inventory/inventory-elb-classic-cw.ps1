$awsRegions = Get-AWSRegion -IncludeChina

$elbXlu = @("SGE1PRDPSSZDK-W-ELB","SGE1PRDPSSZDK-INT-ELB","CNE1PRDPSSZDK-INT-ELB","CNE1PRDPSSZDK-W-ELB")

$htmlTickGreen = "<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>"
$htmlCloseRed = "<td align=center valign=middle><img src=close_red.png height=20 width=20/></td>"

Foreach($awsRegion in $awsRegions)
{
    $awsProfile = "awsgbl"
    If($awsRegion.Region.StartsWith("ap-southeast-1"))
    {
        $topicARN = "arn:aws:sns:ap-southeast-1:415204155249:OPSGENIE_AWS"    
    }
    Elseif($awsRegion.Region.StartsWith("cn-"))
    {
        $awsProfile = "awscn"
        $topicARN = "arn:aws-cn:sns:cn-north-1:014301917773:OPSGENIE_AWS"
    }
    Elseif($awsRegion.Region.StartsWith("eu-west-1"))
    {
        $topicARN = "arn:aws:sns:eu-west-1:415204155249:OPSGENIE_AWS"
    }
    Else
    {
        Continue
    }

    $cwAlarms = Get-CWAlarm -ProfileName $awsProfile -Region $awsRegion.Region
    $elbAlarms = ($alarms | Where {$_.Namespace -eq "AWS/ELB"})

    $dimension = New-Object Amazon.CloudWatch.Model.Dimension
    $dimension.set_Name("LoadBalancerName")
    
    $htmlLine = ""
    $elbs = Get-ELBLoadBalancer -ProfileName $awsProfile -Region $awsRegion.Region
    
    Foreach($elb in $elbs)
    {
        $elbName = $elb.LoadBalancerName
        $healthHostCount = 0
        $instanceHealth = Get-ELBInstanceHealth -LoadBalancerName $elb.LoadBalancerName `
            -ProfileName $awsProfile `
            -Region $awsRegion.Region
        Foreach($health in $instanceHealth)
        {
            If ($health.State -eq "InService")
            {
                $healthHostCount += 1
            }
        }
        If($healthHostCount -ne $instanceHealth.Count)
        {
            $htmlLine = $("<tr><td colspan=2><img src=stopped.png height=16 width=16>" + $healthHostCount.ToString() + " out of " + $instanceHealth.Count.ToString() + " healthy</td>")
        }
        Else
        {
            $htmlLine = $("<tr><td colspan=2><img src=running.png height=16 width=16>" + $healthHostCount.ToString() + " out of " + $instanceHealth.Count.ToString() + " healthy</td>")
        }
        $htmlLine = $($htmlLine + "<td>" + $elb.DNSName + "</td>")
        $htmlLine = $($htmlLine + "<td>" + $elb.Scheme + "</td>")

        ### Get CloudWatch alarms about ELB ###
        $elbWRNHighLatency = ($elbAlarms | Where {$_.AlarmName -match $("\[Warning\]\["+$tagTEAM+"\] High-ELB-Latency \(" + $elbName +"\)")})
        $elbCRIZeroHealthyHosts = ($elbAlarms | Where {$_.AlarmName -match $("\[High\]\["+$tagTEAM+"\] ELB-Zero-Healthy-Hosts \(" + $elbName +"\)")})
        $elbWRNUnHealthyHosts = ($elbAlarms | Where {$_.AlarmName -match $("\[Warning\]\["+$tagTEAM+"\] ELB-UnHealthy-Hosts \(" + $elbName +"\)")})
        $elbCRIHighQueueLength = ($elbAlarms | Where {$_.AlarmName -match $("\[High\]\["+$tagTEAM+"\] ELB-High-Queue-Length \(" + $elbName +"\)")})
        $elbWRNHighQueueLength = ($elbAlarms | Where {$_.AlarmName -like $("\[Warning\]\["+$tagTEAM+"\] ELB-High-Queue-Length \(" + $elbName +"\)")})
        $elbCRIMaxQueueLengthReached = ($elbAlarms | Where {$_.AlarmName -match $("\[High\]\["+$tagTEAM+"\] ELB-Max-Queue-Length-Reached \(" + $elbName +"\)")})
        $elbWRNRequestsFailing = ($elbAlarms | Where {$_.AlarmName -match $("\[Warning\]\["+$tagTEAM+"\] ELB-Requests-Failing \(" + $elbName +"\)")})
        $elbCRIRequestsFailing = ($elbAlarms | Where {$_.AlarmName -match $("\[High\]\["+$tagTEAM+"\] ELB-Requests-Failing \(" + $elbName +"\)")})
        ### End ###

        $dimension.set_Value($elb.LoadBalancerName)

        $tagENV = ""
        $tagTEAM = ""
        $tagSUBTEAM = ""
        $tagKeys = @("ENV", "SUBTEAM", "TEAM")
        $tags = ((Get-ELBTags -LoadBalancerName $elbName -ProfileName $awsProfile -Region $awsRegion.Region).Tags |`
            Where {$_.Key -in $tagKeys})
        If($tags.Count -ge 2)
        {
            $tags = $tags | Sort-Object @{Expression={$_.Key}; Ascending=$true}
            $tagENV = $tags[0].Value
            If($tags.Count -eq 3)
            {
                $tagSUBTEAM = $tags[1].Value
                $tagTEAM = $tags[2].Value
            }
            Else
            {
                $tagTEAM = $tags[1].Value
            }
        }
        If($tagTEAM -ne "BI" -and $tagTEAM -ne "BSD" -and $tagTEAM -ne "GDM" -and $tagTEAM -ne "PD" -and $tagTEAM -ne "SF")
        {
            $tagTEAM = "ITIS"
        }

        If($tagSUBTEAM)
        {
            $cwTopicARN = New-SNSTopic -Name $("E1" + $tagSUBTEAM) -ProfileName $awsProfile -Region $awsRegion.Region
            $alarmPrefixTeam = $tagSUBTEAM.Replace("_","-")
            If($tagSUBTEAM -eq "BSD_LEARNING" -or $tagSUBTEAM -eq "BSD_ODIN")
            {
                $alarmPrefixTeam = "BSD-OMNI"
            }
            Elseif($tagSUBTEAM -eq "BSD_FOUNDATION" -or $tagSUBTEAM -eq "BSD_EFP")
            {
                $alarmPrefixTeam ="BSD-SHS"
            }
        }
        Else
        {
            $cwTopicARN = New-SNSTopic -Name $("E1" + $tagTEAM + "_App_Alert") -ProfileName $awsProfile -Region $awsRegion.Region
            $alarmPrefixTeam = $tagTEAM
        }

        ### Check if high latency warning alert exists ###
        If($elbWRNHighLatency.Count -eq 0)
        {
            If($elb.CreatedTime -lt (Get-Date).AddDays(-15) -and $tagENV -eq "PRD" -and $elbXlu.Contains($elbName) -eq $False)
            {
                $latencyLimit = 3.0
                If($tagTEAM -eq "PD")
                {
                    $latencyLimit = 6.0
                }
                Elseif($elbName -eq "SGE1PRDBIRS01-ELB")
                {
                    $latencyLimit = 15.0
                }
                Write-CWMetricAlarm -AlarmName $("[Warning]["+$tagTEAM+"] High-ELB-Latency (" + $elbName + ")") `
                    -AlarmDescription "Created by AWS PowerShell" `
                    -Namespace "AWS/ELB" `
                    -MetricName Latency `
                    -Dimension $dimension `
                    -AlarmActions $cwTopicARN
                    -ComparisonOperator GreaterThanOrEqualToThreshold `
                    -EvaluationPeriods 6 `
                    -Period 300 `
                    -Statistic Average `
                    -Threshold $latencyLimit `
                    -ProfileName $awsProfile `
                    -Region $awsRegion.Region
                $htmlLine = $($htmlLine + $htmlTickGreen)
            }
            Else
            {
                $htmlLine = $($htmlLine + $htmlCloseRed)
            }
        Else
        {
            $htmlLine = $($htmlLine + $htmlTickGreen)
        }

        ### Check if zero healthy hosts critical alert exists ###
        If($elbCRIZeroHealthyHosts.Count -eq 0)
        {
            If($elb.CreatedTime -lt (Get-Date).AddDays(-15) -and $tagENV -eq "PRD" -and $elbXlu.Contains($elbName) -eq $False)
            {
                Write-CWMetricAlarm -AlarmName $("[High]["+$alarmPrefixTeam+"] ELB-Zero-Healthy-Hosts (" + $elbName + ")") `
                    -AlarmDescription "Created by AWS PowerShell" `
                    -Namespace "AWS/ELB" `
                    -MetricName HealthyHostCount `
                    -Dimension $dimension `
                    -AlarmActions $topicARN
                    -ComparisonOperator LessThanOrEqualToThreshold `
                    -EvaluationPeriods 3 `
                    -Period 60 `
                    -Statistic Average `
                    -Threshold 0 `
                    -ProfileName $awsProfile `
                    -Region $awsRegion.Region
                $htmlLine = $($htmlLine + $htmlTickGreen)
            }
            Else
            {
                $htmlLine = $($htmlLine + $htmlCloseRed)
            }
        }
        Else
        {
            $htmlLine = $($htmlLine + $htmlTickGreen)
        }

        ### Check if unhealthy hosts warning alert exists ###
        If($elbWRNUnHealthyHosts.Count -eq 0)
        {
            If($elb.CreatedTime -lt (Get-Date).AddDays(-15) -and $tagENV -eq "PRD" -and $elbXlu.Contains($elbName) -eq $False)
            {
                Write-CWMetricAlarm -AlarmName $("[Warning]["+$tagTEAM+"] ELB-UnHealthy-Hosts (" + $elbName + ")") `
                    -AlarmDescription "Created by AWS PowerShell" `
                    -Namespace "AWS/ELB" `
                    -MetricName UnHealthyHostCount `
                    -Dimension $dimension `
                    -AlarmActions $cwTopicARN
                    -ComparisonOperator GreaterThanOrEqualToThreshold `
                    -EvaluationPeriods 3 `
                    -Period 300 `
                    -Statistic Average `
                    -Threshold 1 `
                    -ProfileName $awsProfile `
                    -Region $awsRegion.Region
                $htmlLine = $($htmlLine + $htmlTickGreen)
            }
            Else
            {
                $htmlLine = $($htmlLine + $htmlCloseRed)
            }
        }
        Else
        {
            $htmlLine = $($htmlLine + $htmlTickGreen)
        }

        ### Check if high queue length critical alert exists ###
        If($elbCRIHighQueueLength.Count -eq 0)
        {
            If($elb.CreatedTime -lt (Get-Date).AddDays(-15) -and $tagENV -eq "PRD" -and $elbXlu.Contains($elbName) -eq $False)
            {
                Write-CWMetricAlarm -AlarmName $("[High]["+$alarmPrefixTeam+"] ELB-High-Queue-Length (" + $elbName + ")") `
                    -AlarmDescription "Created by AWS PowerShell" `
                    -Namespace "AWS/ELB" `
                    -MetricName SurgeQueueLength `
                    -Dimension $dimension `
                    -AlarmActions $topicARN
                    -ComparisonOperator GreaterThanOrEqualToThreshold `
                    -EvaluationPeriods 3 `
                    -Period 300 `
                    -Statistic Average `
                    -Threshold 20 `
                    -ProfileName $awsProfile `
                    -Region $awsRegion.Region
                $htmlLine = $($htmlLine + $htmlTickGreen)
            }
            Else
            {
                $htmlLine = $($htmlLine + $htmlCloseRed)
            }
        }
        Else
        {
            $htmlLine = $($htmlLine + $htmlTickGreen)
        }

        ### Check if high queue length warning alert exists ###
        If($elbWRNHighQueueLength.Count -eq 0)
        {
            If($elb.CreatedTime -lt (Get-Date).AddDays(-15) -and $tagENV -eq "PRD" -and $elbXlu.Contains($elbName) -eq $False)
            {
                Write-CWMetricAlarm -AlarmName $("[Warning]["+$tagTEAM+"] ELB-High-Queue-Length (" + $elbName + ")") `
                    -AlarmDescription "Created by AWS PowerShell" `
                    -Namespace "AWS/ELB" `
                    -MetricName SurgeQueueLength `
                    -Dimension $dimension `
                    -AlarmActions $cwTopicARN
                    -ComparisonOperator GreaterThanOrEqualToThreshold `
                    -EvaluationPeriods 2 `
                    -Period 300 `
                    -Statistic Average `
                    -Threshold 10 `
                    -ProfileName $awsProfile `
                    -Region $awsRegion.Region
                $htmlLine = $($htmlLine + $htmlTickGreen)
            }
            Else
            {
                $htmlLine = $($htmlLine + $htmlCloseRed)
            }
        }
        Else
        {
            $htmlLine = $($htmlLine + $htmlTickGreen)
        }

        ### Check if max queue length reached critical alert exists ###
        If($elbCRIMaxQueueLengthReached.Count -eq 0)
        {
            If($elb.CreatedTime -lt (Get-Date).AddDays(-15) -and $tagENV -eq "PRD" -and $elbXlu.Contains($elbName) -eq $False)
            {
                Write-CWMetricAlarm -AlarmName $("[High]["+$alarmPrefixTeam+"] ELB-Max-Queue-Length-Reached (" + $elbName + ")") `
                    -AlarmDescription "Created by AWS PowerShell" `
                    -Namespace "AWS/ELB" `
                    -MetricName SpilloverCount `
                    -Dimension $dimension `
                    -AlarmActions $topicARN
                    -ComparisonOperator GreaterThanOrEqualToThreshold `
                    -EvaluationPeriods 3 `
                    -Period 60 `
                    -Statistic Sum `
                    -Threshold 1 `
                    -ProfileName $awsProfile `
                    -Region $awsRegion.Region
                $htmlLine = $($htmlLine + $htmlTickGreen)
            }
            Else
            {
                $htmlLine = $($htmlLine + $htmlCloseRed)
            }
        }
        Else
        {
            $htmlLine = $($htmlLine + $htmlTickGreen)
        }

        ### Check if faied request warning alert exists ###
        If($elbWRNRequestsFailing.Count -eq 0)
        {
            If($elb.CreatedTime -lt (Get-Date).AddDays(-15) -and $tagENV -eq "PRD" -and $elbXlu.Contains($elbName) -eq $False)
            {
                $faileRequestLimit = 7
                If($elbName -eq "SGE1PRDBIRS01-ELB" -or $elbName -eq "SGE1PRDODIN-BGS-ELB-INT")
                {
                    $faileRequestLimit = 25.0
                }
                Write-CWMetricAlarm -AlarmName $("[Warning]["+$tagTEAM+"] ELB-Requests-Failing (" + $elbName + ")") `
                    -AlarmDescription "Created by AWS PowerShell" `
                    -Namespace "AWS/ELB" `
                    -MetricName HTTPCode_ELB_5XX `
                    -Dimension $dimension `
                    -AlarmActions $cwTopicARN
                    -ComparisonOperator GreaterThanOrEqualToThreshold `
                    -EvaluationPeriods 3 `
                    -Period 60 `
                    -Statistic Sum `
                    -Threshold $faileRequestLimit `
                    -ProfileName $awsProfile `
                    -Region $awsRegion.Region
                $htmlLine = $($htmlLine + $htmlTickGreen)
            }
            Else
            {
                $htmlLine = $($htmlLine + $htmlCloseRed)
            }
        }
        Else
        {
            $htmlLine = $($htmlLine + $htmlTickGreen)
        }

        ### Check if faied request critical alert exists ###
        If($elbCRIRequestsFailing.Count -eq 0)
        {
            If($elb.CreatedTime -lt (Get-Date).AddDays(-15) -and $tagENV -eq "PRD" -and $elbXlu.Contains($elbName) -eq $False)
            {
                $faileRequestLimit = 50
                Write-CWMetricAlarm -AlarmName $("[High]["+$alarmPrefixTeam+"] ELB-Requests-Failing (" + $elbName + ")") `
                    -AlarmDescription "Created by AWS PowerShell" `
                    -Namespace "AWS/ELB" `
                    -MetricName HTTPCode_ELB_5XX `
                    -Dimension $dimension `
                    -AlarmActions $topicARN
                    -ComparisonOperator GreaterThanOrEqualToThreshold `
                    -EvaluationPeriods 3 `
                    -Period 60 `
                    -Statistic Sum `
                    -Threshold $faileRequestLimit `
                    -ProfileName $awsProfile `
                    -Region $awsRegion.Region
                $htmlLine = $($htmlLine + $htmlTickGreen)
            }
            Else
            {
                $htmlLine = $($htmlLine + $htmlCloseRed)
            }
        }
        Else
        {
            $htmlLine = $($htmlLine + $htmlTickGreen)
        }

        $tagKeys = @("ENV", "TEAM")
        $tags = (Get-ELBTags -LoadBalancerName $elbName -ProfileName $awsProfile -Region $awsRegion.Region).Tags |`
            Where {$_.Key -in $tagKeys}
        If($tags.Count -eq 2)
        {
            $tags = $tags | Sort-Object @{Expression={$_.Key}; Ascending=$true}
            If($tags[0].Value -eq "PRD")
            {
                If($tags[1].Value -eq "BI")
                {
                    $teamBI = $($teamBI + $htmlLine)
                }
                Elseif($tags[1].Value -eq "BSD")
                {
                    $teamBSD = $($teamBSD + $htmlLine)
                }
                Elseif($tags[1].Value -eq "GDM")
                {
                    $teamGDM = $($teamGDM + $htmlLine)
                }
                Elseif($tags[1].Value -eq "ITIS")
                {
                    $teamITIS = $($teamITIS + $htmlLine)
                }
                Elseif($tags[1].Value -eq "PD")
                {
                    $teamPD = $($teamPD + $htmlLine)
                }
                Elseif($tags[1].Value -eq "SF")
                {
                    $teamSF = $($teamSF + $htmlLine)
                }
                Else
                {
                    $teamNULL = $($teamNULL + $htmlLine)
                }
            }
        }
    }
}

$html = $("<html><body>Last Updated (UTC) - " + (Get-Date).ToUniversalTime() + "<table border=1 width=100%>")

$metricsColums = "<td><b>Warning-High-Latency</b></td> <td><b>Critical-Zero-Healthy-Hosts</b></td> <td><b>Warning-UnHealthy-Hosts</b></td> <td><b>Critical-High-Queue-Length</b></td> <td><b>Warning-High-Queue-Length</b></td> <td><b>Critical-Max-Queue-Length-Reached</b></td> <td><b>Warning-Requests-Failing</b></td> <td><b>Critical-Requests-Failing</b></td>"

If($teamNULL.Length -gt 0)
{
    $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM NULL</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>")
    $html =  $($html + $teamNULL + "<tr></tr>")
}
If($teamBI.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM BI</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>")
  $html =  $($html + $teamBI + "<tr></tr>")
}
If($teamBSD.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM BI</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>")
  $html =  $($html + $teamBSD + "<tr></tr>")
}
If($teamGDM.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM BI</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>")
  $html =  $($html + $teamGDM + "<tr></tr>")
}
If($teamITIS.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM BI</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>")
  $html =  $($html + $teamITIS + "<tr></tr>")
}
If($teamPD.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM BI</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>")
  $html =  $($html + $teamPD + "<tr></tr>")
}
If($teamSF.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM BI</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>")
  $html =  $($html + $teamSF + "<tr></tr>")
}
$html =  $($html + "</table></body></html>")

$html | Set-Content "D:\e1awsinventory\html\cw-elb.html"

#Write-S3Object -BucketName "e1aws-inventory.ef.com" `
#    -File "D:\e1awsinventory\html\cw-elb.html" `
#    -ProfileName awsgbl `
#    -Region ap-southeast-1


