$awsProfile = 'awsgbl'
$awsRegion = 'ap-southeast-1'
$inventoryBucket = 'e1aws-inventory.ef.com'

$archDate = (Get-Date).ToString("yyyyMMdd")
$archKey = 'ec2-' + $archDate + '.html'

aws s3 cp "s3://$inventoryBucket/ec2.html" "s3://$inventoryBucket/MonthlyArchive/$archKey" --profile $awsProfile | Out-Null