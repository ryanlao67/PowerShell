﻿$regions = Get-AWSRegion -IncludeChina
$teamNULL_PROD = "";
$teamBI_PROD = "";
$teamBSD_PROD = "";
$teamGDM_PROD = "";
$teamITIS_PROD = "";
$teamPD_PROD = "";
$teamSF_PROD = "";
 
$elbBlacklist = @("SGE1PRDPSSZDK-W-ELB","SGE1PRDPSSZDK-INT-ELB","CNE1PRDPSSZDK-INT-ELB","CNE1PRDPSSZDK-W-ELB")

foreach($region in $regions)
{
    echo $region.Region
    if($region.Region.StartsWith("ap-southeast-1"))
    {
      $profileName = "awsgbl";
      $topicARN = "arn:aws:sns:ap-southeast-1:415204155249:OPSGENIE_AWS"    
    }
    elseif($region.Region.StartsWith("cn-"))
    {
      $profileName = "awscn";
      $topicARN = "arn:aws-cn:sns:cn-north-1:014301917773:OPSGENIE_AWS"
    }
    elseif($region.Region.StartsWith('eu-west-1'))
    {
      $topicARN = "arn:aws:sns:eu-west-1:415204155249:OPSGENIE_AWS"
    }
    else
    {
        continue
    }

   $elbs = Get-ELBLoadBalancer -ProfileName $profileName -Region $region.Region
   
   $alarms = Get-CWAlarm -ProfileName $profileName -Region $region.Region
   $elbAlarms = ($alarms | Where-Object {$_.Namespace -eq "AWS/ELB"})

   $dimension1 = New-Object Amazon.CloudWatch.Model.Dimension
   $dimension1.set_Name("LoadBalancerName")

   $htmlLine = "";
   foreach($elb in $elbs)
   { 
    $healthHostCount = 0;
    $instanceHealth = (Get-ELBInstanceHealth -LoadBalancerName $elb.LoadBalancerName -ProfileName $profileName -Region $region.Region)
    foreach($health in $instanceHealth)
    {
	 if($health.State -eq “InService”)
     {
		$healthHostCount += 1;
	 }
    }

    if($healthHostCount -ne $instanceHealth.Count)
    {
	    $htmlLine = $(“<tr><td colspan=2><img src=stopped.png height=16 width=16>” + $healthHostCount.ToString() + “ out of ” + $instanceHealth.Count.ToString() + “ healthy</td>”);	
    }
    else
    {
	    $htmlLine = $(“<tr><td colspan=2><img src=running.png height=16 width=16>” + $healthHostCount.ToString() + “ out of ” + $instanceHealth.Count.ToString() + “ healthy</td>”);
    }

    $htmlLine = $($htmlLine + “<td>” + $elb.DNSName + ”</td>”);

    $htmlLine = $($htmlLine + “<td>” + $elb.Scheme + ”</td>”);

    $elbName = $elb.LoadBalancerName;

    $elbAlarmWarningHighLatency = ($elbAlarms | Where-Object {$_.AlarmName -match $("\[Warning\]\["+$team+"\] High-ELB-Latency \(" + $elbName +"\)")})
    $elbAlarmCriticalZeroHealthyHosts = ($elbAlarms | Where-Object {$_.AlarmName -match $("\[High\]\["+$team+"\] ELB-Zero-Healthy-Hosts \(" + $elbName +"\)")})
    $elbAlarmWarningUnHealthyHosts = ($elbAlarms | Where-Object {$_.AlarmName -match $("\[Warning\]\["+$team+"\] ELB-UnHealthy-Hosts \(" + $elbName +"\)")})
    $elbAlarmCriticalHighQueueLength = ($elbAlarms | Where-Object {$_.AlarmName -match $("\[High\]\["+$team+"\] ELB-High-Queue-Length \(" + $elbName +"\)")})
    $elbAlarmWarningHighQueueLength = ($elbAlarms | Where-Object {$_.AlarmName -like $("\[Warning\]\["+$team+"\] ELB-High-Queue-Length \(" + $elbName +"\)")})
    $elbAlarmCriticalMaxQueueLengthReached = ($elbAlarms | Where-Object {$_.AlarmName -match $("\[High\]\["+$team+"\] ELB-Max-Queue-Length-Reached \(" + $elbName +"\)")})
    $elbAlarmWarningRequestsFailing = ($elbAlarms | Where-Object {$_.AlarmName -match $("\[Warning\]\["+$team+"\] ELB-Requests-Failing \(" + $elbName +"\)")})
    $elbAlarmCriticalRequestsFailing = ($elbAlarms | Where-Object {$_.AlarmName -match $("\[High\]\["+$team+"\] ELB-Requests-Failing \(" + $elbName +"\)")})

    $dimension1.set_Value($elb.LoadBalancerName)

    $env = ""
    $team = ""
    $subteam = ""

    $tagKeys = @("ENV", "SUBTEAM", "TEAM");
    $tags = ((Get-ELBTags -LoadBalancerName $elb.LoadBalancerName -ProfileName $profileName -Region $region.Region).Tags | Where-Object {$_.Key -in $tagKeys})
    if($tags.Count -ge 2)
    {
       $tags = $tags | Sort-Object @{Expression={$_.Key}; Ascending=$true}
       $env = $tags[0].Value
       if($tags.Count -eq 3)
       {
          $subteam = $tags[1].Value
          $team = $tags[2].Value
       }
       else
       {
          $team = $tags[1].Value
       }
    }
    
    if($team -ne "BI" -and $team -ne "BSD" -and $team -ne "GDM" -and $team -ne "PD" -and $team -ne "SF")
    {
       $team = "ITIS"
    }

    if($subteam)
    {
        $CWtopicARN = New-SNSTopic -Name $("E1" + $subteam) -ProfileName $profileName -Region $region.Region
        $alarmPrefixTeam = $subteam.Replace("_","-")
        if($subteam -eq "BSD_LEARNING" -or $subteam -eq "BSD_ODIN")
        {
            $alarmPrefixTeam = "BSD-OMNI"
        }
        elseif($subteam -eq "BSD_FOUNDATION" -or $subteam -eq "BSD_EFP")
        {
            $alarmPrefixTeam ="BSD-SHS"
        }
    }
    else
    {
        $CWtopicARN = New-SNSTopic -Name $("E1" + $team + "_APP_AWS_Warning") -ProfileName $profileName -Region $region.Region
        $alarmPrefixTeam = $team
    }
    
    if($elbAlarmWarningHighLatency.Count -eq 0)
    {
        if($elb.CreatedTime -lt (Get-Date).AddDays(-15) -and $env -eq "PRD" -and $elbBlacklist.Contains($elb.LoadBalancerName) -eq $false)
        {
           $latencyLimit = 3.0
           if($team -eq "PD")
           {
            $latencyLimit = 6.0
           }
           elseif($elb.LoadBalancerName -eq "SGE1PRDBIRS01-ELB")
           {
            $latencyLimit = 15.0
           }
           Write-CWMetricAlarm -AlarmName $("[Warning]["+$team+"] High-ELB-Latency (" + $elb.LoadBalancerName + ")") -AlarmDescription "Created by PowerShell script" -Namespace "AWS/ELB" -MetricName Latency -Dimension $dimension1 -AlarmActions $CWtopicARN -ComparisonOperator GreaterThanOrEqualToThreshold -EvaluationPeriods 6 -Period 300 -Statistic Average -Threshold $latencyLimit -ProfileName $profileName -Region $region.Region

           echo $elb.LoadBalancerName
           $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>”);
        }
        else
        {
            $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=close_red.png height=20 width=20/></td>”);
        }
    }
    else
    {
        $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>”);
    }
   

    if($elbAlarmCriticalZeroHealthyHosts.Count -eq 0)
    {
        if($elb.CreatedTime -lt (Get-Date).AddDays(-15) -and $env -eq "PRD" -and $elbBlacklist.Contains($elb.LoadBalancerName) -eq $false)
        {
           Write-CWMetricAlarm -AlarmName $("[High]["+$alarmPrefixTeam+"] ELB-Zero-Healthy-Hosts (" + $elb.LoadBalancerName + ")") -AlarmDescription "Created by PowerShell script" -Namespace "AWS/ELB" -MetricName HealthyHostCount -Dimension $dimension1 -AlarmActions $topicARN -ComparisonOperator LessThanOrEqualToThreshold -EvaluationPeriods 3 -Period 60 -Statistic Average -Threshold 0 -ProfileName $profileName -Region $region.Region

           echo $elb.LoadBalancerName
           $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>”);
        }
        else
        {
            $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=close_red.png height=20 width=20/></td>”);
        }
    }
    else
    {
        $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>”);
    }

    if($elbAlarmWarningUnHealthyHosts.Count -eq 0)
    {
        if($elb.CreatedTime -lt (Get-Date).AddDays(-15) -and $env -eq "PRD" -and $elbBlacklist.Contains($elb.LoadBalancerName) -eq $false)
        {
           Write-CWMetricAlarm -AlarmName $("[Warning]["+$team+"] ELB-UnHealthy-Hosts (" + $elb.LoadBalancerName + ")") -AlarmDescription "Created by PowerShell script" -Namespace "AWS/ELB" -MetricName UnHealthyHostCount -Dimension $dimension1 -AlarmActions $CWtopicARN -ComparisonOperator GreaterThanOrEqualToThreshold -EvaluationPeriods 3 -Period 300 -Statistic Average -Threshold 1 -ProfileName $profileName -Region $region.Region

           echo $elb.LoadBalancerName
           $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>”);
        }
        else
        {
            $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=close_red.png height=20 width=20/></td>”);
        }
    }
    else
    {
        $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>”);
    }

    if($elbAlarmCriticalHighQueueLength.Count -eq 0)
    {
        if($elb.CreatedTime -lt (Get-Date).AddDays(-15) -and $env -eq "PRD" -and $elbBlacklist.Contains($elb.LoadBalancerName) -eq $false)
        {
           Write-CWMetricAlarm -AlarmName $("[High]["+$alarmPrefixTeam+"] ELB-High-Queue-Length (" + $elb.LoadBalancerName + ")") -AlarmDescription "Created by PowerShell script" -Namespace "AWS/ELB" -MetricName SurgeQueueLength -Dimension $dimension1 -AlarmActions $topicARN -ComparisonOperator GreaterThanOrEqualToThreshold -EvaluationPeriods 3 -Period 300 -Statistic Average -Threshold 20 -ProfileName $profileName -Region $region.Region

           echo $elb.LoadBalancerName
           $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>”);
        }
        else
        {
            $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=close_red.png height=20 width=20/></td>”);
        }
    }
    else
    {
        $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>”);
    }

    if($elbAlarmWarningHighQueueLength.Count -eq 0)
    {
        if($elb.CreatedTime -lt (Get-Date).AddDays(-15) -and $env -eq "PRD" -and $elbBlacklist.Contains($elb.LoadBalancerName) -eq $false)
        {
           Write-CWMetricAlarm -AlarmName $("[Warning]["+$team+"] ELB-High-Queue-Length (" + $elb.LoadBalancerName + ")") -AlarmDescription "Created by PowerShell script" -Namespace "AWS/ELB" -MetricName SurgeQueueLength -Dimension $dimension1 -AlarmActions $CWtopicARN -ComparisonOperator GreaterThanOrEqualToThreshold -EvaluationPeriods 2 -Period 300 -Statistic Average -Threshold 10 -ProfileName $profileName -Region $region.Region

           echo $elb.LoadBalancerName
           $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>”);
        }
        else
        {
            $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=close_red.png height=20 width=20/></td>”);
        }
    }
    else
    {
        $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>”);
    }

    if($elbAlarmCriticalMaxQueueLengthReached.Count -eq 0)
    {
        if($elb.CreatedTime -lt (Get-Date).AddDays(-15) -and $env -eq "PRD" -and $elbBlacklist.Contains($elb.LoadBalancerName) -eq $false)
        {
           Write-CWMetricAlarm -AlarmName $("[High]["+$alarmPrefixTeam+"] ELB-Max-Queue-Length-Reached (" + $elb.LoadBalancerName + ")") -AlarmDescription "Created by PowerShell script" -Namespace "AWS/ELB" -MetricName SpilloverCount -Dimension $dimension1 -AlarmActions $topicARN -ComparisonOperator GreaterThanOrEqualToThreshold -EvaluationPeriods 3 -Period 60 -Statistic Sum -Threshold 1 -ProfileName $profileName -Region $region.Region

           echo $elb.LoadBalancerName
           $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>”);
        }
        else
        {
            $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=close_red.png height=20 width=20/></td>”);
        }
    }
    else
    {
        $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>”);
    }

    if($elbAlarmWarningRequestsFailing.Count -eq 0)
    {
        if($elb.CreatedTime -lt (Get-Date).AddDays(-15) -and $env -eq "PRD" -and $elbBlacklist.Contains($elb.LoadBalancerName) -eq $false)
        {
           $faileRequestLimit = 7
           if($elb.LoadBalancerName -eq "SGE1PRDBIRS01-ELB" -or $elb.LoadBalancerName -eq "SGE1PRDODIN-BGS-ELB-INT")
           {
             $faileRequestLimit = 25.0
           }
           Write-CWMetricAlarm -AlarmName $("[Warning]["+$team+"] ELB-Requests-Failing (" + $elb.LoadBalancerName + ")") -AlarmDescription "Created by PowerShell script" -Namespace "AWS/ELB" -MetricName HTTPCode_ELB_5XX -Dimension $dimension1 -AlarmActions $CWtopicARN -ComparisonOperator GreaterThanOrEqualToThreshold -EvaluationPeriods 3 -Period 60 -Statistic Sum -Threshold $faileRequestLimit -ProfileName $profileName -Region $region.Region

           echo $elb.LoadBalancerName
           $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>”);
        }
        else
        {
            $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=close_red.png height=20 width=20/></td>”);
        }
    }
    else
    {
        $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>”);
    }

    if($elbAlarmCriticalRequestsFailing.Count -eq 0)
    {
        if($elb.CreatedTime -lt (Get-Date).AddDays(-15) -and $env -eq "PRD" -and $elbBlacklist.Contains($elb.LoadBalancerName) -eq $false)
        {
           $faileRequestLimit = 50
           Write-CWMetricAlarm -AlarmName $("[High]["+$alarmPrefixTeam+"] ELB-Requests-Failing (" + $elb.LoadBalancerName + ")") -AlarmDescription "Created by PowerShell script" -Namespace "AWS/ELB" -MetricName HTTPCode_ELB_5XX -Dimension $dimension1 -AlarmActions $topicARN -ComparisonOperator GreaterThanOrEqualToThreshold -EvaluationPeriods 3 -Period 60 -Statistic Sum -Threshold $faileRequestLimit -ProfileName $profileName -Region $region.Region

           echo $elb.LoadBalancerName
           $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>”);
        }
        else
        {
            $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=close_red.png height=20 width=20/></td>”);
        }
    }
    else
    {
        $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>”);
    }

    $tagKeys = @("ENV", "TEAM");
    $tags = ((Get-ELBTags -LoadBalancerName $elb.LoadBalancerName -ProfileName $profileName -Region $region.Region).Tags | Where-Object {$_.Key -in $tagKeys})
    if($tags.Count -eq 2)
    {
        $tags = $tags | Sort-Object @{Expression={$_.Key}; Ascending=$true}
        if($tags[0].Value -eq "PRD")
        {
            if($tags[1].Value -eq "BI")
            {
                $teamBI_PROD = $($teamBI_PROD + $htmlLine);
            }
            elseif($tags[1].Value -eq "BSD")
            {
                $teamBSD_PROD = $($teamBSD_PROD + $htmlLine);
            }
            elseif($tags[1].Value -eq "GDM")
            {
                $teamGDM_PROD = $($teamGDM_PROD + $htmlLine);
            }
            elseif($tags[1].Value -eq "ITIS")
            {
                $teamITIS_PROD = $($teamITIS_PROD + $htmlLine);
            }
            elseif($tags[1].Value -eq "PD")
            {
                $teamPD_PROD = $($teamPD_PROD + $htmlLine);
            }
            elseif($tags[1].Value -eq "SF")
            {
                $teamSF_PROD = $($teamSF_PROD + $htmlLine);
            }
            else
            {
                $teamNULL_PROD = $($teamNULL_PROD + $htmlLine);
            }
        }
    }
   }
}

$html = $("<html><body>Last Updated (UTC) - " + (Get-Date).ToUniversalTime() + "<table border=1 width=100%>");

$metricsColums = "<td><b>Warning-High-Latency</b></td> <td><b>Critical-Zero-Healthy-Hosts</b></td> <td><b>Warning-UnHealthy-Hosts</b></td> <td><b>Critical-High-Queue-Length</b></td> <td><b>Warning-High-Queue-Length</b></td> <td><b>Critical-Max-Queue-Length-Reached</b></td> <td><b>Warning-Requests-Failing</b></td> <td><b>Critical-Requests-Failing</b></td>"

if($teamNULL_PROD.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM NULL</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>”);
  $html =  $($html + $teamNULL_PROD + "<tr></tr>");
}

if($teamBI_PROD.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM BI</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>”);
  $html =  $($html + $teamBI_PROD + "<tr></tr>");
}

if($teamBSD_PROD.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM BSD</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>”);
  $html =  $($html + $teamBSD_PROD + "<tr></tr>");
}

if($teamGDM_PROD.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM GDM</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>”);
  $html =  $($html + $teamGDM_PROD + "<tr></tr>");
}

if($teamITIS_PROD.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM ITIS</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>”);
  $html =  $($html + $teamITIS_PROD + "<tr></tr>");
}

if($teamPD_PROD.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM PD</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>”);
  $html =  $($html + $teamPD_PROD + "<tr></tr>");
}

if($teamSF_PROD.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM SalesForce</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>”);
  $html =  $($html + $teamSF_PROD + "<tr></tr>");
}

$html =  $($html + "</table></body></html>");

$html | Set-Content 'D:\e1awsinventory\html\cw-elb.html';

Write-S3Object -BucketName "e1aws-inventory.ef.com" -File "D:\e1awsinventory\html\cw-elb.html" -ProfileName awsgbl  -Region ap-southeast-1
