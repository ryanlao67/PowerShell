#This Script is used for generating LiveDB Disk Usage
 
[array]$results=$null

#E1SD.COM DB Servers
[array]$LiveDBServers=@(
"CNE1PRDNODE01",
"CNE1PRDNODE02",
"CNE1PRDRPLDB01",
"SGE1PRDNODE01",
"SGE1PRDNODE03",
"SGE1PRDRPLDB01"
)



 $script={
                $teamname=$args[0]
                $DiskResult=Get-WmiObject win32_logicaldisk -Filter "Drivetype=3" -ErrorAction SilentlyContinue 
                $DiskResult | Select-Object @{Label = "Server Name";Expression = {$_.SystemName}}, 
                                            @{Label = "Team";Expression = {$teamname}}, 
                                            @{Label = "Drive Letter";Expression = {$_.DeviceID}}, 
                                            @{Label = "Total Capacity (GB)";Expression = {"{0:N1}" -f( $_.Size / 1gb)}}, 
                                            @{Label = "Free Space (GB)";Expression = {"{0:N1}" -f( $_.Freespace / 1gb ) }}, 
                                            @{Label = 'Free Space (%)'; Expression = {"{0:P0}" -f ($_.freespace/$_.size)}}
            }
            
$LiveDBDiskResult=icm -ComputerName $LiveDBServers -ScriptBlock $script -ArgumentList "DB"  -HideComputerName      



#EF.com DB Server
[array]$EFDomainDB=@(
"CNE1PRDBIDB01.ef.com",
"SGE1PRDBIDB01"
)

#get the encrypted password from txt file and convert to secure string
$Securepassword2=Get-Content \\CNE1WSUS02\D$\DiskUsage\credential.txt | convertto-securestring

#create the credential
$UserName = "ef.com\ewen.he"
$Credentials = New-Object System.Management.Automation.PSCredential -ArgumentList $UserName, $SecurePassword2

#get the ef.com db servers result
$EFDBResult=icm -ComputerName $EFDomainDB -ScriptBlock $script -ArgumentList "DB"  -Credential $Credentials -HideComputerName
 


#Total Result
[array]$results+=$LiveDBDiskResult
[array]$results+=$EFDBResult
$DiskReport=$results | select  "Server Name","Team","Drive Letter","Total Capacity (GB)","Free Space (GB)","Free Space (%)" 



#Inventory Format
$htmlFormat = "<style>"
$htmlFormat = $htmlFormat + "BODY{font-family: Segoe UI; font-size: 14px;}"
$htmlFormat = $htmlFormat + "TABLE{border-width: 1px; border-style: solid; border-color: black; border-collapse: collapse;}"
$htmlFormat = $htmlFormat + "TH{border-width: 2px; padding: 2px; border-style: solid; border-color: black;}"
$htmlFormat = $htmlFormat + "TD{border-width: 1px; padding: 1px; border-style: solid; border-color: orange; white-space:nowrap;}"
$htmlFormat = $htmlFormat + "</style>"

#All DB Disk Usage Report
$DiskReportHTML = $DiskReport | ConvertTo-HTML -Head $htmlFormat -Body "<H2>LiveDB-Disk-Report</H2>"
$DiskReportHTML| Set-Content   "\\CNE1WSUS02\D$\DiskUsage\LiveDB-DiskUsage-Temp.html"


#Low Disk(<20%) Report
#$LowDiskReport = $LowDiskReport | ConvertTo-HTML -Head $htmlFormat -Body "<H2>Live-Low-Disk-Report (DiskFreeSpace<20%)</H2>"
#$LowDiskReport| Set-Content    "\\CNE1WSUS02\C$\Monitor\Prod-LowDiskUsage.html"


#phase-2 Highlight the driver which Disk Space less than 20%
[array]$htmlResult=gc "\\CNE1WSUS02\D$\DiskUsage\LiveDB-DiskUsage-Temp.html"

[array]$trs=$null
foreach($tr in $htmlresult)
{

  if( ($tr -like "*tr*") -and ($tr -notlike  "*DOCTYPE*") -and ($tr -notlike  "*serve*"))
  {    
    
    $percentnum=$null
    $TempTR=$tr.split('%')[0]
    $percentnum=$TempTR.substring($TempTR.length - 3).trim()

    if($percentnum -like "*>*")
    { #less than 10%
     $percentnum=$percentnum.Split('>')[1]
     [array]$trs+=$tr -replace "<td>$PercentNum %</td>","<td style='background-color:#FF8080'>$PercentNum %</td>"
    }
    else
    {   
      #great than 10% 
      if($PercentNum -le 20)
      {[array]$trs+=$tr -replace "<td>$PercentNum %</td>","<td style='background-color:#FF8080'>$PercentNum %</td>"}
      else
      {[array]$trs+=$tr}  
    }



  }
  
}


$timestamp=(Get-Date).ToString()

$content='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">'
$content+='<html xmlns="http://www.w3.org/1999/xhtml">'
$content+='<head>'
$content+='<style>BODY{font-family: Segoe UI; font-size: 14px;}TABLE{border-width: 1px; border-style: solid; border-color: black; border-collapse: collapse;}TH{border-width: 2px; padding: 2px; border-style: solid; border-color: black;}TD{border-width: 1px; padding: 1px; border-style: solid; border-color: orange; white-space:nowrap;}</style>'
$content+='</head><body>'
$content+="<H2>LiveDB-Disk-Report $timestamp</H2>"
$content+='<table>'
$content+='<colgroup><col/><col/><col/><col/><col/><col/></colgroup>'
$content+='<tr><th>Server Name</th><th>Team</th><th>Drive Letter</th><th>Total Capacity (GB)</th><th>Free Space (GB)</th><th>Free Space (%)</th></tr>'
$content+=$trs
$content+='</table>'
$content+='</body></html>'


$content | Set-Content "\\CNE1WSUS02\D$\e1awsinventory\html\diskreport-livedb.html"

"Content was uploaded to \\CNE1WSUS02\D$\e1awsinventory\html\diskreport-livedb.html"

#Remove temp files
Remove-Item \\CNE1WSUS02\D$\DiskUsage\LiveDB-DiskUsage-Temp.html

Write-S3Object -BucketName "e1aws-inventory.ef.com" -File "D:\e1awsinventory\html\diskreport-livedb.html" -ProfileName awsgbl -Region ap-southeast-1
