﻿ ####################################################Global S3 Bucket##########################################################
 [array]$SGREsults=$null

 $SGREsults=icm -ComputerName SGE1WSUS01 -ScriptBlock {

 [array]$Buckets=Get-S3Bucket -Region ap-southeast-1 -ProfileName awsgbl  | ? {$_.BucketName -ne "e1-usa-misc"} | ? {$_.BucketName -ne "ntb-transfer-temp"} | select -ExpandProperty bucketname 

    $dimension1 = New-Object Amazon.CloudWatch.Model.Dimension
    $dimension1.set_Name("BucketName")
    $dimension2 = New-Object Amazon.CloudWatch.Model.Dimension
    $dimension2.set_Name("StorageType")
    $dimension2.set_Value("StandardStorage")
    $dimension3 = New-Object Amazon.CloudWatch.Model.Dimension
    $dimension3.set_Name("StorageType")
    $dimension3.set_Value("StandardIAStorage")
    $dimension4 = New-Object Amazon.CloudWatch.Model.Dimension
    $dimension4.set_Name("StorageType")
    $dimension4.set_Value("GlacierStorage")
    $dimensionSets = (@($dimension1,$dimension2),@($dimension1,$dimension3),@($dimension1,$dimension4))

foreach($bucket in $Buckets)
{   
       #debug
       write-host $bucket
      
       #Get the Region
       $region=$null
       $region=Get-S3BucketLocation -BucketName $bucket -ProfileName awsgbl | select -ExpandProperty value

       #Get the Bucket's Team
       $TagTeam=$null
       $TagTeam=Get-S3BucketTagging -BucketName $bucket -region $region -ProfileName awsgbl | ? {$_.key -eq "TEAM"} | select -ExpandProperty value

       #new 
       $dimension1.set_Value($bucket)
             

        foreach($dimensionSet in $dimensionSets)
        {   
            #Standard
            if($dimensionSets.IndexOf($dimensionSet) -eq 0)
             {
               $metrics=$null
               $metrics = (Get-CWMetricStatistics -Dimension $dimensionSet -EndTime (Get-Date).ToUniversalTime() -MetricName BucketSizeBytes -Namespace AWS/S3 -Period 1200 -ProfileName awsgbl  -Region $region -StartTime (Get-Date).ToUniversalTime().AddDays(-3) -Statistic Maximum -Unit Bytes);
               $std_bucketSize = 0
               if($metrics.datapoints.count -gt 0)
                {$std_bucketSize = $metrics.datapoints[0].Maximum;}
             }
             #Standard_IA
             if($dimensionSets.IndexOf($dimensionSet) -eq 1)
             {
               $metrics=$null
               $metrics = (Get-CWMetricStatistics -Dimension $dimensionSet -EndTime (Get-Date).ToUniversalTime() -MetricName BucketSizeBytes -Namespace AWS/S3 -Period 1200 -ProfileName awsgbl  -Region $region -StartTime (Get-Date).ToUniversalTime().AddDays(-3) -Statistic Maximum -Unit Bytes);
               $stdIA_bucketSize = 0
               if($metrics.datapoints.count -gt 0)
              {$stdIA_bucketSize = $metrics.datapoints[0].Maximum;}
             }
             #Glacier
             if($dimensionSets.IndexOf($dimensionSet) -eq 2)
             {
               $metrics=$null
               $metrics = (Get-CWMetricStatistics -Dimension $dimensionSet -EndTime (Get-Date).ToUniversalTime() -MetricName BucketSizeBytes -Namespace AWS/S3 -Period 1200 -ProfileName awsgbl  -Region $region -StartTime (Get-Date).ToUniversalTime().AddDays(-3) -Statistic Maximum -Unit Bytes);
               $gla_bucketSize = 0
               if($metrics.datapoints.count -gt 0)
               {$gla_bucketSize = $metrics.datapoints[0].Maximum;}
             }
                                   
        }



       $TotalStdSize=$null
       $TotalStdIASize=$null
       $TotalGlacierSize=$null
       $TotalSize=$null
       

      [int64]$TotalStdSize="{0:N0}" -f ($std_bucketSize/1GB) 
      [int64]$TotalStdIASize="{0:N0}" -f ($stdIA_bucketSize/1GB) 
      [int64]$TotalGlacierSize="{0:N0}" -f ($gla_bucketSize/1GB)
       $totalSize=$TotalStdSize+$TotalStdIASize+$TotalGlacierSize
      


     #if Tag TEAM is missing, then add value Null as team name
     if($TagTeam -eq $null){$TagTeam="Null"}
    
     $output=New-Object psobject  
     $output | Add-Member NoteProperty "Team"          $TagTeam
     $output | Add-Member NoteProperty "BucketName"    $bucket
     $output | Add-Member NoteProperty "Standard/GB"      $TotalStdSize
     $output | Add-Member NoteProperty "Standard-IA/GB"   $TotalStdIASize
     $output | Add-Member NoteProperty "Glacier/GB"       $TotalGlacierSize
     $output | Add-Member NoteProperty "Total/GB"         $TotalSize
     $output | Add-Member NoteProperty "Region"        $region
     $output 
    
  }
}





####################################################China S3 Bucket##########################################################
#China S3 Bucket
#China S3 Bucket
[array]$CNResults=$null

Write-Host "Starting process China Region"
[array]$CN_Buckets=$nul
$CN_Buckets=Get-S3Bucket -Region cn-north-1 -ProfileName awscn | select -ExpandProperty BucketName

    $dimension1 = New-Object Amazon.CloudWatch.Model.Dimension
    $dimension1.set_Name("BucketName")

    $dimension2 = New-Object Amazon.CloudWatch.Model.Dimension
    $dimension2.set_Name("StorageType")
    $dimension2.set_Value("StandardStorage")

    $dimension3 = New-Object Amazon.CloudWatch.Model.Dimension
    $dimension3.set_Name("StorageType")
    $dimension3.set_Value("StandardIAStorage")
    
    $dimension4 = New-Object Amazon.CloudWatch.Model.Dimension
    $dimension4.set_Name("StorageType")
    $dimension4.set_Value("GlacierStorage")

    $dimensionSets = (@($dimension1,$dimension2),@($dimension1,$dimension3),@($dimension1,$dimension4))

 foreach($CN_bucket in $CN_Buckets)
   {   
       #Get the Bucket's Team
       $TagTeam=$null
       $TagTeam=Get-S3BucketTagging -BucketName $cn_bucket -ProfileName awscn  -Region cn-north-1 | ? {$_.key -eq "TEAM"} | select -ExpandProperty value

       #Get the Region
       $region="cn-north-1"


       #Get the S3 Objects
       $dimension1.set_Value($CN_bucket)

        foreach($dimensionSet in $dimensionSets)
        {   
            #Standard
            if($dimensionSets.IndexOf($dimensionSet) -eq 0)
             {
               $metrics=$null
               $metrics = (Get-CWMetricStatistics -Dimension $dimensionSet -EndTime (Get-Date).ToUniversalTime() -MetricName BucketSizeBytes -Namespace AWS/S3 -Period 1200 -ProfileName awscn  -Region cn-north-1 -StartTime (Get-Date).ToUniversalTime().AddDays(-3) -Statistic Maximum -Unit Bytes);
               $std_bucketSize = 0
               if($metrics.datapoints.count -gt 0)
                {$std_bucketSize = $metrics.datapoints[0].Maximum;}
             }
             #Standard_IA
             if($dimensionSets.IndexOf($dimensionSet) -eq 1)
             {
               $metrics=$null
               $metrics = (Get-CWMetricStatistics -Dimension $dimensionSet -EndTime (Get-Date).ToUniversalTime() -MetricName BucketSizeBytes -Namespace AWS/S3 -Period 1200 -ProfileName awscn  -Region cn-north-1 -StartTime (Get-Date).ToUniversalTime().AddDays(-3) -Statistic Maximum -Unit Bytes);
               $stdIA_bucketSize = 0
               if($metrics.datapoints.count -gt 0)
              {$stdIA_bucketSize = $metrics.datapoints[0].Maximum;}
             }
             #Glacier
             if($dimensionSets.IndexOf($dimensionSet) -eq 2)
             {
               $metrics=$null
               $metrics = (Get-CWMetricStatistics -Dimension $dimensionSet -EndTime (Get-Date).ToUniversalTime() -MetricName BucketSizeBytes -Namespace AWS/S3 -Period 1200 -ProfileName awscn  -Region cn-north-1 -StartTime (Get-Date).ToUniversalTime().AddDays(-3) -Statistic Maximum -Unit Bytes);
               $gla_bucketSize = 0
               if($metrics.datapoints.count -gt 0)
               {$gla_bucketSize = $metrics.datapoints[0].Maximum;}
             }

       }




       $TotalStdSize=$null
       $TotalStdIASize=$null
       $TotalGlacierSize=$null
       $TotalSize=$null

      [int64]$TotalStdSize="{0:N0}" -f ($std_bucketSize/1GB) 
      [int64]$TotalStdIASize="{0:N0}" -f ($stdIA_bucketSize/1GB) 
      [int64]$TotalGlacierSize="{0:N0}" -f ($gla_bucketSize/1GB)
      $totalSize=$TotalStdSize+$TotalStdIASize+$TotalGlacierSize
      
      
       

     #if Tag TEAM is missing, then add value Null as team name
     if($TagTeam -eq $null){$TagTeam="Null"}
    

     $output2=New-Object psobject  
     $output2 | Add-Member NoteProperty "Team"          $TagTeam
     $output2 | Add-Member NoteProperty "BucketName"    $cn_bucket
     $output2 | Add-Member NoteProperty "Standard/GB"      $TotalStdSize
     $output2 | Add-Member NoteProperty "Standard-IA/GB"   $TotalStdIASize
     $output2 | Add-Member NoteProperty "Glacier/GB"       $TotalGlacierSize
     $output2 |  Add-Member NoteProperty "Total/GB"         $totalSize
     $output2 | Add-Member NoteProperty "Region"        $region
     $output2  

     $CNResults+=$output2

   }
 

$TotalResults=$null
$TotalResults=$CNResults
$TotalResults+=$SGResults

$TotalResults=$TotalResults | sort team,region,bucketname |  select -Property team,bucketname,Standard/GB,Standard-IA/GB,Glacier/GB,Total/GB,Region

#remove old files
Remove-Item -Path  D:\e1awsinventory\html\s3bucket.xlsx -Force


#Export the Excel file with pivot table
$date=(get-date).tostring('yyyyMMdd')
#$TotalResults | Export-Excel -WorkSheetname S3Bucket_$date  -Path  D:\e1awsinventory\html\s3bucket.xlsx -IncludePivotTable -PivotRows team -PivotColumns region -PivotData @{'standard/GB'='Sum';'standard-IA/GB'='Sum';'Glacier/GB'='sum';'Total/GB'='sum'}
$TotalResults | Export-Excel -WorkSheetname S3Bucket_$date  -Path  D:\e1awsinventory\html\s3bucket.xlsx -IncludePivotTable -PivotRows team -PivotColumns region -PivotData @{'Total/GB'='sum'}

#Inventory Format
$htmlFormat = "<style>"
$htmlFormat = $htmlFormat + "BODY{font-family: Segoe UI; font-size: 14px;}"
$htmlFormat = $htmlFormat + "TABLE{border-width: 1px; border-style: solid; border-color: black; border-collapse: collapse;}"
$htmlFormat = $htmlFormat + "TH{border-width: 2px; padding: 2px; border-style: solid; border-color: black;}"
$htmlFormat = $htmlFormat + "TD{border-width: 1px; padding: 1px; border-style: solid; border-color: orange; white-space:nowrap;}"
$htmlFormat = $htmlFormat + "</style>"

#Generate html file
$generatedTime=get-date
$S3Report =$null
$S3Report = $TotalResults | sort team,region,bucketname | ConvertTo-HTML -Head $htmlFormat -Body "<H2><a href=s3bucket.xlsx>S3Bucket Excel File Download</a> --Last Updated at $generatedTime</H2>"
$S3Report| Set-Content  "D:\e1awsinventory\html\s3.html"


#upload to S3
Write-S3Object -BucketName "e1aws-inventory.ef.com" -File "D:\e1awsinventory\html\s3.html"       -ProfileName awsgbl -Region ap-southeast-1
Write-S3Object -BucketName "e1aws-inventory.ef.com" -File "D:\e1awsinventory\html\s3bucket.xlsx" -ProfileName awsgbl -Region ap-southeast-1
