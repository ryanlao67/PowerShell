﻿$regions = Get-AWSRegion -IncludeChina

$teamNULL = "";
$teamBI = "";
$teamBSD = "";
$teamGDM = "";
$teamITIS = "";
$teamPD = "";
$teamSF = ""; 

$ec2Blacklist = "SGE1PRDMPLSPROXY","CNE1PRDMPLSPROXY","ASAM-E1-RODC02","CNE1PRDPSSZDK-W01","CNE1PRDPSSZDK-W02","SGE1PRDPSSZDK01","SGE1PRDPSSZDK02"

foreach($region in $regions)
{
    echo $region.Region
    if($region.Region.StartsWith("ap-southeast-1"))
    {
      $profileName = "awsgbl";
      $topicARN = "arn:aws:sns:ap-southeast-1:415204155249:OPSGENIE_AWS"    
    }
    elseif($region.Region.StartsWith("cn-"))
    {
      $profileName = "awscn";
      $topicARN = "arn:aws-cn:sns:cn-north-1:014301917773:OPSGENIE_AWS"
    }
    elseif($region.Region.StartsWith('eu-west-1'))
    {
      $topicARN = "arn:aws:sns:eu-west-1:415204155249:OPSGENIE_AWS"
    }
    else
    {
        continue
    }

    $dimension1 = New-Object Amazon.CloudWatch.Model.Dimension
    $dimension1.set_Name("InstanceId")

    $alarms = Get-CWAlarm -ProfileName $profileName -Region $region.Region
    $ec2Alarms = ($alarms | Where-Object {$_.Namespace -eq "AWS/EC2"})

    $EIPs = Get-EC2Address -ProfileName $profileName -Region $region.Region

    $groups = Get-EC2Instance -ProfileName $profileName -Region $region.Region
    $ec2servers=@()
    foreach($group in $groups)
    {
      foreach($instance in $group.Instances)
      {
        $ec2servers+=$instance;
      }
    }

    $ec2servers = $ec2servers | sort-object @{Expression={($_.Tags | Where-Object{$_.Key -eq "Name"}).Value}; Ascending=$true}
    
      foreach($instance in $ec2servers)
      {
        $htmlLine = "";
        if($instance.State.Name -eq "running")
        {
          $htmlLine = "<tr><td><img src=running.png height=16 width=16 title=Running /></td>"
        }
        else
        {
          $htmlLine = "<tr><td><img src=stopped.png height=16 width=16 title=Stopped /></td>"
        }

        $htmlLine = $($htmlLine + "<td>" + $instance.Platform + "</td>");

        $env =""
        $tagEnv = ($instance.Tags | Where-Object {$_.Key -ieq "ENV"})
        if($tagEnv.Key.Length -gt 0)
        {
            $env=$tagEnv.Value;
        }

        $subteam =""
        $tagSubteam = ($instance.Tags | Where-Object {$_.Key -ieq "SUBTEAM"})
        if($tagSubteam.Key.Length -gt 0)
        {
            $subteam=$tagSubteam.Value;
        }

        $team=""
        $tagTeam = ($instance.Tags | Where-Object {$_.Key -ieq "TEAM"})
        if($tagTeam.Key.Length -gt 0)
        {
            $team = $tagTeam.Value;
            if($team -ne "BI" -and $team -ne "BSD" -and $team -ne "GDM" -and $team -ne "PD" -and $team -ne "SF")
            {
                $team = "ITIS"
            }
        }
        else
        {
            $team = "ITIS"
        }

        if($subteam)
        {
         $CWtopicARN = New-SNSTopic -Name $("E1" + $subteam) -ProfileName $profileName -Region $region.Region
         $alarmPrefixTeam = $subteam.Replace("_","-")
         if($subteam -eq "BSD_LEARNING" -or $subteam -eq "BSD_ODIN")
         {
            $alarmPrefixTeam = "BSD-OMNI"
         }
         elseif($subteam -eq "BSD_FOUNDATION" -or $subteam -eq "BSD_EFP")
         {
            $alarmPrefixTeam ="BSD-SHS"
         }
        }
    else
    {
        $CWtopicARN = New-SNSTopic -Name $("E1" + $team + "_APP_AWS_Warning") -ProfileName $profileName -Region $region.Region
        $alarmPrefixTeam = $team
    }

        $purpose =""
        $tagPurpose = ($instance.Tags | Where-Object {$_.Key -ieq "PURPOSE"})
        if($tagPurpose.Key.Length -gt 0)
        {
            $purpose=$("<img src=Info.png height=16 width=16 title='" + $tagPurpose.Value + "'/>");
        }

        $instanceName = "";
        $tag = ($instance.Tags | Where-Object {$_.Key -ieq "Name"})
        if($tag.Key.Length -gt 0)
        {
            
            $htmlLine = $($htmlLine + "<td>" + $tag.Value + "<sup>" + $env + "</sup>" + $purpose + "</td>");
            $instanceName = $tag.Value;
        }
        else
        {
          $htmlLine = $($htmlLine + "<td></td>");
        }

        $tagDB = ($instance.Tags | Where-Object {$_.Key -ieq "DB"})
        if($tagDB.Key.Length -gt 0)
        {
            $db = $tagDB.Value;
            echo $instanceName
        }
        else
        {
            $db = ""
        }

        $ec2AlarmWarningHighCPU = ($ec2Alarms | Where-Object {$_.AlarmName  -match $("\[High\]\["+ $team + "\] High-CPU-Utilization \(" + $instanceName +": " + $instance.PrivateIPAddress + "\)")})
        
        $ec2AlarmCriticalStatusCheckFailed = ($ec2Alarms | Where-Object {$_.AlarmName -match $("\[High\]\[ITIS\] Status-Check-Failed \(" + $instanceName +": " + $instance.PrivateIPAddress + "\)")})
        
        $dimension1.set_Value($instance.InstanceId)

        if($ec2AlarmWarningHighCPU.Count -eq 0)
        {
            if($instance.State.Name -eq "running" -and $instance.LaunchTime -lt (Get-Date).AddDays(-1) -and $env -eq "PRD" -and $ec2Blacklist.Contains($instanceName) -eq $false)
            {
                Write-CWMetricAlarm -AlarmName $("[High]["+ $team + "] High-CPU-Utilization (" + $instanceName + ": " + $instance.PrivateIPAddress + ")") -AlarmDescription "Created by PowerShell script" -Namespace "AWS/EC2" -MetricName CPUUtilization -Dimension $dimension1 -AlarmActions $topicARN -OKAction $topicARN -ComparisonOperator GreaterThanOrEqualToThreshold -EvaluationPeriods 4 -Period 300 -Statistic Average -Threshold 80 -ProfileName $profileName -Region $region.Region
                echo $instanceName "High CPU alarm added"
                $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>”);
            }
            else
            {
                $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=close_red.png height=20 width=20/></td>”);
            }
        }
        else
        {
            $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>”);
        }

        if($ec2AlarmCriticalStatusCheckFailed.Count -eq 0)
        {
            if($instance.State.Name -eq "running" -and $instance.LaunchTime -lt (Get-Date).AddDays(-1) -and $env -eq "PRD" -and $ec2Blacklist.Contains($instanceName) -eq $false)
            {
                Write-CWMetricAlarm -AlarmName $("[High][ITIS] Status-Check-Failed (" + $instanceName + ": " + $instance.PrivateIPAddress + ")") -AlarmDescription "Created by PowerShell script" -Namespace "AWS/EC2" -MetricName StatusCheckFailed -Dimension $dimension1 -AlarmActions $topicARN -OKAction $topicARN -ComparisonOperator GreaterThanOrEqualToThreshold -EvaluationPeriods 1 -Period 300 -Statistic Average -Threshold 1 -ProfileName $profileName -Region $region.Region
                echo $instanceName  "Critical Status Check Fail alarm added"
                $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>”);
            }
            else
            {
                $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=close_red.png height=20 width=20/></td>”);
            }
        }
        else
        {
            $htmlLine = $($htmlLine + “<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>”);
        }

        $htmlLine = $($htmlLine + "<td>" + $instance.PrivateIPAddress + "</td>");
        if(($EIPs| Where-Object {$_.PublicIp -eq $instance.PublicIPAddress}).Count -gt 0)
        {
          $htmlLine = $($htmlLine + "<td><u>" + $instance.PublicIPAddress + "</u></td>");
        }
        else
        {
          $htmlLine = $($htmlLine + "<td>" + $instance.PublicIPAddress + "</td>");
        }
        $htmlLine = $($htmlLine + "<td>" + $region.Name + "</td></tr>");

        $tagTeam = ($instance.Tags | Where-Object {$_.Key -ieq "TEAM"})
        if($tagTeam.Key.Length -gt 0)
        {
         if($env -eq "PRD")
         {
         if($tagTeam.Value -eq "BI")
         {
            $teamBI = $($teamBI + $htmlLine);
         }
         elseif($tagTeam.Value -eq "BSD")
         {
            $teamBSD = $($teamBSD + $htmlLine);
         }
         elseif($tagTeam.Value -eq "GDM")
         {
            $teamGDM = $($teamGDM + $htmlLine);
         }
         elseif($tagTeam.Value -eq "ITIS")
         {
            $teamITIS = $($teamITIS + $htmlLine);
         }
         elseif($tagTeam.Value -eq "PD")
         {
            $teamPD = $($teamPD + $htmlLine);
         }
         elseif($tagTeam.Value -eq "SF")
         {
            $teamSF = $($teamSF + $htmlLine);
         }
         else
         {
            $teamNULL = $($teamNULL + $htmlLine);
         }
        }
        }
      }
}

$html = $("<html><body>Last Updated (UTC) - " + (Get-Date).ToUniversalTime() + "<table border=1 width=100%>");

if($teamNULL.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=10>" + "<b>TEAM NULL</b>" + "</td></tr><tr bgcolor=Beige><td></td><td><b>Platform</b></td><td><b>Name</b></td><td><b>Warning-High-CPU</b></td><td><b>Critical-High-CPU</b></td><td><b>Critical-Status-Check-Failed</b></td><td><b>Private IP</b></td><td><b>Public IP</b></td><td><b>Region</b></td></tr>");
  $html =  $($html + $teamNULL + "<tr></tr>");
}

if($teamBI.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=10>" + "<b>TEAM BI</b>" + "</td></tr><tr bgcolor=Beige><td></td><td><b>Platform</b></td><td><b>Name</b></td><td><b>Warning-High-CPU</b></td><td><b>Critical-High-CPU</b></td><td><b>Critical-Status-Check-Failed</b></td><td><b>Private IP</b></td><td><b>Public IP</b></td><td><b>Region</b></td></tr>");
  $html =  $($html + $teamBI + "<tr></tr>");
}

if($teamBSD.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=10>" + "<b>TEAM BSD</b>" + "</td></tr><tr bgcolor=Beige><td></td><td><b>Platform</b></td><td><b>Name</b></td><td><b>Warning-High-CPU</b></td><td><b>Critical-High-CPU</b></td><td><b>Critical-Status-Check-Failed</b></td><td><b>Private IP</b></td><td><b>Public IP</b></td><td><b>Region</b></td></tr>");
  $html =  $($html + $teamBSD + "<tr></tr>");
}

if($teamGDM.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=10>" + "<b>TEAM GDM</b>" + "</td></tr><tr bgcolor=Beige><td></td><td><b>Platform</b></td><td><b>Name</b></td><td><b>Warning-High-CPU</b></td><td><b>Critical-High-CPU</b></td><td><b>Critical-Status-Check-Failed</b></td><td><b>Private IP</b></td><td><b>Public IP</b></td><td><b>Region</b></td></tr>");
  $html =  $($html + $teamGDM + "<tr></tr>");
}

if($teamITIS.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=10>" + "<b>TEAM ITIS</b>" + "</td></tr><tr bgcolor=Beige><td></td><td><b>Platform</b></td><td><b>Name</b></td><td><b>Warning-High-CPU</b></td><td><b>Critical-High-CPU</b></td><td><b>Critical-Status-Check-Failed</b></td><td><b>Private IP</b></td><td><b>Public IP</b></td><td><b>Region</b></td></tr>");
  $html =  $($html + $teamITIS + "<tr></tr>");
}

if($teamPD.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=10>" + "<b>TEAM PD</b>" + "</td></tr><tr bgcolor=Beige><td></td><td><b>Platform</b></td><td><b>Name</b></td><td><b>Warning-High-CPU</b></td><td><b>Critical-High-CPU</b></td><td><b>Critical-Status-Check-Failed</b></td><td><b>Private IP</b></td><td><b>Public IP</b></td><td><b>Region</b></td></tr>");
  $html =  $($html + $teamPD + "<tr></tr>");
}

if($teamSF.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=10>" + "<b>TEAM SalesForce</b>" + "</td></tr><tr bgcolor=Beige><td></td><td><b>Platform</b></td><td><b>Name</b></td><td><b>Warning-High-CPU</b></td><td><b>Critical-High-CPU</b></td><td><b>Critical-Status-Check-Failed</b></td><td><b>Private IP</b></td><td><b>Public IP</b></td><td><b>Region</b></td></tr>");
  $html =  $($html + $teamSF + "<tr></tr>");
}

$html =  $($html + "</table></body></html>");

$html | Set-Content 'D:\e1awsinventory\html\cw-ec2.html';

Write-S3Object -BucketName "e1aws-inventory.ef.com" -File "D:\e1awsinventory\html\cw-ec2.html" -ProfileName awsgbl  -Region ap-southeast-1
