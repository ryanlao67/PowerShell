﻿function ConvertPSObjectToHashtable
{
    param (
        [Parameter(ValueFromPipeline)]
        $InputObject
    )

    process
    {
        if ($null -eq $InputObject) { return $null }

        if ($InputObject -is [System.Collections.IEnumerable] -and $InputObject -isnot [string])
        {
            $collection = @(
                foreach ($object in $InputObject) { ConvertPSObjectToHashtable $object }
            )

            Write-Output -NoEnumerate $collection
        }
        elseif ($InputObject -is [psobject])
        {
            $hash = @{}

            foreach ($property in $InputObject.PSObject.Properties)
            {
                $hash[$property.Name] = ConvertPSObjectToHashtable $property.Value
            }

            $hash
        }
        else
        {
            $InputObject
        }
    }
}

Function GetHtmlLine($reserved, $instanceCount, $region)
{
	$html = “<tr>”;
	if($reserved.State -eq “active”)
	{
		$html = $($html + ”<td><img src=running.png height=16 width=16/></td>”);
	}
	else
	{
		$html = $($html + ”<td><img src=stopped.png height=16 width=16/></td>”);
	}

	$html = $($html + ”<td>” + $reserved.ReservedInstancesId + ”</td>”);

	$html = $($html + ”<td>” + $reserved.ProductDescription + ”</td>”);

    if($instanceCount.getType().Name -eq "Hashtable")
    {

    	$html = $($html + ”<td>”);
    	if($instanceCount.ContainsKey("TotalPurchased"))
    	{ 
    		$html = $($html + $instanceCount["TotalPurchased"]);
    	}
    	foreach($key in $instanceCount.Keys)
    	{
    		if($key -ne "TotalPurchased")
    		{
    			$html = $($html +　"<li>" + $key + ":" + $instanceCount[$key] + "</li>");
    		}
    	}
    	$html = $($html + ”</td>”);
    }
    else
    {
		$html = $($html + ”<td>” + $instanceCount + ”</td>”);
	}

	$html = $($html + ”<td>” + $reserved.InstanceType + ”</td>”);
	$html = $($html + ”<td>” + $region.Name + “ - ” + $reserved.AvailabilityZone + ”</td>”);
	$html = $($html + ”<td>” + $reserved.CurrencyCode + “ “ + $reserved.FixedPrice.ToString() + ”</td>”);
	$html = $($html + ”<td>” + $reserved.CurrencyCode + “ “ + $reserved.UsagePrice.ToString() + ”</td>”);
	$html = $($html + ”<td>” + $reserved.End.ToString() + ”</td>”);
	$ts = New-TimeSpan -Seconds $reserved.Duration
	$html = $($html + ”<td>” + $ts.TotalDays.ToString() + ” days</td>”);
	$html = $($html + ”</tr>”);
	return $html;
}

$TeamsName = "TeamBI","TeamBSD","TeamGDM","TeamITIS","TeamPD","TeamSF"



$rsv1 =  Get-Content -Raw -Path "D:\e1awsinventory\scripts\ReservedInstances.json" | Out-String | ConvertFrom-Json

$rsv = ConvertPSObjectToHashtable $rsv1

$TeamHtml =  New-Object System.Collections.Hashtable
$TeamHtml.Add("TeamNull","")
foreach($team in $TeamsName)
{
    $TeamHtml.Add($team,"")
}

$regions = Get-AWSRegion -IncludeChina


foreach($region in $regions)
{
   $profileName = "awsgbl";
   if($region.Region.StartsWith("cn-"))
   {
     $profileName = "awscn";
   }
	
   $reservedList = (Get-EC2ReservedInstance -ProfileName $profileName -Region $region.region)

   foreach($reserved in $reservedList)
   {
        $instanceCount = $reserved.InstanceCount;

        if($instanceCount -gt 0)
        {
            foreach($team in $TeamsName)
            {
                if($rsv.Item($team).Item("ReservedInstancesID").ContainsKey($reserved.ReservedInstancesId))
                {
                    $rsvId = $rsv.Item($team).Item("ReservedInstancesID").Item($reserved.ReservedInstancesId)
                    $instanceCount -= $rsvId.Item("TotalPurchased");
                    $htmlLine = GetHtmlLine $reserved $rsvId $region;
                    $TeamHtml.Item($team) = $($TeamHtml.Item($team) + $htmlLine);
                    # $($rsv.Item($team).Item("ReservedInstancesID").Remove($reserved.ReservedInstancesId);
                    #$htmlLine
                }
            }
            if($instanceCount -gt 0)
            {
            	$htmlLine = GetHtmlLine $reserved $instanceCount $region;
                $TeamHtml.Item("TeamNull") = $($TeamHtml.Item("TeamNull") + $htmlLine);
            }
            #$TeamHtml
        }
    }
}

$TeamsName = $TeamsName + "TeamNull"

$html = $("<html><body>Last Updated (UTC) - " + (Get-Date).ToUniversalTime() + "<table border=1 width=100%>");

foreach($team in $TeamsName)
{
    if($TeamHtml.Item($team).Length -gt 0)
    {
        $html =  $($html + "<tr bgcolor=silver><td colspan=10>" + "<b>" + $team + "</b>" + "</td></tr><tr><td></td><td><b>RI Id</b></td><td><b>Platform</b></td><td><b>Instance Count</b></td><td><b>Instance Type</b></td><td><b>Zone</b></td><td><b>Upfront price</b></td><td><b>Usage price</b></td><td><b>Expires on</b></td><td><b>Term</b></td></tr>");
        $html =  $($html + $TeamHtml.Item($team) + "<tr></tr>");
        #$html
    }

}

$html =  $($html + "</table></body></html>");

$html | Set-Content 'D:\e1awsinventory\html\reserved-ec2.html';

Write-S3Object -BucketName "e1aws-inventory.ef.com" -File "D:\e1awsinventory\html\reserved-ec2.html" -ProfileName awsgbl -Region ap-southeast-1
