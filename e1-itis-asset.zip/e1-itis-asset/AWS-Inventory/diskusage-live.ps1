﻿#This Script is used for generating Stage Enviroment Disk Usage
  
$Regions=@("AWS_CN","AWS_SG")
$results=$null
  
#Each Team Disk Useage
   foreach($region in $Regions)
   { 

    if($Region -like "*beijing*")
    {[array]$OU=Get-ADObject -Filter 'ObjectClass -eq "organizationalUnit"' -SearchBase 'OU=AWS_CN,DC=E1SD,DC=Com' | ? {$_.name -notlike "*AWS_CN*"} | select -expandproperty name}
    else 
    { [array]$OU=Get-ADObject -Filter 'ObjectClass -eq "organizationalUnit"' -SearchBase 'OU=AWS_SG,DC=E1SD,DC=Com' | ? {$_.name -notlike "*AWS_SG*"} | select -expandproperty name}

     $result=$null
     foreach($team in $OU)
     {
          
     [array]$tempservers=$null
     $teamervers=Get-ADComputer -Filter 'ObjectClass -eq "Computer"' -SearchBase "ou=$team,OU=$Region,DC=E1SD,DC=Com" | select -ExpandProperty name

     $script={
                $teamname=$args[0]
                $DiskResult=Get-WmiObject win32_logicaldisk -Filter "Drivetype=3" -ErrorAction SilentlyContinue 
                $DiskResult | Select-Object @{Label = "Server Name";Expression = {$_.SystemName}}, 
                                            @{Label = "Team";Expression = {$teamname}}, 
                                            @{Label = "Drive Letter";Expression = {$_.DeviceID}}, 
                                            @{Label = "Total Capacity (GB)";Expression = {"{0:N1}" -f( $_.Size / 1gb)}}, 
                                            @{Label = "Free Space (GB)";Expression = {"{0:N1}" -f( $_.Freespace / 1gb ) }}, 
                                            @{Label = 'Free Space (%)'; Expression = {"{0:P0}" -f ($_.freespace/$_.size)}}
            }
            
     $result+=icm -ComputerName $teamervers -ScriptBlock $script -ArgumentList $team  -HideComputerName      
                                     
     }
    
     $results+=$result

   }


#Default OU-Computers Disk Usage
 [array]$DefaultComputers=Get-ADComputer -Filter 'ObjectClass -eq "Computer"' -SearchBase "CN=Computers,DC=E1SD,DC=Com" |  ? {($_.name -notlike  "*PRDCLDB*") -and ($_.name -notlike  "*PRDDB*")} | select -ExpandProperty name 

 $script={
                $teamname=$args[0]
                $DiskResult=Get-WmiObject win32_logicaldisk -Filter "Drivetype=3" -ErrorAction SilentlyContinue 
                $DiskResult | Select-Object @{Label = "Server Name";Expression = {$_.SystemName}}, 
                                            @{Label = "Team";Expression = {$teamname}}, 
                                            @{Label = "Drive Letter";Expression = {$_.DeviceID}}, 
                                            @{Label = "Total Capacity (GB)";Expression = {"{0:N1}" -f( $_.Size / 1gb)}}, 
                                            @{Label = "Free Space (GB)";Expression = {"{0:N1}" -f( $_.Freespace / 1gb ) }}, 
                                            @{Label = 'Free Space (%)'; Expression = {"{0:P0}" -f ($_.freespace/$_.size)}}
            }
            
$DefaultComputerresult=icm -ComputerName $DefaultComputers -ScriptBlock $script -ArgumentList "DB"  -HideComputerName      


 #DomainController Disk Usage
[array]$DomainControl=Get-ADComputer -Filter 'ObjectClass -eq "Computer"' -SearchBase "OU=Domain Controllers,DC=E1SD,DC=Com" | select -ExpandProperty name
 $script={
                $teamname=$args[0]
                $DiskResult=Get-WmiObject win32_logicaldisk -Filter "Drivetype=3" -ErrorAction SilentlyContinue 
                $DiskResult | Select-Object @{Label = "Server Name";Expression = {$_.SystemName}}, 
                                            @{Label = "Team";Expression = {$teamname}}, 
                                            @{Label = "Drive Letter";Expression = {$_.DeviceID}}, 
                                            @{Label = "Total Capacity (GB)";Expression = {"{0:N1}" -f( $_.Size / 1gb)}}, 
                                            @{Label = "Free Space (GB)";Expression = {"{0:N1}" -f( $_.Freespace / 1gb ) }}, 
                                            @{Label = 'Free Space (%)'; Expression = {"{0:P0}" -f ($_.freespace/$_.size)}}
            }
            
$DomainControllerresult=icm -ComputerName $DomainControl -ScriptBlock $script -ArgumentList "DC"  -HideComputerName   


#Finnal Result
$results+=$DefaultComputerresult
$results+=$DomainControllerresult
$DiskReport=$results | select  "Server Name","Team","Drive Letter","Total Capacity (GB)","Free Space (GB)","Free Space (%)" 
#sort object 
$freeSpace="Free Space (%)"
$DiskReport =$DiskReport | sort $freeSpace 


#FreeDisk Space less than 20%
$freespace="Free Space (%)"
$LowDiskReport=$results | select  "Server Name","Team","Drive Letter","Total Capacity (GB)","Free Space (GB)","Free Space (%)"  | ? {$_.$freespace -notlike "*100*" }  | ? {$_.$freespace -lt "20%" }


#Inventory Format
$htmlFormat = "<style>"
$htmlFormat = $htmlFormat + "BODY{font-family: Segoe UI; font-size: 14px;}"
$htmlFormat = $htmlFormat + "TABLE{border-width: 1px; border-style: solid; border-color: black; border-collapse: collapse;}"
$htmlFormat = $htmlFormat + "TH{border-width: 2px; padding: 2px; border-style: solid; border-color: black;}"
$htmlFormat = $htmlFormat + "TD{border-width: 1px; padding: 1px; border-style: solid; border-color: orange; white-space:nowrap;}"
$htmlFormat = $htmlFormat + "</style>"

#All Disk Usage Report
$DiskReportHTML = $DiskReport | ConvertTo-HTML -Head $htmlFormat -Body "<H2>Live-Disk-Report</H2>"
$DiskReportHTML| Set-Content   "\\CNE1WSUS02\D$\DiskUsage\Prod-DiskUsage-Temp.html"


#Low Disk(<20%) Report
#$LowDiskReport = $LowDiskReport | ConvertTo-HTML -Head $htmlFormat -Body "<H2>Live-Low-Disk-Report (DiskFreeSpace<20%)</H2>"
#$LowDiskReport| Set-Content    "\\CNE1WSUS02\C$\Monitor\Prod-LowDiskUsage.html"


#phase-2 HighLight the driver which is runing out of Disk Space
[array]$htmlResult=gc "\\CNE1WSUS02\D$\DiskUsage\Prod-DiskUsage-Temp.html"

[array]$trs=$null
[array]$trsabove20=$null
foreach($tr in $htmlresult)
{

  if( ($tr -like "*tr*") -and ($tr -notlike  "*DOCTYPE*") -and ($tr -notlike  "*serve*"))
  {    
     $percentnum=$null
     $TempTR=$tr.split('%')[0]
     $percentnum=$TempTR.substring($TempTR.length - 3).trim()

    if($percentnum -like "*>*")
     { #less than 10%
       $percentnum=$percentnum.Split('>')[1]
       [array]$trs+=$tr -replace "<td>$PercentNum %</td>","<td style='background-color:#FF8080'>$PercentNum %</td>"
     }
   else
     {   
        #great than 10% 
        if($PercentNum -le 20)
        {[array]$trs+=$tr -replace "<td>$PercentNum %</td>","<td style='background-color:#FF8080'>$PercentNum %</td>"}
        else
        {[array]$trsabove20+=$tr}  
     }

  }
  
}


#Merger less than 20 and more than 20%
$trs+=$trsabove20

$timestamp=(Get-Date).ToString()

$content='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">'
$content+='<html xmlns="http://www.w3.org/1999/xhtml">'
$content+='<head>'
$content+='<style>BODY{font-family: Segoe UI; font-size: 14px;}TABLE{border-width: 1px; border-style: solid; border-color: black; border-collapse: collapse;}TH{border-width: 2px; padding: 2px; border-style: solid; border-color: black;}TD{border-width: 1px; padding: 1px; border-style: solid; border-color: orange; white-space:nowrap;}</style>'
$content+='</head><body>'
$content+="<H2>Live-Disk-Report $timestamp --Refresh Daily</H2>"
$content+='<table>'
$content+='<colgroup><col/><col/><col/><col/><col/><col/></colgroup>'
$content+='<tr><th>Server Name</th><th>Team</th><th>Drive Letter</th><th>Total Capacity (GB)</th><th>Free Space (GB)</th><th>Free Space (%)</th></tr>'
$content+=$trs
$content+='</table>'
$content+='</body></html>'


$content | Set-Content "\\CNE1WSUS02\D$\e1awsinventory\html\diskreport-live.html"

"Content was uploaded to \\CNE1WSUS02\D$\e1awsinventory\html\diskreport-live.html"

#Remove temp files
Remove-Item  \\CNE1WSUS02\D$\DiskUsage\Prod-DiskUsage-Temp.html

#upload to s3 bucket
Write-S3Object -BucketName "e1aws-inventory.ef.com" -File "D:\e1awsinventory\html\diskreport-live.html" -ProfileName awsgbl -Region ap-southeast-1


#upload another report
Write-S3Object -BucketName "e1aws-inventory.ef.com" -File  "D:\e1awsinventory\html\OSLevelSecurity.xlsx" -ProfileName awsgbl -Region ap-southeast-1
Write-S3Object -BucketName "e1aws-inventory.ef.com" -File  "D:\e1awsinventory\html\E1SD_UserDetail.csv" -ProfileName awsgbl -Region ap-southeast-1
Write-S3Object -BucketName "e1aws-inventory.ef.com" -File  "D:\e1awsinventory\html\E1SD_Computerinfo.html"  -ProfileName awsgbl -Region ap-southeast-1



