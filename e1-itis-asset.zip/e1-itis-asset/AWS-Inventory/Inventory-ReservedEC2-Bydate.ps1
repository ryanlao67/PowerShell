﻿function ConvertPSObjectToHashtable
{
    param (
        [Parameter(ValueFromPipeline)]
        $InputObject
    )

    process
    {
        if ($null -eq $InputObject) { return $null }

        if ($InputObject -is [System.Collections.IEnumerable] -and $InputObject -isnot [string])
        {
            $collection = @(
                foreach ($object in $InputObject) { ConvertPSObjectToHashtable $object }
            )

            Write-Output -NoEnumerate $collection
        }
        elseif ($InputObject -is [psobject])
        {
            $hash = @{}

            foreach ($property in $InputObject.PSObject.Properties)
            {
                $hash[$property.Name] = ConvertPSObjectToHashtable $property.Value
            }

            $hash
        }
        else
        {
            $InputObject
        }
    }
}

Function GetHtmlLine($reserved, $instanceCount, $team)
{
	$html = “<tr>”;
	if($reserved.State -eq “active”)
	{
		$html = $($html + ”<td><img src=running.png height=16 width=16/></td>”);
	}
	else
	{
		$html = $($html + ”<td><img src=stopped.png height=16 width=16/></td>”);
	}

	$html = $($html + ”<td>” + $reserved.InstanceType + ”</td>”);

    $html = $($html + ”<td>” + $team + ”</td>”);

    if($instanceCount.getType().Name -eq "Hashtable")
    {

    	$html = $($html + ”<td>”);
    	if($instanceCount.ContainsKey("TotalPurchased"))
    	{ 
    		#$html = $($html + $instanceCount["TotalPurchased"]);
    	}
    	foreach($key in $instanceCount.Keys)
    	{
    		if($key -ne "TotalPurchased")
    		{
    			$html = $($html +　"<li>" + $key + ":" + $instanceCount[$key] + "</li>");
    		}
    	}
    	$html = $($html + ”</td>”);
    }
    else
    {
		$html = $($html + ”<td>” + $instanceCount + ”</td>”);
	}
	
    $html = $($html + ”<td>” + $reserved.End.ToString() + ”</td>”);
	$ts = New-TimeSpan -Seconds $reserved.Duration
	$html = $($html + ”<td>” + $ts.TotalDays.ToString() + ” days</td>”);
	$html = $($html + ”</tr>”);
	
	return $html;
}

$TeamsName = "TeamBI","TeamBSD","TeamGDM","TeamITIS","TeamPD","TeamSF"

$rsv1 =  Get-Content -Raw -Path "D:\e1awsinventory\scripts\ReservedInstances.json" | Out-String | ConvertFrom-Json

$rsv = ConvertPSObjectToHashtable $rsv1

$TeamHtml =  New-Object System.Collections.Hashtable
$TeamHtml.Add("TeamNull","")
foreach($team in $TeamsName)
{
    $TeamHtml.Add($team,"")
}

$mainHash = @{}
$regions = Get-AWSRegion -IncludeChina
$reservedList = @()

foreach($region in $regions)
{
   $profileName = "awsgbl";
   if($region.Region.StartsWith("cn-"))
   {
     $profileName = "awscn";
   }
	
   $reservedListByRegion = (Get-EC2ReservedInstance -ProfileName $profileName -Region $region.region)
   $reservedList += $reservedListByRegion

   foreach($reserved in $reservedListByRegion)
   {
        $instanceCount = $reserved.InstanceCount;

        if($instanceCount -gt 0)
        {
            if($mainHash.Item($reserved.Start.Date.ToString("yyyy-MM-dd")) -isnot [hashtable])
            {
                $mainHash.Item($reserved.Start.Date.ToString("yyyy-MM-dd")) = @{"Region" = @($region.Name); "RID" = @($reserved.ReservedInstancesId)};
            }
            else
            {
                $mainHash.Item($reserved.Start.Date.ToString("yyyy-MM-dd")).Item("Region") += $region.Name;
                $mainHash.Item($reserved.Start.Date.ToString("yyyy-MM-dd")).Item("RID") += $reserved.ReservedInstancesId;
            }

            #foreach($team in $TeamsName)
            #{
            #    if($rsv.Item($team).Item("ReservedInstancesID").ContainsKey($reserved.ReservedInstancesId))
            #    {
            #        $rsvId = $rsv.Item($team).Item("ReservedInstancesID").Item($reserved.ReservedInstancesId)
            #        $instanceCount -= $rsvId.Item("TotalPurchased");
            #        $htmlLine = GetHtmlLine $reserved $rsvId $region;
            #        $TeamHtml.Item($team) = $($TeamHtml.Item($team) + $htmlLine);
            #        #$htmlLine
            #    }
            #}
            #if($instanceCount -gt 0)
            #{
            #	$htmlLine = GetHtmlLine $reserved $instanceCount $region;
            #    $TeamHtml.Item("TeamNull") = $($TeamHtml.Item("TeamNull") + $htmlLine);
            #}
            ##$TeamHtml
        }
    }
}

$html = $("<html><body>Last Updated (UTC) - " + (Get-Date).ToUniversalTime() + "<table border=1 width=100%>");

foreach($rDate in $mainHash.GetEnumerator() | Sort Name -Descending)
{
    $html =  $($html + "<tr bgcolor=silver><td colspan=6><b>" + $rDate.Name + "</b></td></tr>");
    
    $rIDs = $mainHash.Item($rDate.Name).Item("RID")
    $rRegions = $mainHash.Item($rDate.Name).Item("Region")
    
    for ($i=0; $i -lt $rIDs.Count; $i++)
    {
        $rInfo = $reservedList | Where-Object {$_.ReservedInstancesId -eq $rIDs[$i]}
        $html =  $($html + "<tr bgcolor=Beige><td colspan=2><b>RID: " + $rIDs[$i] + "</b></td><td><b>" + $rRegions[$i] + "</b></td><td><b>Instance Count: " + $rInfo.InstanceCount.ToString() + "</b></td><td><b>Upfront Price: " + $rInfo.CurrencyCode.Value + " " + $rInfo.FixedPrice.ToString() + "</b></td><td><b>Usage Price: " + $rInfo.CurrencyCode.Value + " " + $rInfo.UsagePrice.ToString() +  "</b></td></tr>");
        $html =  $($html + "<tr><td></td><td><b>Instance Type</b></td><td><b>Team</b></td><td><b>Details</b></td><td><b>Expiry Date</b></td><td><b>Term</b></td></tr>")
        $instanceCount = $rInfo.InstanceCount;
        foreach($team in $TeamsName)
        {
            if($rsv.Item($team).Item("ReservedInstancesID").ContainsKey($rIDs[$i]))
            {
              $rsvId = $rsv.Item($team).Item("ReservedInstancesID").Item($rIDs[$i])
              $instanceCount -= $rsvId.Item("TotalPurchased");
              $htmlLine = GetHtmlLine $rInfo $rsvId $team;
              $html =  $($html + $htmlLine)
            }
        }
        if($instanceCount -gt 0)
        {
           	$htmlLine = GetHtmlLine $rInfo @{} "TeamNull";
            $html =  $($html + $htmlLine)
        }
    }
}

$html =  $($html + "</table></body></html>");

$html | Set-Content 'D:\e1awsinventory\html\reserved-ec2-by-date.html';

Write-S3Object -BucketName "e1aws-inventory.ef.com" -File "D:\e1awsinventory\html\reserved-ec2-by-date.html" -ProfileName awsgbl -Region ap-southeast-1