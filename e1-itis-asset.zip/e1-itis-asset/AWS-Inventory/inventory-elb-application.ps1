$awsRegions = Get-AWSRegion -IncludeChina
$teamNULL_PROD = $NULL
$teamBI_PROD = $NULL
$teamODIN_PROD = $NULL
$teamOMNI_PROD = $NULL
$teamEFP_PROD = $NULL
$teamSIS_PROD = $NULL
$teamGDM_PROD = $NULL
$teamITIS_PROD = $NULL
$teamPD_PROD = $NULL
$teamSF_PROD = $NULL

Foreach($awsRegion in $awsRegions.Region)
{
    If($awsRegion.StartsWith("ap-southeast-1"))
    {
        $awsProfile = "awsgbl";  
    }
    Elseif($awsRegion.StartsWith("cn-"))
    {
        $awsProfile = "awscn";
    }
    Else
    {
        Continue
    }

    $albs = Get-ELB2LoadBalancer -ProfileName $awsProfile -Region $awsRegion

    $htmlLine = ""
    Foreach($alb in $albs)
    {
        $albArn = $alb.LoadBalancerArn
        $albName = $alb.LoadBalancerName
        $albTargetGroups = Get-ELB2TargetGroup -LoadBalancerArn $albArn -ProfileName $awsProfile -Region $awsRegion
        $htmlLine = $("<tr bgcolor=Beige><td colspan=2>" + $alb.DNSName + "</td><td>" + $alb.Scheme + "</td></tr>")
        Foreach ($albTargetGroup in $albTargetGroups)
        {
            $albTGArn = $albTargetGroup.TargetGroupARN
            $htmlLine = $($htmlLine + "<tr><td colspan=2>" + $albTargetGroup.TargetGroupName + "</td>" + `
                "<td>" + $albTargetGroup.Port + "</td></tr>")
            $albTGInsts = Get-ELB2TargetHealth -TargetGroupArn $albTGArn -ProfileName $awsProfile -Region $awsRegion
            Foreach($albTGInst in $albTGInsts)
            {
                $albTGInstance = $albTGInst.Target.Id
                If($albTGInstance.StartsWith("i-"))
                {
                    $ec2Inst = (Get-EC2Instance -InstanceId $albTGInstance -ProfileName $awsProfile -Region $awsRegion).Instances
                }
                Else
                {
                    $ec2Inst = (Get-EC2Instance -Filter @{Name="private-ip-address";Value=$albTGInstance} -ProfileName $awsProfile -Region $awsRegion).Instances
                }
                $ec2Name = ($ec2Inst.Tags | Where {$_.Key -ieq 'Name'}).Value
                $ec2PrivateIP = $ec2Inst.PrivateIpAddress
                If($albTGInst.TargetHealth.State.Value -eq "healthy")
                {
                    $htmlLine = $($htmlLine + "<tr><td><img src=running.png height=16 width=16 /></td>" + `
                    "<td>" + $ec2Name + "</td>" + `
                    "<td>" + $ec2PrivateIP + "</td>")
                }
                Else
                {
                    $htmlLine = $($htmlLine + "<tr><td><img src=stopped.png height=16 width=16 /></td>" + `
                    "<td>" + $ec2Name + "</td>" + `
                    "<td>" + $ec2PrivateIP + "</td>")
                }
            }
        }

        $env = $NULL
        $team = $NULL
        $subteam = $NULL

        $tagKeys = @("ENV", "SUBTEAM", "TEAM");
        $tags = ((Get-ELB2Tag -ResourceArn $albArn -ProfileName $awsProfile -Region $awsRegion).Tags | Where-Object {$_.Key -in $tagKeys})
        If($tags.Count -ge 2)
        {
            $tags = $tags | Sort-Object @{Expression={$_.Key}; Ascending=$true}
            $env = $tags[0].Value
            If($tags.Count -eq 3)
            {
                $subteam = $tags[1].Value
                $team = $tags[2].Value
            }
            Else
            {
                $team = $tags[1].Value
            }
        }
        If($team -ne "BI" -and $team -ne "BSD" -and $team -ne "GDM" -and $team -ne "PD" -and $team -ne "SF" -and $team -ne "ODIN" -and $team -ne "OMNI" -and $team -ne "EFP" -and $team -ne "SIS")
        {
            $team = "ITIS"
        }
        
        $tagKeys = @("ENV", "TEAM");
        $tags = ((Get-ELB2Tag -ResourceArn $albArn -ProfileName $awsProfile -Region $awsRegion).Tags | Where-Object {$_.Key -in $tagKeys})
        If($tags.Count -eq 2)
        {
            $tags = $tags | Sort-Object @{Expression={$_.Key}; Ascending=$true}
            If($tags[0].Value -eq "PRD")
            {
                If($tags[1].Value -eq "BI")
                {
                    $teamBI_PROD = $($teamBI_PROD + $htmlLine);
                }
                Elseif($tags[1].Value -eq "BSD")
                {
                    $teamBSD_PROD = $($teamBSD_PROD + $htmlLine);
                }
                Elseif($tags[1].Value -eq "GDM")
                {
                    $teamGDM_PROD = $($teamGDM_PROD + $htmlLine);
                }
                Elseif($tags[1].Value -eq "ITIS")
                {
                    $teamITIS_PROD = $($teamITIS_PROD + $htmlLine);
                }
                Elseif($tags[1].Value -eq "PD")
                {
                    $teamPD_PROD = $($teamPD_PROD + $htmlLine);
                }
                Elseif($tags[1].Value -eq "SF")
                {
                    $teamSF_PROD = $($teamSF_PROD + $htmlLine);
                }
                Elseif($tags[1].Value -eq "ODIN")
                {
                    $teamODIN_PROD = $($teamODIN_PROD + $htmlLine);
                }
                Elseif($tags[1].Value -eq "OMNI")
                {
                    $teamOMNI_PROD = $($teamOMNI_PROD + $htmlLine);
                }
                Elseif($tags[1].Value -eq "EFP")
                {
                    $teamEFP_PROD = $($teamEFP_PROD + $htmlLine);
                }
                Elseif($tags[1].Value -eq "SIS")
                {
                    $teamSIS_PROD = $($teamSIS_PROD + $htmlLine);
                }
                Else
                {
                    $teamNULL_PROD = $($teamNULL_PROD + $htmlLine);
                }
            }
        }
    }
}


# Inventory Format
$htmlFormat = "<style>"
$htmlFormat = $htmlFormat + "BODY{font-family: Sans-serif; font-size: 15px;}"
$htmlFormat = $htmlFormat + "TABLE{border-width: 2px; border-style: solid; border-color: black; border-collapse: collapse; width: 100%;}"
$htmlFormat = $htmlFormat + "TH{border-width: 2px; padding: 2px; border-style: solid; border-color: black;}"
$htmlFormat = $htmlFormat + "TD{border-width: 2px; padding: 2px; border-style: solid; border-color: orange; white-space:nowrap;}"
$htmlFormat = $htmlFormat + "</style>"

$html = $("<html>" + $htmlFormat + "<body>Last Updated (UTC) - " + (Get-Date).ToUniversalTime() + "<table border=2 width=100%>")

If($teamNULL_PROD.Length -gt 0)
{
    $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM NULL</b>" + "</td></tr>")
    $html =  $($html + $teamNULL_PROD + "<tr></tr>")
}
If($teamBI_PROD.Length -gt 0)
{
    $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM BI</b>" + "</td></tr>")
    $html =  $($html + $teamBI_PROD + "<tr></tr>")
}
If($teamBSD_PROD.Length -gt 0)
{
    $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM BSD</b>" + "</td></tr>")
    $html =  $($html + $teamBSD_PROD + "<tr></tr>")
}
If($teamGDM_PROD.Length -gt 0)
{
    $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM GDM</b>" + "</td></tr>")
    $html =  $($html + $teamGDM_PROD + "<tr></tr>")
}
If($teamITIS_PROD.Length -gt 0)
{
    $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM ITIS</b>" + "</td></tr>")
    $html =  $($html + $teamITIS_PROD + "<tr></tr>")
}
If($teamPD_PROD.Length -gt 0)
{
    $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM PD</b>" + "</td></tr>")
    $html =  $($html + $teamPD_PROD + "<tr></tr>")
}
If($teamSF_PROD.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM SALESFORCE</b>" + "</td></tr>")
  $html =  $($html + $teamSF_PROD + "<tr></tr>")
}
If($teamODIN_PROD.Length -gt 0)
{
    $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM ODIN</b>" + "</td></tr>")
    $html =  $($html + $teamODIN_PROD + "<tr></tr>")
}
If($teamOMNI_PROD.Length -gt 0)
{
    $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM OMNI</b>" + "</td></tr>")
    $html =  $($html + $teamOMNI_PROD + "<tr></tr>")
}
If($teamEFP_PROD.Length -gt 0)
{
    $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM EFP</b>" + "</td></tr>")
    $html =  $($html + $teamEFP_PROD + "<tr></tr>")
}
If($teamSIS_PROD.Length -gt 0)
{
  $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM SIS</b>" + "</td></tr>")
  $html =  $($html + $teamSIS_PROD + "<tr></tr>")
}
$html =  $($html + "</table></body></html>")

$html | Set-Content "D:\e1awsinventory\html\albinventory.html"

Write-S3Object -BucketName "e1aws-inventory.ef.com" -File "D:\e1awsinventory\html\albinventory.html" -ProfileName awsgbl -Region ap-southeast-1