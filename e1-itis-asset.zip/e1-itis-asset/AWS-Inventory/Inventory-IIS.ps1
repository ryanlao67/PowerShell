﻿param(
[string]$ServerNameORServerlist=""
)

if($ServerNameORServerlist -like "*txt*")
   {[array]$list=gc $ServerNameORServerlist}
else
   {[array]$list=Get-ADComputer -Filter * -Properties Name | select -ExpandProperty name}


$scripts={

[array]$websites=$null
[array]$websites=get-website 
[array]$outputs=$null
foreach($website in $websites)
{

  $sitename=$website.name
  $siteID=$website.ID
  $PhysicalPath=$website.PhysicalPath

  #$state=$websites.state

  [int]$bindingsAmount=$website.bindings.collection.count
  [array]$allbindings=$website.bindings.collection
  
  if($bindingsAmount -le 1)
   {
    $BindingsProtocol=$website.bindings.collection.protocol
    $BindingPort=$website.bindings.collection.Bindinginformation
    $bindings=$BindingsProtocol+" "+$BindingPort
  }

  else{
          [string]$bindings=$null
          foreach($binding in $allbindings)
          {
              $BindingsProtocol=$binding.protocol
              $BindingPort=$binding.Bindinginformation
              [string]$bindings+=$BindingsProtocol+" "+$BindingPort+"`n"         
          
          }
  
  
    }

  $LogLocation=$website.logfile.directory
  $AppPool=$website.applicationpool

  $MaxConnection=$website.limits.maxconnections
  $MaxBandWidth=$("{0:N0}" -f ($website.limits.maxbandwidth/1MB))+"MB/Sec"

  $ConnectionTimeOut=$website.limits.connectionTimeOut

  $output = New-Object psobject
  $output | Add-Member NoteProperty "Servername"         $env:COMPUTERNAME
  $output | Add-Member NoteProperty "SiteName"           $sitename
  #$output | Add-Member NoteProperty "SiteStatus"        $state
  $output | Add-Member NoteProperty "SiteID"             $siteID
  $output | Add-Member NoteProperty "Bindings"           $Bindings
  $output | Add-Member NoteProperty "PhysicalPath"       $PhysicalPath
  $output | Add-Member NoteProperty "LogPath"            $LogLocation
  $output | Add-Member NoteProperty "AppPool"            $AppPool
  $output | Add-Member NoteProperty "MaxConnection"      $MaxConnection
  $output | Add-Member NoteProperty "MaxBandWidth"       $MaxBandWidth
  $output | Add-Member NoteProperty "ConnectionTimeOut"  $ConnectionTimeOut
 
 [array]$outputs+=$output 

}

$outputs 


}


[array]$failedservers=$null
[array]$totalResult=$null
Foreach ($srv in $list)
{  
   $singleResult=$null     
   try{           
         $singleResult=icm -ComputerName $srv -ErrorAction stop  -ScriptBlock  $scripts  -HideComputerName
       }
   catch
       {
       "$srv connect failed"
        $failedservers+=$srv 
        }
   $singleResult  
   $totalResult+=$singleResult
 }
  
#Output the failed servers
if($failedservers)
{

 Write-Warning "Below server failed to connect,you can find them from your desktop\failedservers.txt"
 $failedservers
 $timestamp=(get-date).ToString('yyyyMMdd_hhmmss')
 $failedServerFilename="FailedConnectedServer"+"_"+$timestamp+".txt"
 $failedservers | out-file $home\desktop\$failedServerFilename
}

#Define the filename
$domainname=$env:USERDNSDOMAIN
$Reportname=$domainname+"_"+"IIS.html"

#output the finally Report
#Inventory Format
$htmlFormat = "<style>"
$htmlFormat = $htmlFormat + "BODY{font-family: Segoe UI; font-size: 14px;}"
$htmlFormat = $htmlFormat + "TABLE{border-width: 1px; border-style: solid; border-color: black; border-collapse: collapse;}"
$htmlFormat = $htmlFormat + "TH{border-width: 2px; padding: 2px; border-style: solid; border-color: black;}"
$htmlFormat = $htmlFormat + "TD{border-width: 1px; padding: 1px; border-style: solid; border-color: orange; white-space:nowrap;}"
$htmlFormat = $htmlFormat + "</style>"

Remove-item -force D:\e1awsinventory\html\$Reportname

$Refreshtime=$(get-date)
$finanllyResult=$null
$finanllyResult=$totalResult | select servername,sitename,siteID,bindings,physicalpath,appPool,MaxConnection,MaxbandWidth,ConnectionTimeOut | sort servername  | ConvertTo-Html -Body "<H2>$domainname IIS Website Information -Update at $Refreshtime </H2>"  -Head $htmlFormat
$finanllyResult | Set-Content D:\e1awsinventory\html\$Reportname

#upload to s3
Write-S3Object -BucketName "e1aws-inventory.ef.com" -File D:\e1awsinventory\html\$Reportname  -ProfileName awsgbl -Region ap-southeast-1

