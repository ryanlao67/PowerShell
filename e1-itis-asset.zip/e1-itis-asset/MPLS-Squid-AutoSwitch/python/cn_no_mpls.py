from SquidSwitch.SquidSwitchController import SquidSwitchController as SSC

if __name__ == "__main__":
    SSC().switch_to_squid_no_mpls()
