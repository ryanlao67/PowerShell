# -*- encoding:utf-8 -*-
# CustomizedNetworkUtils.py
# Using for handling fundamental actions toward dns/network checking.
#
# ver-0.0.1, 2017/03/29, Author: bob.yeh@ef.com
# First init.
# Todo: Since pyping will require the root privileges either on Win or Linux/Ubuntu, still figure out how to solve this.

import socket
import requests

class CustomizedNetworkUtils:

    @staticmethod
    def get_dns_availability(domain):
        ret = 0
        try:
            lookup = socket.gethostbyname(domain)
            if lookup is not None:
                ret = 1
        except:
            pass
        return ret

    @staticmethod
    def head_url_latency(url,proxy=None):
        ret = -1
        try:
            ret = requests.head(url,proxies=proxy).elapsed.total_seconds()
        except:
            pass
        return ret

    @staticmethod
    def get_url_latency(url,proxy=None):
        ret = -1
        try:
            ret = requests.get(url,proxies=proxy).elapsed.total_seconds()
        except:
            pass
        return ret
