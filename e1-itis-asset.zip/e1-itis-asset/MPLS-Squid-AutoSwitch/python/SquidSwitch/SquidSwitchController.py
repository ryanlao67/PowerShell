# -*- encoding:utf-8 -*-
# SquidSwitchController.py
# Using for handling fundamental actions toward dns/network checking.
#
# ver-0.0.1, 2017/03/29, Author: bob.yeh@ef.com
# First init.
# Note: Clone from previous CNU
#
# ver-0.0.2, 2017/04/11, Author: bob.yeh@ef.com
# Append new trigger point with run()

import subprocess
import time
from CustomizedNetworkUtils import CustomizedNetworkUtils as CNU

_sudo = "sudo"
_kill = "kill"
_killall = "killall"
_squid = "squid"
_pgrep = "pgrep"
_squid_exec = "/usr/local/squid/sbin/squid" 
_f = "-f"
_9 = "-9"
_config_mpls = "/usr/local/squid/etc/squid4-mpls.conf"
_config_no_mpls = "/usr/local/squid/etc/squid4-no-mpls.conf"
_config_sg = "/usr/local/squid/etc/squid4.conf"
_sf_host = 'ap1.salesforce.com'
_sleep = 5


class SquidSwitchController():

    def __init__(self):
        return

    def check_squid_mpls_running(self):
        ret = False
        if self.get_pid_squid_mpls() is not None:
            ret = True
        return ret

    def check_squid_no_mpls_running(self):
        ret = False
        if self.get_pid_squid_no_mpls() is not None:
            ret = True
        return ret

    def check_squid_sg_running(self):
        ret = False
        if self.get_pid_squid_sg() is not None:
            ret = True
        return ret

    def run_squid_mpls(self):
        return self.run_squid_config(_config_mpls)

    def run_squid_no_mpls(self):
        return self.run_squid_config(_config_no_mpls)

    def run_squid_sg(self):
        return self.run_squid_config(_config_sg)

    def run_squid_config(self, config_file=None):
        ret = False
        if config_file is None:
            return ret
        try:
            subprocess.call([_sudo, _squid_exec, _f, config_file])
            ret = True
        except Exception as e:
            print str(e)
            pass
        return ret

    def kill_squid_mpls(self):
        return self.kill_squid_pid(self.get_pid_squid_mpls())

    def kill_squid_no_mpls(self):
        return self.kill_squid_pid(self.get_pid_squid_no_mpls())

    def kill_squid_sg(self):
        return self.kill_squid_pid(self.get_pid_squid_sg())

    def kill_squid_pid(self, pid):        
        ret = False
        try:
            if pid and subprocess.call([_sudo, _kill, _9, pid]) == 0:
                ret = True
        except Exception as e:
            print str(e)
            pass
        return ret

    def killall_squid(self):
        ret = False
        try:
            if subprocess.call([_sudo, _killall, _9, _squid]) == 0:
                ret = True
        except Exception as e:
            print str(e)
            pass
        return ret

    def get_pid_squid_mpls(self):
        pid = None
        try:
            pid = subprocess.check_output([_pgrep, _f, "{0} {1} {2}".format(_squid_exec,_f,_config_mpls)])
            pid = pid.replace('\n', '')
        except Exception as e:
            print str(e)
            pass
        return pid

    def get_pid_squid_no_mpls(self):
        pid = None
        try:
            pid = subprocess.check_output([_pgrep, _f, "{0} {1} {2}".format(_squid_exec,_f,_config_no_mpls)])
            pid = pid.replace('\n', '')
        except Exception as e:
            print str(e)
            pass
        return pid

    def get_pid_squid_sg(self):
        pid = None
        try:
            pid = subprocess.check_output([_pgrep, _f, "{0} {1} {2}".format(_squid_exec,_f,_config_sg)])
            pid = pid.replace('\n', '')
        except Exception as e:
            print str(e)
            pass
        return pid

    def squid_switch_controller(self):
        sf_available = CNU.get_dns_availability(_sf_host)
        if not sf_available:
            return self.switch_to_squid_mpls()
        else:
            return self.switch_to_squid_no_mpls()

    def switch_to_squid_mpls(self):
        ret = False
        retry_cnt = 0
        while self.check_squid_no_mpls_running():
            self.kill_squid_no_mpls()
            self.killall_squid()
            retry_cnt += 1
            if retry_cnt >= 5:
                return ret
            time.sleep(_sleep)

        retry_cnt = 0
        while not self.check_squid_mpls_running():
            ret = self.run_squid_mpls()
            time.sleep(_sleep)
            retry_cnt += 1
            if retry_cnt >= 5:
                return ret
        return ret

    def switch_to_squid_no_mpls(self):
        ret = False
        retry_cnt = 0
        while self.check_squid_mpls_running():
            self.kill_squid_mpls()
            self.killall_squid()
            retry_cnt += 1
            if retry_cnt >= 5:
                return ret
            time.sleep(_sleep)

        retry_cnt = 0
        while not self.check_squid_no_mpls_running():
            ret = self.run_squid_no_mpls()
            time.sleep(_sleep)
            retry_cnt += 1
            if retry_cnt >= 5:
                return ret
        return ret

    def squid_sg_reload(self):
        ret = False
        if self.check_squid_sg_running():
            self.kill_squid_sg()
            time.sleep(_sleep)

        self.killall_squid()
        ret = self.run_squid_sg()

        return ret

    def run(self):
        return self.squid_switch_controller()
