# -*- encoding:utf-8 -*-
# CustomizedNetworkUtils.py
# Using for handling fundamental actions toward dns/network checking.
#
# ver-0.0.1, 2017/04/10, Author: bob.yeh@ef.com
# append all the necessary testcases for SSC
#
# ver-0.0.2, 2017/04/12, Author: bob.yeh@ef.como
# append new Mock/MagicMock/patch for testing

import unittest
import subprocess
from mock import Mock, MagicMock, patch

_sudo = "sudo"
_kill = "kill"
_killall = "killall"
_squid = "squid"
_pgrep = "pgrep"
_squid_exec = "/usr/local/squid/sbin/squid" 
_f = "-f"
_config_mpls = "/usr/local/squid/etc/squid4-mpls.conf"
_config_no_mpls = "/usr/local/squid/etc/squid4-no-mpls.conf"
_sf_host = 'ap1.salesforce.com'

class TestSquidSwitchController(unittest.TestCase):

    def test_check_squid_no_mpls_running(self):
        from SquidSwitch import SquidSwitchController 
        self.ssc = SquidSwitchController.SquidSwitchController()
        self.ssc.get_pid_squid_no_mpls = MagicMock(return_value=None)
        self.assertIsNone(self.ssc.get_pid_squid_mpls())
        self.assertFalse(self.ssc.check_squid_no_mpls_running(), msg=self.ssc.get_pid_squid_no_mpls()) 

        self.ssc.get_pid_squid_no_mpls = MagicMock(return_value=123)
        self.assertTrue(self.ssc.check_squid_no_mpls_running(), msg=self.ssc.get_pid_squid_no_mpls())

    def test_check_squid_mpls_running(self):
        from SquidSwitch import SquidSwitchController
        self.ssc = SquidSwitchController.SquidSwitchController()
        self.ssc.get_pid_squid_mpls = MagicMock(return_value=None)
        self.assertFalse(self.ssc.check_squid_mpls_running(), msg=self.ssc.get_pid_squid_mpls())

        self.ssc.get_pid_squid_mpls = MagicMock(return_value=123)
        self.assertTrue(self.ssc.check_squid_mpls_running(), msg=self.ssc.get_pid_squid_mpls())

    def test_run_squid_s(self):
        from SquidSwitch import SquidSwitchController
        self.ssc = SquidSwitchController.SquidSwitchController()
        self.ssc.run_squid_config = MagicMock(return_value=True)
        self.assertTrue(self.ssc.run_squid_mpls())
        self.assertTrue(self.ssc.run_squid_no_mpls())

        self.ssc.run_squid_config = MagicMock(return_value=False)
        self.assertFalse(self.ssc.run_squid_mpls())
        self.assertFalse(self.ssc.run_squid_no_mpls())

    def test_run_squid_config(self):
        with patch("subprocess.call") as scall:
            scall = MagicMock(return_value=True)
            from SquidSwitch import SquidSwitchController
            self.ssc = SquidSwitchController.SquidSwitchController()
            self.assertTrue(self.ssc.run_squid_config(_config_no_mpls))
            self.assertTrue(self.ssc.run_squid_config(_config_mpls))
            self.assertFalse(self.ssc.run_squid_config(None))

    def test_kill_squid_s(self):
        from SquidSwitch import SquidSwitchController
        self.ssc = SquidSwitchController.SquidSwitchController()
        self.ssc.kill_squid_pid = MagicMock(return_value=True)
        self.assertTrue(self.ssc.kill_squid_mpls())
        self.assertTrue(self.ssc.kill_squid_no_mpls())

        self.ssc.kill_squid_pid = MagicMock(return_value=False)
        self.assertFalse(self.ssc.kill_squid_mpls())
        self.assertFalse(self.ssc.kill_squid_no_mpls())

   
    def test_switch_to_squid_mpls(self):
        with patch("SquidSwitch.SquidSwitchController.time.sleep") as scall:
            scall = MagicMock(return_value=None)
            from SquidSwitch import SquidSwitchController
            self.ssc = SquidSwitchController.SquidSwitchController()
            self.ssc.check_squid_no_mpls_running = MagicMock(return_value=True)
            self.ssc.check_squid_mpls_running = MagicMock(return_value=False)
            self.assertFalse(self.ssc.switch_to_squid_mpls())

            self.ssc.check_squid_no_mpls_running = MagicMock(return_value=False)
            self.ssc.check_squid_mpls_running = MagicMock(return_value=False)
            self.assertFalse(self.ssc.switch_to_squid_mpls())
            self.ssc.run_squid_mpls = MagicMock(return_value=True)
            self.assertTrue(self.ssc.switch_to_squid_mpls())

    def test_switch_to_squid_no_mpls(self):
        with patch("SquidSwitch.SquidSwitchController.time.sleep") as scall:
            scall = MagicMock(return_value=None)
            from SquidSwitch import SquidSwitchController
            self.ssc = SquidSwitchController.SquidSwitchController()
            self.ssc.check_squid_mpls_running = MagicMock(return_value=True)
            self.assertFalse(self.ssc.switch_to_squid_no_mpls())

            self.ssc.check_squid_mpls_running = MagicMock(return_value=False)
            self.ssc.check_squid_no_mpls_running = MagicMock(return_value=False)
            self.assertFalse(self.ssc.check_squid_no_mpls_running())
            self.assertFalse(self.ssc.switch_to_squid_no_mpls())
            self.ssc.run_squid_no_mpls = MagicMock(return_value=True)
            self.assertTrue(self.ssc.switch_to_squid_no_mpls(),msg=self.ssc.run_squid_mpls())

    def test_squid_sg_reload(self):
        with patch("SquidSwitch.SquidSwitchController.time.sleep") as scall:
            scall = MagicMock(return_value=None)
            from SquidSwitch import SquidSwitchController
            self.ssc = SquidSwitchController.SquidSwitchController()
            self.ssc.check_squid_sg_running = MagicMock(return_value=False)
            self.ssc.run_squid_sg = MagicMock(return_value=True)
            self.assertTrue(self.ssc.squid_sg_reload(),msg=self.ssc.run_squid_mpls())
            self.ssc.check_squid_sg_running = MagicMock(return_value=True)
            self.assertTrue(self.ssc.squid_sg_reload(),msg=self.ssc.run_squid_mpls())
