import requests
import sys

def check_domain(proto,domain):
    ret = False
    try:
        requests.get(proto+"://"+domain, timeout=10)
        print proto+"://"+domain+" available"
        ret = True
    except:
        print proto+"://"+domain+" unavailable"
        pass

    return ret


if __name__ == "__main__":
    if len(sys.argv) == 2 and "ef" in sys.argv[1]:
        http = check_domain("http",sys.argv[1])
        https = check_domain("https",sys.argv[1])
        print ">",sys.argv[1],http,https
