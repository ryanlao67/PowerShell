import requests
import sys

def check_domain(proto,domain):
    ret = False
    try:
        requests.get(proto+"://"+domain)
        print proto + "://"+domain+" available"
        ret = True
    except:
        print proto + "://"+domain+" unavailable"
        pass

    return ret

def check_redirect(domain):
    ret = False
    try:
        res = requests.get("http://" + domain)
        if len(res.history) > 0:
            if 'Location' in res.history[0].headers and 'https' in res.history[0].headers['Location']:
                ret = True
    except:
        pass
    if ret:
        print "auto redirect to https"
    return ret

if __name__ == "__main__":
    if len(sys.argv) == 2 and "ef" in sys.argv[1]:
        domain = sys.argv[1]
        http = check_domain("http",domain)
        https = check_domain("https",domain)
        redirect = check_redirect(domain)
        print ">",sys.argv[1],http,https,redirect
