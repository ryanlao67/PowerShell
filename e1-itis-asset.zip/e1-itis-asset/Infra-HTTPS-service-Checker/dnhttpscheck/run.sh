 cat newdns.list | awk '{system("python http_https_check.py "$1)}'  2> /dev/null 
