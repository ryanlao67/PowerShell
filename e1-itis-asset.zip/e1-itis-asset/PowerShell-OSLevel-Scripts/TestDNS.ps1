Param (
    [Parameter(Mandatory = $True, Position = 0)]
    [string] $dnsList,

    [Parameter(Mandatory = $True, Position = 1)]
    [string] $resultFolder
)

While ($True)
{
    Get-Content $dnsList | Foreach-Object{
        $scriptBlock = {
            param($dnsName)
            $infoLog = "$resultFolder\$dnsName.txt"
            Try 
            {
                $rslv = (Measure-Command{Resolve-DnsName $dnsName -ErrorAction Stop}).TotalMilliseconds
            }
            Catch
            {
                $rslvFail = $Error[0].Exception
            }
            $curTime = (Get-Date).ToString("yyyyMMddhhmmss")
            If ($rslv -eq $NULL)
            {
                $curTime + ": " + $rslvFail | Out-File -filepath $infoLog -Append
            }
            Elseif ($rslv -ge 5000)
            {
                $curTime + ": $dnsName cannot be resolved after " + $rslv + "5s" | Out-File -filepath $infoLog -Append
            }
            Else{
                $curTime + ": $dnsName can be resolved in " + $rslv + "ms" | Out-File -filepath $infoLog -Append
            }
        }
        Start-Job $scriptBlock -ArgumentList $_ | Out-Null
    }
    Start-Sleep 300
}