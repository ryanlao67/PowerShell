# Enable userdata setting in EC2Config
If (Get-Service EC2Config)
{
    $ec2Config = Get-Content "C:\Program Files\Amazon\Ec2ConfigService\Settings\config.xml"
    $ec2Config[41] = $ec2Config[41].Replace($ec2Config[41], "      <State>Enabled</State>")
    Set-Content "C:\Program Files\Amazon\Ec2ConfigService\Settings\config.xml" $ec2Config
}

# Setup local account
$Computername = $env:COMPUTERNAME
$ADSIComp = [adsi]"WinNT://$Computername" 
$Username = 'itisadmin'
$NewUser = $ADSIComp.Create('User',$Username)
$Password = '' | ConvertTo-SecureString -asPlainText -Force
$BSTR = [system.runtime.interopservices.marshal]::SecureStringToBSTR($Password)
$_password = [system.runtime.interopservices.marshal]::PtrToStringAuto($BSTR)
$NewUser.SetPassword(($_password))
$NewUser.SetInfo()
[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($BSTR) 
Remove-Variable Password,BSTR,_password
$userGroup = 'Administrators'
$group = [ADSI]"WinNT://$env:COMPUTERNAME/$userGroup,group"
$group.Add("WinNT://$env:COMPUTERNAME/$UserName,user")
$User = [adsi]"WinNT://$env:computername/$Username"
$User.UserFlags.value = $user.UserFlags.value -bor 0x10000
$User.CommitChanges

# Enable PowerShell remoting
winrm quickconfig | Out-Null
Set-Item -Path WSMan:\localhost\Client\TrustedHosts -Value * -Force
New-NetFirewallRule -Group 'EF' -DisplayName "PowerShell Remoting" -Action Allow -Description "Remote Access PowerShell" -Direction Inbound -Enabled True -LocalPort 5985 -Profile Any -Protocol TCP | Out-Null