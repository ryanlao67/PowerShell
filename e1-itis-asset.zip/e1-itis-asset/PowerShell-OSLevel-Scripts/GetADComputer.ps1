﻿# Get some computer information from AD like OS Version ,when the computer created, computer account last logonDate ,IP Address,Computer SID
# Pre-condition to running this script
# The server must be able to talk with Domain Control Port:9389
# The server mush have Powershell AD moudule installed



Get-ADComputer -Filter * -Properties Name,OperatingSystem,OperatingSystemVersion,Created,PasswordLastSet,LastLogonDate,IPv4Address,PrimaryGroup,SID |`
select Name,OperatingSystem,OperatingSystemVersion,Created,PasswordLastSet,LastLogonDate,IPv4Address,@{Name="OU";expression={$_.DistinguishedName.split(',')[1].split('=')[1]}},SID |`
Export-Csv -Path $home\desktop\ComputerInfo.csv -NoTypeInformation


write-host "=======Result ComputerInfo.CSV was dropped on your Desktop========" -ForegroundColor Green


                            

 
 

