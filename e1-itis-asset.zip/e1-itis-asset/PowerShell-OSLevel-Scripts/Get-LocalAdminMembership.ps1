Param(
    [Parameter(Mandatory = $True, Position = 0)]
    [string] $serverList
)

$scriptBlock = {
    $serverName = $env:COMPUTERNAME
    $adsiComputer = [ADSI]("WinNT://$serverName,computer")
    $group = $adsiComputer.psbase.children.find('Administrators', 'Group')
    $membership = $group.psbase.invoke("members")  | Foreach {
        $_.GetType().InvokeMember("Name", 'GetProperty', $null, $_, $null) | `
            Where {$_ -ne 'Administrator' -and $_ -ne 'Domain Admins' -and $_ -notmatch 'E1_'}
    }
    $memList = $membership -Join ','
    Write-Host $serverName','$memList
}

Foreach($tgtServer in Get-Content $serverList)
{
    Invoke-Command -ComputerName $tgtServer -ScriptBlock $scriptBlock
}