#Confirm centralized server
$domName = (Get-WmiObject -Class WIN32_ComputerSystem).Domain

Switch ($domName)
{
    E1EF.COM {$srcSrv = "10.163.25.64"}
    E1SD.COM {$srcSrv = "10.160.114.146"}
}

#Configuration file
$configFile = "\\$srcSrv\scripts\GroupPolicy\Local_Account\Local_Account.json"

$config = Get-Content -Raw -Path $configFile | out-string | ConvertFrom-Json

#Confirm server owner
If(Test-Path "C:\DBServer.txt")
{
    $ec2TagDB = 'Yes'
}

If(Test-Path "C:\ServerOwner.txt")
{
    $teamTag = Get-Content "C:\ServerOwner.txt"
    Switch ($teamTag)
    {
        ITIS {$teamAccount = $config.localcred.itis; $teamDomAct="E1_ITIS"}
        BI {$teamAccount = $config.localcred.bi; $teamDomAct="E1_BI"}
        BSD {$teamAccount = $config.localcred.bsd; $teamDomAct="E1_BSD"}
        GDM {$teamAccount = $config.localcred.gdm; $teamDomAct="E1_GDM"}
        PD {$teamAccount = $config.localcred.pd; $teamDomAct="E1_PD_ADMINS"; $teamDomAct1="E1_PD_USERS"}
        SF {$teamAccount = $config.localcred.sf; $teamDomAct="E1_SF"}
    }
}
Else
{
    Break;
}

#Grant domain permission
$computerName = $env:COMPUTERNAME

If($ec2TagDB -eq $NULL)
{
    $adsiComputer = [ADSI]("WinNT://$computerName,computer") 
    $localGroup = $adsiComputer.psbase.children.find('Administrators', 'Group') 
    $admMember = $localGroup.psbase.invoke("members")  | ForEach{
        $_.GetType().InvokeMember("Name",  'GetProperty',  $null,  $_, $null)
    }

    Foreach($groupAcct in $admMember)
    {
        If($groupAcct -eq $teamDomAct -and $groupAcct -ne "E1_ITIS")
        {
            $existTeamDomAcct = $TRUE
        }
        Elseif($groupAcct -eq "E1_ITIS")
        {
            $existE1Group = $TRUE
        }
        Else
        {
            Continue;
        }
    }

    Sleep 5

    If($existTeamDomAcct -ne $TRUE)
    {
        $adsiComp = [adsi]"WinNT://$Computername" 
        $userGroup = 'Administrators'
        $group = [ADSI]"WinNT://$env:COMPUTERNAME/$userGroup,group"
        $group.psbase.Invoke("Add",([ADSI]"WinNT://$domName/$teamDomAct").path)
    }
    Elseif($existE1Group -ne $TRUE)
    {
        $adsiComp = [adsi]"WinNT://$Computername" 
        $userGroup = 'Administrators'
        $group = [ADSI]"WinNT://$env:COMPUTERNAME/$userGroup,group"
        $group.psbase.Invoke("Add",([ADSI]"WinNT://$domName/E1_ITIS").path)
    }    

    If($teamTag -eq 'pd')
    {
        $rdsGroup = $adsiComputer.psbase.children.find('Remote Desktop Users', 'Group') 
        $rdsMember = $rdsGroup.psbase.invoke("members")  | ForEach{
            $_.GetType().InvokeMember("Name",  'GetProperty',  $null,  $_, $null)
        }
        Foreach($rdsAcct in $rdsMember)
        {
            If($rdsAcct -eq $teamDomAct1)
            {
                $existROAcct = $TRUE
            }
            Else
            {
                Continue;
            }
        }

        Sleep 5

        If($existROAcct -ne $TRUE)
        {
            $adsiComp = [adsi]"WinNT://$Computername" 
            $rdGroup = 'Remote Desktop Users'
            $group = [ADSI]"WinNT://$env:COMPUTERNAME/$rdGroup,group"
            $group.psbase.Invoke("Add",([ADSI]"WinNT://$domName/$teamDomAct1").path)
        }
    }
}
Else
{
    $adsiComputer = [ADSI]("WinNT://$computerName,computer")
    $localGroup = $adsiComputer.psbase.children.find('Administrators', 'Group') 
    $admMember = $localGroup.psbase.invoke("members")  | ForEach{
        $_.GetType().InvokeMember("Name",  'GetProperty',  $null,  $_, $null)
    }
    Foreach($dbAcct in $admMember)
    {
        If($dbAcct -eq "E1_DBA")
        {
            $existDBAcct = $TRUE
        }
        Else
        {
            Continue;
        }
    }

    Sleep 5

    If($existDBAcct -ne $TRUE)
    {
        $adsiComp = [adsi]"WinNT://$Computername" 
        $userDBGroup = 'Administrators'
        $dbGroup = [ADSI]"WinNT://$env:COMPUTERNAME/$userDBGroup,group"
        $dbGroup.psbase.Invoke("Add",([ADSI]"WinNT://$domName/E1_DBA").path)
    }
}

# Create local account
$localAdm = $config.e1admin.username
$localPwd = $config.e1admin.password
$localAccount = (Get-WmiObject -Class Win32_UserAccount -Namespace "root\cimv2" -Filter "LocalAccount='$True'" -ComputerName $computerName).Name

Sleep 2

Foreach($Acct in $localAccount)
{
    If($Acct -eq $teamAccount.username)
    {
        $existTeamAcct = $TRUE
    }
    Elseif($Acct -eq $localAdm)
    {
        $existE1Acct = $TRUE
    }
    Else
    {
        Continue;
    }
}

Sleep 2

If($existTeamAcct -ne $TRUE)
{
    $teamAcct = $teamAccount.username
    $adsiComp = [adsi]"WinNT://$Computername" 
    $newUser = $adsiComp.Create('User',$teamAcct)
    $passwd = $teamAccount.password | ConvertTo-SecureString -asPlainText -Force
    $bstr = [system.runtime.interopservices.marshal]::SecureStringToBSTR($passwd)
    $_password = [system.runtime.interopservices.marshal]::PtrToStringAuto($bstr)
    $newUser.SetPassword(($_password))
    $newUser.SetInfo()
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) 
    Remove-Variable passwd,bstr,_password
    $userLocalGroup = 'Administrators'
    $localAdmGroup = [ADSI]"WinNT://$env:COMPUTERNAME/$userLocalGroup,group"
    $localAdmGroup.Add("WinNT://$env:COMPUTERNAME/$teamAcct,user")
    $user = [adsi]"WinNT://$env:computername/$teamAcct"
    $user.UserFlags.value = $user.UserFlags.value -bor 0x10000
    $user.SetInfo()
    $user.CommitChanges
}

If($existE1Acct -ne $TRUE)
{
    $adsiComp = [adsi]"WinNT://$Computername" 
    $newUser = $adsiComp.Create('User',$localAdm)
    $passwd = $localPwd | ConvertTo-SecureString -asPlainText -Force
    $bstr = [system.runtime.interopservices.marshal]::SecureStringToBSTR($passwd)
    $_password = [system.runtime.interopservices.marshal]::PtrToStringAuto($bstr)
    $newUser.SetPassword(($_password))
    $newUser.SetInfo()
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) 
    Remove-Variable passwd,bstr,_password
    $userLocalGroup = 'Administrators'
    $localAdmGroup = [ADSI]"WinNT://$env:COMPUTERNAME/$userLocalGroup,group"
    $localAdmGroup.Add("WinNT://$env:COMPUTERNAME/$localAdm,user")
    $user = [adsi]"WinNT://$env:computername/$localAdm"
    $user.UserFlags.value = $user.UserFlags.value -bor 0x10000
    $user.SetInfo()
    $user.CommitChanges
}