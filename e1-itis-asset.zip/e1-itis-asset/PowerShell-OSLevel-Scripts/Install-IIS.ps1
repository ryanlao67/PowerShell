$ec2PrivateIP = (Get-NetIPAddress | where {$_.AddressFamily -eq 'IPv4' -and $_.PrefixOrigin -ne 'WellKnown'}).IPAddress
$domName = (Get-WmiObject -Class WIN32_ComputerSystem).Domain

If ($ec2PrivateIP -match '10.163' -and $domName -eq 'E1SD.COM')
{
    $srcPath = 'cne1wsus02.e1sd.com\Source\sxs'
}
Elseif ($ec2PrivateIP -match '10.163' -and $domName -eq 'E1EF.COM')
{
    $srcPath = 'cne1wsus01.e1ef.com\Source\sxs'
}
Elseif ($ec2PrivateIP -match '10.160' -and $domName -eq 'E1SD.COM')
{
    $srcPath = 'sge1wsus01.e1ed.com\Source\sxs'
}
Elseif ($ec2PrivateIP -match '10.160' -and $domName -eq 'E1EF.COM')
{
    $srcPath = 'sge1wsus02.e1ef.com\Source\sxs'
}
Else
{
    Write-Warning "Server location cannot be determined, please verify."
    Exit 1
}

Install-WindowsFeature -Source $srcPath -Name `
@(
    "Web-Server",
    "Web-WebServer",
    "Web-Common-Http",
    "Web-Default-Doc",
    "Web-Dir-Browsing",
    "Web-Http-Errors",
    "Web-Static-Content",
    "Web-Health",
    "Web-Http-Logging",
    "Web-Log-Libraries",
    "Web-Request-Monitor",
    "Web-Http-Tracing",
    "Web-Performance",
    "Web-Stat-Compression",
    "Web-Dyn-Compression",
    "Web-Security",
    "Web-Filtering",
    "Web-App-Dev",
    "Web-Net-Ext",
    "Web-Net-Ext45",
    "Web-Asp-Net45",
    "Web-ISAPI-Ext",
    "Web-ISAPI-Filter",
    "Web-Ftp-Server",
    "Web-Mgmt-Tools",
    "Web-Mgmt-Console",
    "Web-Mgmt-Compat",
    "Web-Mgmt-Service",
    "NET-Framework-Features",
    "NET-Framework-Core",
    "NET-HTTP-Activation",
    "NET-Framework-45-Features",
    "NET-Framework-45-Core",
    "NET-Framework-45-ASPNET",
    "NET-WCF-Services45",
    "NET-WCF-HTTP-Activation45",
    "NET-WCF-TCP-PortSharing45",
    "RSAT",
    "RSAT-Feature-Tools",
    "Telnet-Client",
    "WAS",
    "WAS-Process-Model",
    "WAS-NET-Environment",
    "WAS-Config-APIs"
)