﻿################################################################################################################
#Auto send out notification email for user which password will be expired in 15 days
#This script running depend on file E1SD_UserDetail.csv which generated from CNE1WSUS02 Schedule
#CNE1WSUS02 can not reach SMTP-ht.ef.com, we have to run it from SGE1WSUS01
###############################################################################################################


#All E1SD.COM Users
copy-item \\CNE1WSUS02\D$\e1awsinventory\html\E1SD_UserDetail.csv  D:\Scripts\AccountNotification\E1SD_UserDetail.csv -force
$AllUsers=Import-Csv -Path  "D:\Scripts\AccountNotification\E1SD_UserDetail.csv"

#All Excetpion Users
$ExceptionUsers=Import-Csv -Path  "D:\Scripts\AccountNotification\E1SD_ExceptionList.csv"

#Generate a new Csv file
[array]$outputs=$null
foreach($user in $allUsers)
{
   $susername=$null
   $sdomainaccount=$null
   $sExpirationDate=$null
   $MailAddress=$null
   $sExpirationDate=$null
   $ActiveDays=$null

   
   $sUserName=$user.UserName
   $sDomainAccount=$user.UpN
   $sExpirationDate=$user.PasswordExpiration
  
   #MailAddress
   if ($ExceptionUsers | ? {$_.eUsername -eq "$sUserName"})
    { $MailAddress=$ExceptionUsers | ? {$_.eUsername -eq "$sUserName"} | select -ExpandProperty MailAddress}
   Else
    { $MailAddress="$sUserName"+"@ef.com"}   


    #Remaining Days
    if($user.PasswordExpiration){
    [datetime]$PasswordExpiration=$user.PasswordExpiration
    $CurrentDate=Get-date
    $ActiveDays=($PasswordExpiration - $CurrentDate).days
    }
   else{$ActiveDays="NeverExpired"}

    $output = New-Object psobject
    $output | Add-Member NoteProperty "UserName"      $sUserName
    $output | Add-Member NoteProperty "DomainAccount" $sDomainAccount
    $output | Add-Member NoteProperty "MailAddress"   $MailAddress
    $output | Add-Member NoteProperty "Expiration"    $sExpirationDate
    $output | Add-Member NoteProperty "RemainingDays" $ActiveDays
    $output
    $outputs+=$output
}

#Output New Results to csv file 
$outputs | sort RemainingDays -Descending | Export-Csv D:\Scripts\AccountNotification\PasswordExpiration.csv -NoTypeInformation




#Filter out the account which will be expired within 15 days
$ExpiredWithin15Days=$outputs | ? {($_.RemainingDays -le 15) -and ($_.RemainingDays -ge 0)}


if($ExpiredWithin15Days)
{
  $domainname=$env:USERDNSDOMAIN
  $NotifyHistory=$null

  foreach($exp in $ExpiredWithin15Days)
   { 

     $domUserName=$exp.UserName
     $RemDays=$exp.remainingdays
     $expiredDate=$exp.Expiration
     #mail address
     $ExpiredUserMailAddress=$exp.MailAddress


     #Notify history
     $notifytime=get-date
     [array]$NotifyHistory+="$notifytime Notify $ExpiredUserMailAddress---->For Expiring Account $domUserName"
     

     #Create the notification text
     $HTMLFileName=$null
     $body=$null     
         
     $HTMLFileName ="<html>"
     $HTMLFileName+="<head>"
     $HTMLFileName+= "<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>"
     $HTMLFileName+= '<title></title>'
     $HTMLFileName+= '<STYLE TYPE="text/css">'
     $HTMLFileName+= "<!--"
     $HTMLFileName+= "-->"
     $HTMLFileName+= "</style>"
     $HTMLFileName+= "</head>"
     $HTMLFileName+= "<body>"
     $HTMLFileName+= "<p>Hi, </p>"
     $HTMLFileName+= "<p>You are receiving this mail because of account $domainname\$domUserName will be expired in $RemDays days at $expiredDate, Please take action to updating password before the expiration. </p>"
     $HTMLFileName+= "<li><b>Domain Account:</b>  $domainname\$domUserName</li>"
     $HTMLFileName+= "<li><b>Expiration Date:</b> $expiredDate</li>"
     $HTMLFileName+= "<li><b>Remaining Days:</b>  $RemDays</li>"
     $HTMLFileName+= "<br>"
     $HTMLFileName+= "<br>"
     $HTMLFileName+= "<p>Tips:</p>"
     $HTMLFileName+= "<li>If you logon server by using Remote Desktop Connection Manager or RDP, please Press Ctrl+Alt+End Key to lunch the Password Change Windows. </li>"
     $HTMLFileName+= "<li>If you can not logon by the new password, please wait for a moment (15-20Minutes) for data syncroziation on all AD Servers and then try it again. </li>"
     $HTMLFileName+= "<br>"
     $HTMLFileName+= "<br>"
     #contact ITIS for help
     $HTMLFileName+= "<p>Please submit JIRA if you need ITIS help</p>"
     $HTMLFileName+= "<li><a href=https://jira.englishtown.cn/secure/RapidBoard.jspa?rapidView=698&projectKey=E1IT&view=planning>Submit JIRA Ticket</a></li>"
     $HTMLFileName+= "<li>Team: E1.IT.Infrastructure </li>"
     $HTMLFileName+= "<li>Mail: E1.IT.Infrastructure@EF.com</li>"
     $HTMLFileName+= "<br>"
     $HTMLFileName+= "</body>"
     $HTMLFileName+= "</html>"

     $body = $HTMLFileName


     #Connect SMTP server
     $smtpServer="ht.ef.com"
     $smtp = new-object Net.Mail.SmtpClient($smtpServer)


     #Create Mail
     $msg = new-object Net.Mail.MailMessage
     $msg.From = "AccountNotify@ef.com"
     $ExpiringAccount=$ExpiredUserMailAddress
     #$ExpiredUserMailAddress
     if($RemDays -le 5) 
      { 
        $msg.to.Add($ExpiringAccount)
        #$msg.cc.Add("ewen.he@ef.com") 
      }
     else {$msg.to.Add($ExpiringAccount)}
     $msg.Subject = "$domainname\$domUserName will be expired in $RemDays days at $expiredDate"
     $msg.Body = $body
     $msg.isBodyhtml = $true
     $smtp.Send($msg)
   }

  #output the notify history
  $NotifyHistory | Out-File -Append "D:\Scripts\AccountNotification\NotifyHistory.txt"

}
else{break}






