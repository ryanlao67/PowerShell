$e1Group = (Get-ADGroup -Filter 'GroupCategory -eq "Security"' | Where {$_.SamAccountName -match "E1_"}).SamAccountName
$e1GroupMemAll = @()
$e1GroupAll = @()
Foreach($e1Groups in $e1Group)
{
    $e1GroupUsers = @((Get-ADGroupMember $e1Groups | Where {$_.objectClass -eq "user"}).SamAccountName)
    Foreach ($e1GroupUser in $e1GroupUsers)
    {
        If((Get-ADUser $e1GroupUser -ErrorAction SilentlyContinue).Enabled -eq "True")
        {
            $e1GroupMem = $e1Groups + ": " + $e1GroupUser
        }
        $e1GroupMemAll += $e1GroupMem
    }
    $e1GroupAll += $e1GroupMemAll
}

$e1GroupAll

#(Get-ADGroup -Filter 'GroupCategory -eq "Security"' | Where {$_.SamAccountName -match "E1_"} | Get-ADGroupMember | Where {$_.objectClass -eq "user"}).SamAccountName | Select -Uniq | Get-ADUser | Where {$_.Enabled -eq "True"} | Select-Object SamAccountName | Sort-Object SamAccountName