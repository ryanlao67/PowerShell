﻿#Pre-condition to running this script
#The server must be able to talk with Domain Control Port:9389
#The server mush have Powershell AD moudule installed


param($DaysInactive)
#By default inactive days is 45 
$DaysInactive=45

write-warning "--1.This Script is used for check AD Account with no ctivity for more than $DaysInactive days---"
write-warning "--2.Incative Account does not mean the user is not required,you can not delete it diretcly------"

$time = (Get-Date).Adddays(-($DaysInactive))
 
# Get all AD computers with lastLogonTimestamp less than our time
[array]$oldUser=$null
[array]$oldUser=Get-ADUser -Filter {LastLogonTimeStamp -lt $time} -Properties LastLogonTimeStamp | select-object Name,@{Name="LastLogOn"; Expression={[DateTime]::FromFileTime($_.lastLogonTimestamp)}} 

#output the result to console
$oldUser | sort lastlogon -desc

write-host "Result OLD_User.csv was dropped on your Desktop" -ForegroundColor Green
[array]$oldUser | sort lastlogon -desc | export-csv $home\Desktop\OLD_User.csv -notypeinformation
