﻿#Pre-condition to running this script
#The server must be able to talk with Domain Control Port:9389
#The server mush have Powershell AD moudule installed


param($DaysInactive)
$DaysInactive = 90 

write-warning "--1.This Script is used for check Computer Account with no ctivity for more than $DaysInactive days---"
write-warning "--2.Incative Computer Account does not mean the Computer is no-need ,you can not delete it diretcly------"


$time = (Get-Date).Adddays(-($DaysInactive))
 
# Get all AD computers with lastLogonTimestamp less than our time
Get-ADComputer -Filter {LastLogonTimeStamp -lt $time} -Properties LastLogonTimeStamp |
 
# Output hostname and lastLogonTimestamp into CSV
select-object Name,@{Name="Stamp"; Expression={[DateTime]::FromFileTime($_.lastLogonTimestamp)}} | sort Stamp -desc | export-csv  $home\desktop\OLD_Computer.csv -notypeinformation

write-host "=======Result OLD_Computer.CSV was dropped on your Desktop========" -ForegroundColor Green