Param (
    [Parameter(Mandatory = $True, Position = 0)]
    [string] $srvList
)

$startTime = Get-Date

Get-Content $srvList | Foreach-Object{
    $ScriptBlock = {
        param($node) 
        Tracert $node | Out-File -filepath ".\$node.txt"
    }
    Start-Job $ScriptBlock -ArgumentList $_
}

Get-Job | Out-Null

While (Get-Job -State "Running")
{
  Start-Sleep 10
}

Get-Job | Receive-Job

$endTime = Get-Date

$duration = ($endTime-$startTime).TotalSeconds

Write-Host $duration"s"