$user = ""
$pswd = ConvertTo-SecureString -String "" -AsPlainText -Force
$cred = New-Object -TypeName "System.Management.Automation.PSCredential" -ArgumentList $user, $pswd

foreach ($srv in (Get-Content ".\sl.txt"))
{
    Invoke-Command -ComputerName $srv -Credential $cred -ScriptBlock {
        Hostname
        $networkConfig = Get-WmiObject Win32_NetworkAdapterConfiguration -filter "ipenabled = 'true'"
        $networkConfig.SetDynamicDNSRegistration($true,$true) | Out-Null
        ipconfig /registerdns
        $networkConfig.SetDynamicDNSRegistration($true,$false) | Out-Null
        gpupdate /force
        wuauclt.exe /detectnow /reportnow
        Restart-Service wuauserv -PassThru
    }
}