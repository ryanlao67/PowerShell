Param(
    [Parameter(Mandatory = $True, Position = 0)]
    [string] $serverList
)

$scriptBlock = {
    $srvName = $ENV:COMPUTERNAME
    $srvName
    $domName = (Get-WmiObject -Class WIN32_ComputerSystem).Domain
    $ec2PrivateIP = (Get-WmiObject Win32_NetworkAdapterConfiguration -ComputerName $srvName -ErrorAction Stop | Where {$_.IPEnabled}).IPAddress[0]
    If ($ec2PrivateIP -match '10.160')
    {
        $zbxSRV = '10.160.134.50'
    }
    Elseif ($ec2PrivateIP -match '10.163')
    {
        $zbxSRV = '10.163.30.50'
    }
    Else
    {
        Break;
    }

    #Install and config Zabbix agent
    If(Test-Path 'D:\Zabbix\zabbix_agentd.conf')
    {
        $zbxLoc = 'D:\Zabbix'
    }
    Else
    {
        $zbxLoc = 'C:\Zabbix'
    }

    $zbxLog = "$zbxLoc\zabbix_agentd.log"
    $zbxConf = Get-Content "$zbxLoc\zabbix_agentd.conf"
    $zbxConf[13] = $zbxConf[13].Replace($zbxConf[13], "LogFile=$zbxLog")
    $zbxConf[73] = $zbxConf[73].Replace($zbxConf[73], "Server=$zbxSRV")
    $zbxConf[125] = $zbxConf[125].Replace($zbxConf[125], "Hostname=$srvName")
    Set-Content "$zbxLoc\zabbix_agentd.conf" $zbxConf
    Invoke-WmiMethod -Class Win32_process -Name Create -ArgumentList ("cmd.exe /C $zbxLoc\zabbix_agentd.exe --config $zbxLoc\zabbix_agentd.conf --stop") | Out-Null
    Sleep 3
    Invoke-WmiMethod -Class Win32_process -Name Create -ArgumentList ("cmd.exe /C $zbxLoc\zabbix_agentd.exe --config $zbxLoc\zabbix_agentd.conf --start") | Out-Null
    Sleep 3
}

Foreach($tgtServer in Get-Content $serverList)
{
    Invoke-Command -ComputerName $tgtServer -ScriptBlock $scriptBlock
}