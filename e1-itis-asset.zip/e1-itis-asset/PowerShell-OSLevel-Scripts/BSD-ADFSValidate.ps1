﻿[array]$servers=@(
"CNE1PRDOMNI-SS2",
"CNE1PRDOMNISSo1",
"SGE1PRDOMNI-SS1",
"SGE1PRDOMNI-SS2"
)

foreach ($server in $servers)
{
   icm -ComputerName $server -ScriptBlock {
                                                $Servername=$env:computername
                                                $PointIP=(Test-Connection adfs.ef.com -count 1).ipv4address.ipaddresstostring
                                                $Result=D:\ValidateADFS\ValidateAdfs.exe -s "https://adfs.ef.com/adfs/services/trust/13/usernamemixed" -r "https://omni-sso.ef.cn" -u "test.other@ef.com" -p "Zendesk1"
                                                 
                                                 "==========$Servername Start======================"
                                                "$Servername ADFS.EF.COM Point TO IP: $PointIP"
                                                "Validation Result:"
                                                 $Result  
                                                 "==========$Servername  End======================="   
                                                 Write-Host `n 
                                                 Write-Host `n 
                                            }
}