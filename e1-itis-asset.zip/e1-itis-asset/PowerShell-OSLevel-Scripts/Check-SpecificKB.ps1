$srvResultAll = @()
Foreach($srv in Get-Content "D:\Scripts\Patching\ServerList\12AM\all.txt")
{
    $scriptBlock = {
        $srvResult = New-Object psobject
        $srvName = (Get-CimInstance -ClassName win32_operatingsystem).CSName
        $osInfo = (Get-WmiObject -class Win32_OperatingSystem).Caption
        If($osInfo -Match 2012)
        {
            $kbInfo = "KB4056898"
            $kbNum = Get-HotFix | Where {$_.HotfixID -match "KB4056898"}
        }
        Elseif($osInfo -Match 2016)
        {
            $kbInfo = "KB4056890"
            $kbNum = Get-HotFix | Where {$_.HotfixID -match "KB4056890"}
        }
        Else
        {
            $kbInfo = ""
            $kbNum = ""
            Continue

        }

        If($kbNum)
        {
            $patchStatus = "Yes"
            $installTime = $kbNum.Installedon
        }
        Else
        {
            $patchStatus = "No"
            $installTime = "N/A"
        }

        $srvResult | Add-Member NoteProperty "ServerName" $srvName
        $srvResult | Add-Member NoteProperty "OSVersion" $osInfo
        $srvResult | Add-Member NoteProperty "KB#" $kbInfo
        $srvResult | Add-Member NoteProperty "Patched" $patchStatus
        $srvResult
    }
    $resultRaw = Invoke-Command -ComputerName $srv -ScriptBlock $scriptBlock
    $srvResultAll += $resultRaw
}

$srvResultAll | Select-Object ServerName, OSVersion, KB#, Patched | Format-Table -Auto