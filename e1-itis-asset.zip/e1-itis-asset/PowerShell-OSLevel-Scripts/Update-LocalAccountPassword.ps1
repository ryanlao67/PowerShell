Param(
    [Parameter(Mandatory = $True, Position = 0)]
    [string] $serverList,

    [Parameter(Mandatory = $True, Position = 1)]
    [string] $accountName
)

$passwd = Read-Host -AsSecureString "Please input password"
$bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($passwd)
$passwdValue = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)

$scriptBlock = {
    Param($updateUser,$newPasswd)
    $strComputer = $env:COMPUTERNAME
    $admin=[adsi]("WinNT://" + $strComputer + "/$updateUser, user")
    $admin.psbase.invoke("SetPassword", $newPasswd)
    If(!$Error)
    {
        Write-Host "$strComputer done"
    }
}

Foreach($tgtServer in Get-Content $serverList)
{
    Invoke-Command -ComputerName $tgtServer -ScriptBlock $scriptBlock -ArgumentList `
            $accountName, `
            $passwdValue
}