$resultFile = "D:\zabbix-agent\LDAPResult.txt"

$testRaw = 'tcping.exe ldap.ef.com 389 > D:\zabbix-agent\TestResult.txt'

Invoke-Expression "& $testRaw"

$ldapEvent = "LDAP Test"
If(!([System.Diagnostics.EventLog]::SourceExists($ldapEvent)))
{
    New-EventLog -LogName Application -Source $ldapEvent
}

$eventInfo = "8751"
$eventWrn = "8752"
$eventErr = "8753"

$dT = (Get-Date).ToString("yyyyMMddHHmmss")

$testCMD = Get-Content "D:\zabbix-agent\TestResult.txt"

$n = 0
Foreach ($testRst in $testCMD)
{
    If($testCMD[$n] -match "0 failed.")
    {
        $testInfo = "[$dT]ldap.ef.com is working as expected."
        Write-EventLog -Source "$ldapEvent" -LogName "Application" -EntryType Information -EventID $eventInfo -Message $testInfo
    }
    Elseif($testCMD[$n] -match "1 failed." -or $testCMD[$n] -match "2 failed.")
    {
        $testWrn = "[$dT]ldap.ef.com is not stable."
        Write-EventLog -Source "$ldapEvent" -LogName "Application" -EntryType Warning -EventID $eventWrn -Message $testWrn
    }
    Elseif($testCMD[$n] -match "3 failed." -or $testCMD[$n] -match "4 failed.")
    {
        $testErr = "[$dT]ldap.ef.com is unreachable."
        Write-EventLog -Source "$ldapEvent" -LogName "Application" -EntryType Error -EventID $eventErr -Message $testErr
    }
    Elseif($testCMD[$n] -match "Could not find host")
    {
        $testErr = "[$dT]ldap.ef.com cannot be resolved."
        Write-EventLog -Source "$ldapEvent" -LogName "Application" -EntryType Error -EventID $eventErr -Message $testErr
    }
    $n++
}

If($testErr)
{
    $testResult = 1
}
Elseif($testWrn)
{
    $testResult = 2
}
Else
{
    $testResult = 0
}

$testResult | Out-File -filepath $resultFile