Set-ExecutionPolicy Remotesigned -Force

Function testAdmin 
{ 
([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator") 
} 

If (!(testAdmin))
{
    Write-Warning "Please start the script with administrator privilige."
    Break
}
Else
{
    Set-ExecutionPolicy Remotesigned -Force
    Add-Type -AssemblyName Microsoft.VisualBasic

    $kavSvc = Get-Service Kavfs -ErrorAction SilentlyContinue
    $klnAgt = Get-Service klnagent -ErrorAction SilentlyContinue

    $domName = (Get-WmiObject -Class WIN32_ComputerSystem).Domain
    $srvName = $ENV:COMPUTERNAME
    $srvIP = (Get-WmiObject Win32_NetworkAdapterConfiguration -ComputerName $srvName -ErrorAction Stop | Where {$_.IPEnabled}).IPAddress[0]

    If($srvIP -match '10.163')
    {
        If($domName -eq 'E1EF.COM')
        {
            $srcSrv = "10.163.25.64"
            $cpSrv="10.163.25.64"
        }
        Elseif($domName -eq 'E1SD.COM')
        {
            $srcSrv = "10.163.13.139"
            $cpSrv="10.163.13.139"
        }
        Else
        {
            Break
        }
    }
    Elseif($srvIP -match '10.160')
    {
        If($domName -eq 'E1EF.COM')
        {
            $srcSrv = "10.160.131.126"
            $cpSrv="10.160.131.126"
        }
        Elseif($domName -eq 'E1SD.COM')
        {
            $srcSrv = "10.160.114.146"
            $cpSrv="10.160.114.146"
        }
        Else
        {
            Break
        }
    }
    Else
    {
        Break
    }

    If($klnAgt.Status -eq "Running" -or $klnAgt.Status -eq "Stopped")
    {
        Start-Process klmover.exe -Workingdirectory "C:\Program Files (x86)\Kaspersky Lab\NetworkAgent" -ArgumentList "-address $srcSrv" -Wait -PassThru
        If ($kavSvc -eq $null)
        {            
            Robocopy "\\$cpSrv\klshare\PkgInst\KAVFSEE_8.0.2.213" "C:\Kaspersky\KAVFSEE_8.0.2.213" /e /r:2 /w:0 /mir /np
            Start-Process setup.exe -Workingdirectory "C:\Kaspersky\KAVFSEE_8.0.2.213" -ArgumentList "-s" -Wait -PassThru
            Start-Sleep 60
            
            $kavSvc = Get-Service Kavfs -ErrorAction SilentlyContinue
            If($kavSvc.Status -eq "Running")
            {
                Write-Host "KAV8 Installation Successful."
                Remove-item "C:\Kaspersky\KAVFSEE_8.0.2.213" -Recurse
                Start-Process kavshell.exe -WorkingDirectory "C:\Program Files (x86)\Kaspersky Lab\Kaspersky Anti-Virus 8.0 For Windows Servers Enterprise Edition" -ArgumentList "update /KL" -Wait -PassThru
            }
            Else
            {
                Write-Warning "KAV8 installation Failed, please manually check."
                Break
            }
        }        
        Else
        {
            Write-Host "KAV8 already installed."
            Break
        }
    }
    Else
    {
        Write-Warning "No anti-virus installed on the server, proceeding with the installation"
        Robocopy "\\$cpSrv\klshare\PkgInst" "C:\Kaspersky" /e /r:2 /w:0 /mir /np

        If($LASTEXITCODE -eq "0" -or $LASTEXITCODE -eq "1")
        {
            $instCode = (Start-Process "setup.exe" -Workingdirectory "C:\Kaspersky\NetAgent" -ArgumentList "-s" -Wait -PassThru).Exitcode
            If ($instCode -eq "0")
            {
                Start-Process "setup.exe" -Workingdirectory "C:\Kaspersky\KAVFSEE_8.0.2.213" -ArgumentList "-s" -Wait -PassThru
                Start-Sleep -Seconds 60

                $kavSvc = Get-Service Kavfs -ErrorAction SilentlyContinue
                If($kavSvc.Status -eq "Running")
                {
                    Remove-item "C:\Kaspersky" -Recurse
                    Start-Process kavshell.exe -WorkingDirectory "C:\Program Files (x86)\Kaspersky Lab\Kaspersky Anti-Virus 8.0 For Windows Servers Enterprise Edition" -ArgumentList "update /KL" -Wait -PassThru
                }
                Else
                    {
                        Write-Warning "KAV8 Installation Failed, please manually check."
                        Break
                    }
                }
            Else
                {
                    Write-Warning "Kaspersky NetworkAgent installation failed, please manually check."
                    Break
                }
        }
        Else
        {
            Write-Warning "Package copy failed locally."
            Break
        }     
    }
}