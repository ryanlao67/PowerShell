﻿#This scripte is used for gettting all installed certsinstalled from path:"Cert:\LocalMachine\" 
#Usage: 
# Parameter Specified
#.\winodws-GetCert.ps1 -servernameorserverlist serverlist.txt
#
# None Parameter Specified,the script will get all servernames from AD and then check&get cert list server by server
#.\windows-GetCert.ps1

param(
[string]$ServerNameORServerlist=""
)

if($ServerNameORServerlist -like "*txt*")
   {[array]$list=gc $ServerNameORServerlist}
else
   {[array]$list=Get-ADComputer -Filter * -Properties Name | select -ExpandProperty name }

#Get the cert list server by server
[array]$failedservers=$null
[array]$totalResult=$null
Foreach ($srv in $list)
{  
   $singleResult=$null     
   try{           
         $singleResult=icm -ComputerName $srv -ErrorAction stop  -ScriptBlock {         
          Get-ChildItem -Recurse  Cert:\LocalMachine\ | select  @{name="Servername";expression={$env:COMPUTERNAME}},subject,notbefore,notafter   
          } -HideComputerName
       }
   catch
       {
       "$srv connect failed"
        $failedservers+=$srv 
        }
    $singleResult  
   $totalResult+=$singleResult
 }
  
#Output the failed servers
if($failedservers)
{

"Below server failed to connect"
 $failedservers
 $failedservers | out-file $home\desktop\failedservers.txt
}

#Define the filename
$domainname=$env:USERDNSDOMAIN
$Reportname=$domainname+"_"+"CertDetail.csv"

#output the finally Report
write-host "Result was dropped on your desktop with name $Reportname"
$totalResult |  ? {$_.Subject -ne $null} | Export-Csv $home\desktop\$Reportname -NoTypeInformation

