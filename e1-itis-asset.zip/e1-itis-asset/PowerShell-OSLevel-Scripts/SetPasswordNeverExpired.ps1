Foreach($Servers in Get-Content <SERVER LIST HERE>)
{
   	Invoke-Command -ComputerName $Servers -ScriptBlock{
   		$computerName = $env:COMPUTERNAME
        $localAccount = (Get-WmiObject -Class Win32_UserAccount -Namespace "root\cimv2" -Filter "LocalAccount='$True'" -ComputerName $computerName).Name
        Foreach($localAcct in $localAccount)
        {
        	If($localAcct -eq <LOCAL ACCOUNT NAME>)
        	{
        		$itAcct = <LOCAL ACCOUNT NAME>
        	}
        	Else
        	{
        		Continue
        	}
        }
        If($itAcct)
        {
        	$neverExpired = '0x10000'
        	$user = [adsi]"WinNT://$env:computername/$itAcct"
			$user.userflags = $user.userflags[0] -bor $neverExpired
			$user.SetInfo()
			$user.CommitChanges
        }
    } -ArgumentList $Servers;
}