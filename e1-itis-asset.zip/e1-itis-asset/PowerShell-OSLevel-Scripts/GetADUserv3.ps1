﻿[array]$allUsers=Get-ADUser -Filter *  -Properties SamAccountName,UserPrincipalName,enabled,LastLogonDate,Created,PasswordLastSet,msDS-UserPasswordExpiryTimeComputed,PasswordExpired,accountExpires,LastBadPasswordAttempt,logonCount,memberof,sid


[array]$outputs=$null
foreach($user in $allUsers)
{
 $output=$null

 $username=$null
 $upn=$null
 $lastlogon=$null
 $AccoutStaus=$null
 $AccoutCreated=$null
 $PasswordLastSet=$null
 $PasswordExpiration=$null
 $passwordExpired=$null
 $LastBadPasswordAttempt=$null
 $logonCount=$null 
 $SID=$null
 $group=$null
 $groupdetail=$null
 
 $username=$user.SamAccountName
 $UPN=$user.UserPrincipalName
 $LastLogon=$user.LastLogonDate
 $AccoutStaus=$user.enabled
 $AccoutCreated=$user.created
 $PasswordLastSet=$user.PasswordLastSet
 $PasswordExpiration=[datetime]::FromFileTime($user."msDS-UserPasswordExpiryTimeComputed")

 $passwordExpired=$user.PasswordExpired
 #$AccoutExpired= [datetime]::FromFileTime($user.accountexpires).tostring()
 $LastBadPasswordAttempt=$user.LastBadPasswordAttempt
 $logonCount=$user.logoncount
 [array]$group=$user.memberof

 $SID=$user.sid

 #convert the group to string type
 $groupdetail=$null
 foreach($g in $group)
  {  [string]$groupdetail+=$g+"`n" }


$output = New-Object psobject
$output | Add-Member NoteProperty "UserName" $username
$output | Add-Member NoteProperty "UpN"  $UPN
$output | Add-Member NoteProperty "LastLogon"  $LastLogon
$output | Add-Member NoteProperty "AccoutStatus"     $AccoutStaus
$output | Add-Member NoteProperty "AccoutCreated"    $AccoutCreated

#$output | Add-Member NoteProperty "AccoutExpired"    $AccoutExpired
$output | Add-Member NoteProperty "PasswordLastSet"  $PasswordLastSet
$output | Add-Member NoteProperty "PasswordExpiration"  $PasswordExpiration
$output | Add-Member NoteProperty "PasswordExpired"  $PasswordExpired
$output | Add-Member NoteProperty "SID"  $SID
#$output | Add-Member NoteProperty "LastBadPasswordAttempt"  $LastBadPasswordAttempt

#$output | Add-Member NoteProperty "logonCount"       $logonCount
#$output | Add-Member NoteProperty  "Group"           $groupdetail
$output

#collect all result
[array]$outputs+=$output

}


#output the result to Desktop
Write-Host "User Scan Completed,and Result was dropped on Desktop UserDetail.txt"
$outputs | ? {($_.username -ne "Guest") -and ($_.username -ne "administrator") -and ($_.username -ne "krbtgt") -and ($_.username -ne "e1admin") -and ($_.username -ne '$DUPLICATE-675') } | sort LastLogon |  Export-Csv -Path D:\e1awsinventory\html\E1SD_UserDetail.csv -NoTypeInformation
