Param (
    [Parameter(Mandatory = $False, Position = 0)]
    [string] $srvName
)

# Confirm server region and environment
If ($srvName -match 'CNE1')
{
    If ($srvName -match 'PRD')
    {
        $dnsIP1 = '10.163.8.184'
        $dnsIP2 = '10.163.12.246'
    }
    Else
    {
        $dnsIP1 = '10.163.24.40'
        $dnsIP2 = '10.163.28.227'
    }
}
Elseif ($srvName -match 'SGE1')
{
    If ($srvName -match 'PRD')
    {
        $dnsIP1 = '10.160.112.144'
        $dnsIP2 = '10.160.113.132'
    }
    Else
    {
        $dnsIP1 = '10.160.128.28'
        $dnsIP2 = '10.160.129.180'
    }
}
Else
{
    Write-Host "Server name entered is not standard naming convention, please run it script again with correct server name" -Foregroundcolor Yellow
    Break;
}
    
# Set DNS server
Get-DnsClientServerAddress -InterfaceAlias Ethernet -AddressFamily IPv4 | Set-DnsClientServerAddress -ServerAddresses ($dnsIP1,$dnsIP2)

# Rename server and restart for taking effect
Rename-Computer -NewName $srvName -Force -Restart