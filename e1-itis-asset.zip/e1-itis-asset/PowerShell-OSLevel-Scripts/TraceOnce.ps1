Param (
    [Parameter(Mandatory = $True, Position = 0)]
    [string] $dstIP
)

$traceResult = (Test-NetConnection $dstIP -TraceRoute).pingsucceeded

If($traceResult -eq 'True')
{
    Return 0
}
Elseif($traceResult -eq 'False')
{
    Return 1
}
