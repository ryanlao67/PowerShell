# Usage
# 1. Copy this script to a server can access target servers need to be patched as Administrator
# 2. Make sure this server has Psexec.exe and add environment path for it
# 3. Run following command to patch target servers in parallel:
#     for /f %i in (serverlist.txt) do start cmd /k "psexec -s \\%i powershell -ExecutionPolicy Bypass -File "\\<ScriptPath>\ApplyUpdates.ps1""
#

# Define log types
$updtDt = Get-Date -format 'yyMMddHHmm'
$updtLogName = "C:\Patching_" + $updtDt + ".log"

# Query applicable updates
$updtSess = New-Object -Com Microsoft.Update.Session
$updtSrch = $updtSess.CreateUpdateSearcher()
"Searching for applicable updates..." | Out-File -filepath $updtLogName -Append
$srchRst = $updtSrch.Search("IsInstalled=0 and Type='Software'")
"List of applicable items on the machine:" | Out-File -filepath $updtLogName -Append
For ($n = 0; $n -lt $srchRst.Updates.Count; $n++){
    $updt = $srchRst.Updates.Item($n)
    ($n + 1).ToString() + ": " + $updt.Title) | Out-File -filepath $updtLogName -Append
}
 
If ($srchRst.Updates.Count -eq 0) {
    "There are no applicable updates." | Out-File -filepath $updtLogName -Append
    Exit 0
}

# Download applicable updates
$updt2Dnld = New-Object -Com Microsoft.Update.UpdateColl
For ($n = 0; $n -lt $srchRst.Updates.Count; $n++)
{
    $updt = $srchRst.Updates.Item($n)
    $NULL = $updt2Dnld.Add($updt)
}
"Downloading Updates..." | Out-File -filepath $updtLogName -Append
$dnlder = $updtSess.CreateUpdateDownloader()
$dnlder.Updates = $updt2Dnld
$NULL = $dnlder.Download()

# Ready to install
$updt2Inst = New-Object -Com Microsoft.Update.UpdateColl
For ($n = 0; $n -lt $srchRst.Updates.Count; $n++)
{
    $updt = $srchRst.Updates.Item($n)
    If ($updt.IsDownloaded)
    {
        $NULL = $updt2Inst.Add($updt)        
    }
}

# Install updates
"Installing Updates..." | Out-File -filepath $updtLogName -Append
$inster = $updtSess.CreateUpdateInstaller()
$inster.Updates = $updt2Inst
$instRst = $inster.Install()
"List of Updates Installed with Results:" | Out-File -filepath $updtLogName -Append
For ($n = 0; $n -lt $updt2Inst.Count; $n++)
{
    $updt2Inst.Item($n).Title + ": " + $instRst.GetUpdateResult($n).ResultCode | Out-File -filepath $updtLogName -Append
}
"Installation Result: " + $instRst.ResultCode | Out-File -filepath $updtLogName -Append
"Reboot Required: " + $instRst.RebootRequired | Out-File -filepath $updtLogName -Append