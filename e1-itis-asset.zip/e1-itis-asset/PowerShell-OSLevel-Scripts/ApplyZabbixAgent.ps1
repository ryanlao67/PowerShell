#Confirm centralized server
$srvName = $ENV:COMPUTERNAME
$domName = (Get-WmiObject -Class WIN32_ComputerSystem).Domain
$ec2PrivateIP = (Get-WmiObject Win32_NetworkAdapterConfiguration -ComputerName $srvName -ErrorAction Stop | Where {$_.IPEnabled}).IPAddress[0]
If ($ec2PrivateIP -match '10.160')
{
    $zbxSRV = '10.160.134.50'
}
Elseif ($ec2PrivateIP -match '10.163')
{
    $zbxSRV = '10.163.30.50'
}
Else
{
    Break;
}

Switch ($domName)
{
    E1EF.COM {$srcSrv = "10.163.25.64";$cpSrv="10.163.25.64"}
    E1SD.COM {$srcSrv = "10.160.114.146";$cpSrv="10.160.114.146"}
}

#Check if Zabbix agent installed
$zbxAgt = Get-Service "Zabbix Agent" -ErrorAction SilentlyContinue
If($zbxAgt.Status -eq "Running")
{
    Break;
}
Else
{
    #Define Event Source
    $awsAuto = "AWS Automation"
    $eventInfo = "7751"
    $eventWrn = "7752"
    $eventErr = "7753"
    If(!([System.Diagnostics.EventLog]::SourceExists($awsAuto)))
    {
        New-EventLog -LogName Application -Source $awsAuto
    }

    #Remote Copy zabbix agent
    If(Test-Path "C:\temp\Zabbix")
    {
        Remove-Item "C:\temp\Zabbix" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
    }

    New-Item "C:\temp\Zabbix" -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
    Copy-Item "\\$cpSrv\Scripts\GroupPolicy\Zabbix_Agent\*" "C:\temp\Zabbix" -Recurse -ErrorAction SilentlyContinue | Out-Null

    #Install and config Zabbix agent
    If(Test-Path 'D:\')
    {
        $zbxLoc = 'D:\Zabbix'
    }
    Else
    {
        $zbxLoc = 'C:\Zabbix'
    }

    New-Item $zbxLoc -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
    Move-Item C:\temp\Zabbix\* $zbxLoc | Out-Null
    Sleep 5
    $zbxLog = "$zbxLoc\zabbix_agentd.log"
    $zbxConf = Get-Content "$zbxLoc\zabbix_agentd.conf"
    $zbxConf[13] = $zbxConf[13].Replace($zbxConf[13], "LogFile=$zbxLog")
    $zbxConf[73] = $zbxConf[73].Replace($zbxConf[73], "Server=$zbxSRV")
    $zbxConf[125] = $zbxConf[125].Replace($zbxConf[125], "Hostname=$srvName")
    Set-Content "$zbxLoc\zabbix_agentd.conf" $zbxConf
    Invoke-WmiMethod -Class Win32_process -Name Create -ArgumentList ("cmd.exe /C $zbxLoc\zabbix_agentd.exe --config $zbxLoc\zabbix_agentd.conf --install") | Out-Null
    Sleep 3
    Invoke-WmiMethod -Class Win32_process -Name Create -ArgumentList ("cmd.exe /C $zbxLoc\zabbix_agentd.exe --config $zbxLoc\zabbix_agentd.conf --start") | Out-Null
    Sleep 3

    $zbxAgt = Get-Service "Zabbix Agent" -ErrorAction SilentlyContinue
    If($zbxAgt.Status -eq "Running")
    {
        $eventMsg = "Zabbix Agent has been installed and running successfully."
        Write-EventLog -Source "$awsAuto" -LogName "Application" -EntryType Information -EventID $eventInfo -Message $eventMsg
    }
    Elseif($zbxAgt.Status -eq "Stopped")
    {
        $eventMsg = "Zabbix Agent has been installed but running failed."
        Write-EventLog -Source "$awsAuto" -LogName "Application" -EntryType Information -EventID $eventWrn -Message $eventMsg
    }
    Else
    {
        $eventMsg = "Zabbix Agent installed failed, please manually check."
        Write-EventLog -Source "$awsAuto" -LogName "Application" -EntryType Information -EventID $eventErr -Message $eventMsg
    }
}

#Add Windows firewall rule for Zabbix
If((Get-NetFirewallRule | where {$_.displayname -eq "Zabbix"}) -eq $NULL)
{
    New-NetFirewallRule -Group 'EF' -DisplayName "Zabbix" -Action Allow -Description "Allow TCP 10050" -Direction Inbound -Enabled True -LocalPort 10050 -Profile Any -Protocol TCP | Out-Null
}