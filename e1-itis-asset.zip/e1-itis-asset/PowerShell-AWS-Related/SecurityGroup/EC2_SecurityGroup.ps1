﻿
#########################################SecurityGroup Mapping#######################################################
[array]$SGMapping=$null
[array]$awsRegions=@("cn-north-1","ap-southeast-1")

Foreach($awsregion in $awsRegions)
{
   switch($awsregion)
    {        
     'cn-north-1'     {$awsprofile="awscn";$locaton="CN"}  
     'ap-southeast-1' {$awsprofile="awsgbl";$locaton="SG"}           
    }


    Get-EC2SecurityGroup -Region $awsregion -ProfileName $awsprofile  | ForEach-Object `
    {
       [array]$InboundRules=$_.ipPermissions

       [string]$SingleResult=$null
       foreach($InboundRule in $InboundRules)
       {
          $SourceIP=$null
          $FromPort=$null
          $Toport=$null

                   
           
         if($InboundRule.ipranges){$SourceIP=$InboundRule.ipranges}
         else{$SourceIP=$InboundRule.UserIdGroupPairs | select -ExpandProperty groupid }
         
         
         $FromPort=$InboundRule.fromport.tostring()
         $Toport=$InboundRule.toport.tostring()
         #$SourceProtocol=$InboundRule.IpProtocol
         #"$SourceIP;$SourcePort;$SourceProtocol"
         #Tag XXXX is used for html format converted, no meaning 
         [string]$SingleResult+="$SourceIP->Portrange $FromPort - $Toport; XXXX `n" 
        }
 
       $output = New-Object psobject
       $output | Add-Member NoteProperty "Region" $locaton
       $output | Add-Member NoteProperty "SGName" $_.GroupName
       $output | Add-Member NoteProperty "ID"   $_.GroupID
       $output | Add-Member NoteProperty "Description"  $_.Description
       $output | Add-Member NoteProperty "Inbound"  $SingleResult.Trim()
       $output 
       $SGMapping+=$output
    }

}

#output for reference
write-host "SecurityGroupMapping.csv was dropped into current folder"
$SGMapping | Export-csv .\SecurityGroupMapping.csv -NoTypeInformation

###########################################EC2 Security Group#####################################################################


[array]$Ec2SecruityGroup=$null

[array]$awsRegions=@("cn-north-1","ap-southeast-1")

Foreach($awsregion in $awsRegions)
{
   switch($awsregion)
    {        
     'cn-north-1'     {$awsprofile="awscn";$locaton="CN"}  
     'ap-southeast-1' {$awsprofile="awsgbl";$locaton="SG"}           
    }

$Instances=(Get-EC2Instance -Region $awsregion -ProfileName $awsprofile).instances

 foreach($EC2 in $Instances)
  {
    
    
    [array]$SGIDs
    [array]$SGIDs=$EC2.securitygroups
    foreach($sgid in  $SGIDs)
           {           
                     $ENv=$null
                     $Team=$null
                     $Servername=$null
                     $InstanceID=$null
                     $PubIP=$null
  
                      $Env=($EC2.tag | ? {$_.key -ieq "ENV"}).value
                      $Team=($EC2.tag | ? {$_.key -ieq "TEAM"}).value
                      $Servername=($EC2.tag | ? {$_.key -ieq "Name"}).value

                      $InstanceID=$EC2.InstanceID
                      $PubIP=$ec2.PublicIpAddress
    

                       $SGName=$null
                       $SGRule=$null
                       $securityID=$null

                       $securityID=$sgid.GroupId
                       $SGName=$SGMapping | ? {$_.ID -eq "$securityID"} | select -ExpandProperty SGName
                       $SGRule=$SGMapping | ? {$_.ID -eq "$securityID"} | select -ExpandProperty Inbound

                       $output3 = New-Object psobject
                       $output3 | Add-Member NoteProperty "Region"      $awsregion
                       $output3 | Add-Member NoteProperty "Env"         $ENv
                       $output3 | Add-Member NoteProperty "Team"        $Team
                       $output3 | Add-Member NoteProperty "Server"      $Servername
                       $output3 | Add-Member NoteProperty "PublicIP"      $PubIP
                       $output3 | Add-Member NoteProperty "ID"          $InstanceID
                       $output3 | Add-Member NoteProperty "SGroupName"  $SGName
                       $output3 | Add-Member NoteProperty "sg-ID"       $securityID
                       $output3 | Add-Member NoteProperty "SGRule"      $SGRule
                       $output3
                       
                       #EC2 Security Result
                       $Ec2SecruityGroup+=$output3
    
            }
   }

}


 #Output the Ec2 security group result
 write-host "EC2SecurityGroup.csv was dropped into current folder"
 $Ec2SecruityGroup | sort region,Env,Team,Server | Export-Csv .\EC2SecurityGroup.csv -NoTypeInformation


#HTML Result output
#Inventory Format
$htmlFormat = "<style>"
$htmlFormat = $htmlFormat + "BODY{font-family: Segoe UI; font-size: 14px;}"
$htmlFormat = $htmlFormat + "TABLE{border-width: 1px; border-style: solid; border-color: black; border-collapse: collapse;}"
$htmlFormat = $htmlFormat + "TH{border-width: 2px; padding: 2px; border-style: solid; border-color: black;}"
$htmlFormat = $htmlFormat + "TD{border-width: 1px; padding: 1px; border-style: solid; border-color: orange; white-space:nowrap;}"
$htmlFormat = $htmlFormat + "</style>"

$Timestamp=get-date

$Temp_EC2SGReport=$null
$Temp_EC2SGReport = $Ec2SecruityGroup | sort region,Env,Team,Server | ConvertTo-HTML -Head $htmlFormat -Body "<H2>EC2 Security Group Detail -Update at $Timestamp</H2>"
$Temp_EC2SGReport | Set-Content  .\Temp_EC2SG.html

$Final_EC2SGReport=$null
$Final_EC2SGReport=gc .\Temp_EC2SG.html
$Final_EC2SGReport=$Final_EC2SGReport -replace ("XXXX","<br>")
$Final_EC2SGReport=$Final_EC2SGReport -creplace ("0.0.0.0/0",'<span style="color:red"><b>0.0.0.0/0</b></span>')
$Final_EC2SGReport | set-Content .\EC2SecurityGroup.html

 write-host "EC2SecurityGroup.html was dropped into current folder"
