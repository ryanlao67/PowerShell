﻿
#########################################SecurityGroup Mapping#######################################################
[array]$SGMapping=$null
[array]$awsRegions=@("cn-north-1","ap-southeast-1")

Foreach($awsregion in $awsRegions)
{
   switch($awsregion)
    {        
     'cn-north-1'     {$awsprofile="awscn";$locaton="CN"}  
     'ap-southeast-1' {$awsprofile="awsgbl";$locaton="SG"}           
    }


    Get-EC2SecurityGroup -Region $awsregion -ProfileName $awsprofile  | ForEach-Object `
    {
       [array]$InboundRules=$_.ipPermissions

       [string]$SingleResult=$null
       foreach($InboundRule in $InboundRules)
       {
          $SourceIP=$null
          $FromPort=$null
          $Toport=$null

                   
           
         if($InboundRule.ipranges){$SourceIP=$InboundRule.ipranges}
         else{$SourceIP=$InboundRule.UserIdGroupPairs | select -ExpandProperty groupid }
         
         
         $FromPort=$InboundRule.fromport.tostring()
         $Toport=$InboundRule.toport.tostring()
         #$SourceProtocol=$InboundRule.IpProtocol
         #"$SourceIP;$SourcePort;$SourceProtocol"
         [string]$SingleResult+="$SourceIP->Portrange $FromPort - $Toport`n" 
        }
 
       $output = New-Object psobject
       $output | Add-Member NoteProperty "Region" $locaton
       $output | Add-Member NoteProperty "SGName" $_.GroupName
       $output | Add-Member NoteProperty "ID"   $_.GroupID
       $output | Add-Member NoteProperty "Description"  $_.Description
       $output | Add-Member NoteProperty "Inbound"  $SingleResult.Trim()
       $output 
       $SGMapping+=$output
    }

}

#output for reference
$SGMapping | Export-csv .\SecurityGroupDetail.csv -NoTypeInformation


##########################################ELB SecurityGroup#######################################################
#ELB SecurityGroup
[array]$awsRegions=@("ap-southeast-1","cn-north-1")
[array]$ELBSGResult=$null
 foreach($region in $awsRegions)
{

    switch($region)
    { 
       'ap-southeast-1' {$profile="awsgbl"}
       'cn-north-1'    {$profile="awscn"}      
    }

    [array]$ELBs=$null
    [array]$ELBs=Get-ELBLoadBalancer -profilename $profile  -region $Region | select -ExpandProperty LoadBalancerName 
           foreach($elb in $ELBs)
           {
              $elbRegion=$region
              $elbName=$elb

              $ELBMode=$null
              $ELBMode=Get-ELBLoadBalancer -profilename $profile  -region $Region -LoadBalancerName $elb | select -ExpandProperty scheme

              [array]$SGIDs=$null
              [array]$SGIDs=(Get-ELBLoadBalancer -profilename $profile  -region $Region -LoadBalancerName $elb).SecurityGroups
                Foreach($sgid in $SGIDs)
                {     
                      $SGName=$null
                      $SGRule=$null
                      $ELBTags=$null
                      $elbEnv=$null
                      $elbTeam=$null
                     
                       $SGName=$SGMapping | ? {$_.ID -eq "$sgid"} | select -ExpandProperty SGName
                       $SGRule=$SGMapping | ? {$_.ID -eq "$sgid"} | select -ExpandProperty Inbound

                       $ELBTags=(Get-ELBTags -LoadBalancerName $elb -ProfileName $profile  -Region $region).tags
                       $elbEnv=($ELBTags | ? {$_.key -ieq "ENV"}).value
                       $elbTeam=($ELBTags | ? {$_.key -ieq "TEAM"}).value


                       $output2 = New-Object psobject
                       $output2 | Add-Member NoteProperty "Region"      $elbRegion
                       $output2 | Add-Member NoteProperty "Env"         $elbEnv
                       $output2 | Add-Member NoteProperty "Team"        $elbTeam
                       $output2 | Add-Member NoteProperty "ELB"         $elb
                       $output2 | Add-Member NoteProperty "ELB-Scheme"      $ELBMode
                       $output2 | Add-Member NoteProperty "SGroupName"  $SGName
                       $output2 | Add-Member NoteProperty "sg-ID"       $sgid
                       $output2 | Add-Member NoteProperty "SGRule"      $SGRule
                       $output2

                       $ELBSGResult+=$output2
                  }
            }
}

Write-Host "ELB_SecurityGroup generated completed" -ForegroundColor Green
$ELBSGResult | Export-Csv .\ELB_SecurityGroup.csv -NoTypeInformation


###############################################ALB SecurityGroup###############################################################
#ALB SecurityGroup
[array]$ALBSGResult=$null
[array]$awsRegions=@("ap-southeast-1","cn-north-1")

foreach($awsregion in $awsRegions)
{

    switch($awsregion)
    { 
       'ap-southeast-1' {$awsprofile="awsgbl"}
       'cn-north-1'     {$awsprofile="awscn"}      
    }

   $albs = Get-ELB2LoadBalancer -ProfileName $awsprofile -Region $awsRegion 

   Foreach($alb in $albs)
   {
        $albArn = $alb.LoadBalancerArn
        $albName = $alb.LoadBalancerName
           
         $ALB_Scheme=$null
         $ALB_Scheme=(Get-ELB2LoadBalancer -profilename $awsprofile  -region $awsRegion -LoadBalancerArn $albArn | select -ExpandProperty scheme).value      

        [array]$ALB_SGIDs=$null
        [array]$ALB_SGIDs=(Get-ELB2LoadBalancer -LoadBalancerArn $albArn -profilename $awsprofile  -region $awsRegion ).SecurityGroups
         Foreach($ALB_sgid in $ALB_SGIDs)
                {     
                      $ALB_SGName=$null
                      $ALB_SGRule=$null
                      
                      $ALB_SGName=$SGMapping | ? {$_.ID -eq "$ALB_sgid"} | select -ExpandProperty SGName
                      $ALB_SGRule=$SGMapping | ? {$_.ID -eq "$ALB_sgid"} | select -ExpandProperty Inbound

                      $albEnv = ((Get-ELB2Tag -ResourceArn $albArn -ProfileName $awsProfile -Region $awsRegion).Tags | ? {$_.key -ieq "ENV"}).value
                      $albTeam= ((Get-ELB2Tag -ResourceArn $albArn -ProfileName $awsProfile -Region $awsRegion).Tags | ? {$_.key -ieq "TEAM"}).value

                       $output3 = New-Object psobject
                       $output3 | Add-Member NoteProperty "Region"      $awsregion
                       $output3 | Add-Member NoteProperty "Env"         $albEnv
                       $output3 | Add-Member NoteProperty "Team"        $albTeam
                       $output3 | Add-Member NoteProperty "ALB"         $albname
                       $output3 | Add-Member NoteProperty "ALB-Scheme"  $ALB_Scheme
                       $output3 | Add-Member NoteProperty "SGroupName"  $ALB_SGName
                       $output3 | Add-Member NoteProperty "sg-ID"       $ALB_sgid
                       $output3 | Add-Member NoteProperty "SGRule"      $ALB_SGRule
                       $output3

                       $ALBSGResult+=$output3
                  }
    } 
     
}

Write-Host "ALB_SecurityGroup generated completed" -ForegroundColor Green
$ALBSGResult | Export-Csv .\ALB_SecurityGroup.csv -NoTypeInformation