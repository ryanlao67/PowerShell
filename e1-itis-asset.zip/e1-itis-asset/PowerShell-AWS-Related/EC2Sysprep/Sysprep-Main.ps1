####################################################################################################
# This script is main script to do EC2 sysprep
# Example:
# .\Sysprep-Main.ps1
####################################################################################################

#Confirm AWS profile name and region
Param (
    [Parameter(Mandatory = $True, Position = 0)]
    [string] $awsProfile,
    
    [Parameter(Mandatory = $True, Position = 1)]
    [string] $awsRegion,

    [Parameter(Mandatory = $True, Position = 2)]
    [string] $ec2InstID
)

Function takeAMI
{
    .\Create-AMI
}

Function LaunchEC2
{

}

takeAMI