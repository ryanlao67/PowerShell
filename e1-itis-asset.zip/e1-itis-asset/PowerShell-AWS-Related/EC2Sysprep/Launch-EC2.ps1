####################################################################################################
# This script is to launch an EC2 instance with specific AMI ID
# Example:
# .\Launch-EC2.ps1 -InstanceId $ec2InstID -ProfileName $awsProfile -Region $awsRegion
####################################################################################################

#Confirm AWS profile name, region and instanceId
Param (
    [Parameter(Mandatory = $True, Position = 0)]
    [string] $awsProfile,
    
    [Parameter(Mandatory = $True, Position = 1)]
    [string] $awsRegion,

    [Parameter(Mandatory = $True, Position = 2)]
    [string] $ec2InstID
)

# Start related EC2 with specific instance ID
# 
Start-EC2Instance -InstanceId $ec2InstID -ProfileName $awsProfile -Region $awsRegion | Out-Null

Start-Sleep 5

While ($ec2Status.status.Status.Value -ne "ok" -or $ec2Status.systemstatus.Status.Value -ne "ok")
{
    # Get related EC2 status check
    $ec2Status = Get-EC2InstanceStatus -InstanceId $ec2InstID -ProfileName $awsProfile -Region $awsRegion
    Write-Host 'Waiting EC2 launch successfully...'
    Start-Sleep 10
}

Return 'ok'