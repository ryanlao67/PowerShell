####################################################################################################
# This script is to take an AMI from an existing EC2 instance
# Example:
# .\Create-AMI.ps1 -InstanceId $ec2InstID -ProfileName $awsProfile -Region $awsRegion
####################################################################################################

#Confirm AWS profile name, region and instanceId
Param (
    [Parameter(Mandatory = $True, Position = 0)]
    [string] $awsProfile,
    
    [Parameter(Mandatory = $True, Position = 1)]
    [string] $awsRegion,

    [Parameter(Mandatory = $True, Position = 2)]
    [string] $ec2InstID
)

$amiNameRaw = Read-Host -Prompt "Please input AMI name(Can be used as previous EC2 name)"

$amiDscp = Read-Host -Prompt "Please input AMI description"

$timeTag = Get-Date -Format "yyyy-MM-dd"

$amiName = $amiNameRaw + "-AMI-" + $timeTag

$amiID = New-EC2Image -InstanceId $ec2InstID -ProfileName $awsProfile -Region $awsRegion `
    -Name $amiName -Description $amiDscp -NoReboot:$TRUE

New-EC2Tag -ProfileName $awsProfile -Region $awsRegion -Resource $amiID `
    -Tags @( @{ Key = "Name" ; Value = $amiName}, @{ Key = "Description"; Value = $amiDscp } )

While ($ec2Image.State.Value -ne "available")
{
    # Get related EC2 status check
    $ec2Image = Get-EC2Image -ImageId $amiID -ProfileName $awsProfile -Region $awsRegion
    Start-Sleep 10
    Write-Host 'Waiting AMI create successfully...'
}

Return 'ok'