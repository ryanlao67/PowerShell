﻿$AllInstances=$null
$CNInstances=Get-EC2Tag -Region cn-north-1 -ProfileName awscn | ? {$_.resourcetype -eq "Instance"} | ? {$_.key -eq "Name"} | select ResourceID,value
$SGInstances=Get-EC2Tag -Region ap-southeast-1 -ProfileName awsgbl | ? {$_.resourcetype -eq "Instance"} | ? {$_.key -eq "Name"} | select ResourceID,value

$AllInstances=$CNInstances
$AllInstances+=$SGInstances


[array]$Result=$null
[array]$awsRegions=@("cn-north-1","ap-southeast-1")


Foreach($awsregion in $awsRegions)
{

    switch($awsregion)
    {        
     'cn-north-1'     {$awsprofile="awscn"; $locaton="CN"}  
     'ap-southeast-1' {$awsprofile="awsgbl";$locaton="SG"}           
    }

    $ASGs=Get-ASAutoScalingGroup -Region $awsregion -ProfileName $awsprofile 
 
  
    Foreach($asg in $ASGs)
    {
    $env=$null
    $Team=$null
    $AsgGroupName=$null
    $createdTime=$null
    $DesiredCapacity=$null
    $MinSize=$null
    $maxSize=$null
    $lunchConfiguration=$null
    $ELBName=$null
    $TGName=$null
    $ASGInstances=$null
    


    $env=$asg.tags | ? {$_.key -ieq "ENV"} | select -ExpandProperty value
    $Team=$asg.tags | ? {$_.key -ieq "Team"} | select -ExpandProperty value

    $AsgGroupName=$asg.autoscalinggroupname
    $createdTime=$asg.createdTime
    $DesiredCapacity=$asg.DesiredCapacity
    $MinSize=$asg.MinSize
    $maxSize=$asg.MaxSize
    $lunchConfiguration=$asg.LaunchConfigurationName
     
    [string]$ELBName=$asg | select -ExpandProperty LoadBalancerNames
    if($asg.TargetGroupARNs){$TGName=$asg.TargetGroupARNs.split("/")[1]}
    Else{$TGName=""}

    
    $ASGInstances=$asg.instances
    [string]$instancesResult=$null
    Foreach($asginstance in $ASGInstances)
      {      
            $insID=$null
            $InsTagName=$null
            $insStatus=$null
            $Protected=$null
            
        
            $insID=$asginstance.instanceid
            $InsTagName=$AllInstances | ? {$_.ResourceId -eq $insID} | select -ExpandProperty value
            $insStatus=$asginstance.LifecycleState
            $Protected=$asginstance.ProtectedFromScaleIn
            [string]$instancesResult+="$InsTagName;$insStatus;$insID;Protected;$Protected"+"`n"
      }
     

   $output = New-Object psobject
   $output | Add-Member NoteProperty "Region"         $locaton
   $output | Add-Member NoteProperty "Env"            $env
   $output | Add-Member NoteProperty "Team"           $Team
   $output | Add-Member NoteProperty "ASGName"        $AsgGroupName
   $output | Add-Member NoteProperty "ELB"            $ELBName
   $output | Add-Member NoteProperty "TargetGroup"    $TGName
   $output | Add-Member NoteProperty "Instances"      $instancesResult
   $output | Add-Member NoteProperty  "CreatedTime"    $createdTime
   $output | Add-Member NoteProperty "DesiredCapacity"  $DesiredCapacity
   $output | Add-Member NoteProperty "MinSize"        $MinSize
   $output | Add-Member NoteProperty "MaxSize"        $maxSize
   $output | Add-Member NoteProperty "LunchConfiguration"        $lunchConfiguration
   $output
   
   $Result+=$output
  
  
  }

}


Write-Host "Rersult drop to your desktop with name ASGResult.csv" -ForegroundColor Green
$timestamp=(get-date).ToString('yyyyMMdd_HHmmss')
$Reportname="ASGResult"+"_"+$timestamp+".csv"

$Result | Export-Csv -Path $Home\desktop\$Reportname -NoTypeInformation

