####################################################################################################
# This script is to get Amazon provided Windows Server AMIs
# Example:
# .\Get-AmazonAMI.ps1 awschina cn-north-1
####################################################################################################

# Un-comment below part if run this script separately.
####################################################################################################
#Param (
#    [Parameter(Mandatory = $True, Position = 0)]
#    [string] $awsProfile,
#    
#    [Parameter(Mandatory = $True, Position = 1)]
#    [string] $awsRegion
#)
####################################################################################################

$ec2OS = Read-Host -Prompt "Please Choose the version of Windows Server(2012 or 2016)"

#Load AWS SDK
Add-Type -Path "C:\Program Files (x86)\AWS SDK for .NET\bin\Net45\AWSSDK.EC2.dll" | Out-Null

Sleep 2

$platfWin = New-Object 'collections.generic.list[string]'
$platfWin.add('windows')
$platFilt = New-Object Amazon.EC2.Model.Filter -Property @{Name = 'platform'; Values = $platfWin} -ErrorAction SilentlyContinue

$amiWin2012 = Get-EC2Image -Owner amazon -Filter $platFilt -ProfileName $awsProfile -Region $awsRegion `
                | Where {$_.Name -match 'English' -and $_.Name -match 'Base' -and $_.Name -match '2012-R2'} `
                | Where {$_.ImageState -eq 'available'} `
                | Sort-Object CreationDate -Descending
$amiWin2016 = Get-EC2Image -Owner amazon -Filter $platFilt -ProfileName $awsProfile -Region $awsRegion `
                | Where {$_.Name -match 'English' -and $_.Name -match 'Full-Base' -and $_.Name -match '2016'} `
                | Where {$_.ImageState -eq 'available'} `
                | Sort-Object CreationDate -Descending

If($ec2OS -ne '2012' -and $ec2OS -ne '2016')
{
    Write-Warning "OS version is not standardized, please re-run the script and input again."
    Break
}

Switch ($ec2OS)
{
    2012 {$amiID = $amiWin2012[0].ImageId}
    2016 {$amiID = $amiWin2016[0].ImageId}
}

Return $amiID