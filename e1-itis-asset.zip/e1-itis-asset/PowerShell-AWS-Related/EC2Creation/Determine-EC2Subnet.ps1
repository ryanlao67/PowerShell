####################################################################################################
# This script is to determine subnet which new EC2 will be located in
# Example:
# .\Determine-EC2Subnet.ps1 awschina cn-north-1
####################################################################################################

# Un-comment below part if run this script separately.
####################################################################################################
#Param (
#    [Parameter(Mandatory = $True, Position = 0)]
#    [string] $awsProfile,
#    
#    [Parameter(Mandatory = $True, Position = 1)]
#    [string] $awsRegion
#)
####################################################################################################

$ec2VPC = Read-Host -Prompt "Please input VPC which new instance will be located in(LIVE or STAGE)"
$ec2Subnet = Read-Host -Prompt "Please choose the subnet which new instance will be located in(Public or Private)"

$vpcinfo = Get-EC2Vpc -ProfileName $awsProfile -Region $awsRegion

Foreach ($vpc in $vpcinfo)
{
    If($vpc.Tags.Value -match 'LIVE')
    {
        $vpcLIVE = $vpc.Vpcid
    }
    Elseif($vpc.Tags.Value -match 'STAGE')
    {
        $vpcSTAGE = $vpc.Vpcid
    }
}

Switch ($ec2VPC)
{
    LIVE {$ec2VPCID = $vpcLIVE}
    STAGE {$ec2VPCID = $vpcSTAGE}
}

$ec2SubnetID = (Get-EC2Subnet -ProfileName $awsProfile -Region $awsRegion `
    | Where {$_.VpcId -eq $ec2VPCID} `
    | Where {$_.Tags.Value -match $ec2Subnet}).SubnetId | Get-Random

Return $ec2SubnetID