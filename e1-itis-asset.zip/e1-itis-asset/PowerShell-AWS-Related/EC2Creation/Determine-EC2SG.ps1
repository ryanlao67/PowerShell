####################################################################################################
# This script is to determine Amazon EC2 security group(s)
# By default, common security group will be attached to all EC2 running Windows Server
# Example:
# .\Determine-EC2SG.ps1 awschina cn-north-1
####################################################################################################

# Un-comment below part if run this script separately.
####################################################################################################
#Param (
#    [Parameter(Mandatory = $True, Position = 0)]
#    [string] $awsProfile,
#    
#    [Parameter(Mandatory = $True, Position = 1)]
#    [string] $awsRegion,
#
#    [Parameter(Mandatory = $True, Position = 2)]
#    [string] $ec2VPC
#)
####################################################################################################

$commonSG = Get-EC2SecurityGroup -ProfileName $awsProfile -Region $awsRegion `
            | Where {$_.GroupName -match 'Common_SecurityGroup'} `
            | Where {$_.GroupName -notmatch 'Linux'} `
            | Where {$_.VpcId -eq $ec2VPC}

$customSG = Read-Host -Prompt "Please confirm if new security group(s) is needed (Y or N)?"

If($customSG -eq 'Y')
{
    $customSGName = Read-Host -Prompt "Please enter new security group name"
    $customSGVPC = Read-Host -Prompt "Please confirm VPC information(LIVE or STAGE)"
    $vpcinform = Get-EC2Vpc -ProfileName $awsProfile -Region $awsRegion

    Foreach ($vpcs in $vpcinform)
    {
        If($vpcs.Tags.Value -match 'LIVE')
        {
            $vpcLIVEInfo = $vpcs.Vpcid
        }
        Elseif($vpcs.Tags.Value -match 'STAGE')
        {
            $vpcSTAGEInfo = $vpcs.Vpcid
        }
        Switch ($customSGVPC)
        {
            LIVE {$customSGVPCID = $vpcLIVEInfo}
            STAGE {$customSGVPCID = $vpcSTAGEInfo}
        }
    }

    If($customSGVPC -ne 'LIVE' -and $customSGVPC -ne 'STAGE')
    {
        Write-Warning "VPC information is invalid, please add new security group later."
        Return $commonSG.GroupId
    }

    $customSGDesc = Read-Host -Prompt "Please input description for this new security group"

    $newCustomSG = New-EC2SecurityGroup -GroupName $customSGName -Description $customSGDesc -VpcId $customSGVPCID -ProfileName $awsProfile -Region $awsRegion -Force

    Return $commonSG.GroupId, $newCustomSG
}
Else
{
    Return $commonSG.GroupId
}