####################################################################################################
# This script is to determine Amazon EC2 type
# Example:
# .\Determine-EC2Type.ps1 awschina cn-north-1
####################################################################################################

# Un-comment below part if run this script separately.
####################################################################################################
#Param (
#    [Parameter(Mandatory = $True, Position = 0)]
#    [string] $awsProfile,
#    
#    [Parameter(Mandatory = $True, Position = 1)]
#    [string] $awsRegion
#)
####################################################################################################

$ec2Type = Read-Host -Prompt "More information, please see EC2Type_Global.json and EC2Type_China.json as reference.`r`nPlease Input EC2 Type"

Return $ec2Type