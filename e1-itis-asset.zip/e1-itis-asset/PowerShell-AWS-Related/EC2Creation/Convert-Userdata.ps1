####################################################################################################
# This script is to encode userdata for new EC2.
# Example:
# .\Convert-Userdata.ps1
####################################################################################################

$userDataRaw = Get-Content ".\awsuserdata.ps1"

$userData = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($userDataRaw))

Return $userData