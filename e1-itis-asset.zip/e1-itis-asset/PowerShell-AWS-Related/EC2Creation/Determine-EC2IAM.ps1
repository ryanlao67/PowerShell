####################################################################################################
# This script is to determine Amazon EC2 IAM role associated
# Example:
# .\Determine-EC2IAM.ps1 awschina cn-north-1
####################################################################################################

# Un-comment below part if run this script separately.
####################################################################################################
#Param (
#    [Parameter(Mandatory = $True, Position = 0)]
#    [string] $awsProfile,
#    
#    [Parameter(Mandatory = $True, Position = 1)]
#    [string] $awsRegion
#)
####################################################################################################

$iamList = Get-IAMRoleList -ProfileName $awsProfile -Region $awsRegion

$iamRoleList = $iamList.Rolename -join "`r`n" | Out-String

$ec2IAM = Read-Host -Prompt "Please enter an IAM role which will be applied to new instance:`r`n$iamRoleList"

If($iamList.Rolename -contains $ec2IAM)
{
    Return $ec2IAM
}
Else
{
    Write-Warning "Input IAM role doesn't exist, please confirm and re-enter again."
    Break
}