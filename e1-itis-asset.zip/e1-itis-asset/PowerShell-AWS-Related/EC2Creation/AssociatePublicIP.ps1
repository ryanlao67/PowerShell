####################################################################################################
# This script is to determine if new EC2 new public or not.
# Example:
# .\AssociatePublicIP.ps1
####################################################################################################

$assPublicIP = Read-Host -Prompt "Please confirm if public IP is needed (Y or N)?"

Switch ($assPublicIP)
{
    Y {$publicIP = $TRUE}
    N {$publicIP = $FALSE}
}

Return $publicIP