####################################################################################################
# This script is to determine which keypair will be used
# Example:
# .\Determine-EC2Key.ps1 awschina cn-north-1
####################################################################################################

# Un-comment below part if run this script separately.
####################################################################################################
#Param (
#    [Parameter(Mandatory = $True, Position = 0)]
#    [string] $awsProfile,
#    
#    [Parameter(Mandatory = $True, Position = 1)]
#    [string] $awsRegion
#)
####################################################################################################

$keyPairs = (Get-EC2KeyPair -ProfileName $awsProfile -Region $awsRegion).KeyName

$keyAvail = $keyPairs -join "`r`n" | Out-String

$ec2Keypair = Read-Host -Prompt "$keyAvail`r`nPlease enter an available keypair from above list"

If($keyPairs -contains $ec2Keypair)
{
    Return $ec2Keypair
}
Else
{
    Write-Warning "Input keypair doesn't exist, please confirm and re-enter again."
    Break
}