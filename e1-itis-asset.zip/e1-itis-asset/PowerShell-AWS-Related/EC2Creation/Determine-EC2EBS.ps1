####################################################################################################
# This script is to determine Amazon EC2 EBS count and size
# Example:
# .\Determine-EC2EBS.ps1 awschina cn-north-1
####################################################################################################

# Un-comment below part if run this script separately.
####################################################################################################
#Param (
#    [Parameter(Mandatory = $True, Position = 0)]
#    [string] $awsProfile,
#    
#    [Parameter(Mandatory = $True, Position = 1)]
#    [string] $awsRegion
#)
####################################################################################################

#Load AWS SDK
Add-Type -Path "C:\Program Files (x86)\AWS SDK for .NET\bin\Net45\AWSSDK.EC2.dll" | Out-Null
Sleep 2

[Int]$ebsCount = Read-Host "Please confirm how many EBS drives will be used by new instance(input a number)"

If($ebsCount.GetType().Name -eq 'Int32')
{
    If($ebsCount -eq 0)
    {
        Write-Warning "Please input a correct number."
        Break
    }
    Else
    {
        $rootEBS = New-Object Amazon.EC2.Model.EbsBlockDevice
        $rootEBS.VolumeSize = 50
        $rootEBS.VolumeType = 'gp2'
        $rootEBS.DeleteOnTermination = $true
        $rootEBSMap = New-Object Amazon.EC2.Model.BlockDeviceMapping
        $rootEBSMap.DeviceName = '/dev/sda1'
        $rootEBSMap.Ebs = $rootEBS

        If($ebsCount -eq 2)
        {
            $ebsDevName = 'xvdb'
            $appEBS = New-Object Amazon.EC2.Model.EbsBlockDevice
            $appEBS.VolumeSize = Read-Host "Please input a number of EBS size(Default is 30)"
            $appEBS.VolumeType = 'gp2'
            $appEBS.DeleteOnTermination = $true
            $appEBSMap = New-Object Amazon.EC2.Model.BlockDeviceMapping
            $appEBSMap.DeviceName = 'xvdb'
            $appEBSMap.Ebs = $appEBS
        }
        Elseif($ebsCount -gt 2)
        {
            Write-Warning "Please add EBS after EC2 launched."
            Continue
        }
    }
}
Else
{
    Write-Warning "Please input a number instead of letter(s) here."
    Break
}

If($appEBSMap)
{
    Return $rootEBSMap, $appEBSMap
}
Else
{
    Return $rootEBSMap
}