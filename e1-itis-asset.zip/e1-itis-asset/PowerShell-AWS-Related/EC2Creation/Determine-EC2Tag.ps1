####################################################################################################
# This script is to determine which tags will be used
# Example:
# .\Determine-EC2Tag.ps1 awschina cn-north-1
####################################################################################################

# Un-comment below part if run this script separately.
####################################################################################################
#Param (
#    [Parameter(Mandatory = $True, Position = 0)]
#    [string] $awsProfile,
#    
#    [Parameter(Mandatory = $True, Position = 1)]
#    [string] $awsRegion
#)
####################################################################################################

#Load AWS SDK
Add-Type -Path "C:\Program Files (x86)\AWS SDK for .NET\bin\Net45\AWSSDK.EC2.dll" | Out-Null
Sleep 2

$ec2Name = Read-Host -Prompt "Please input EC2 name"
If($ec2Name -notmatch 'CNE1' -and $ec2Name -notmatch 'SGE1')
{
    Write-Warning "Input EC2 name doesn't conform our standard, please input again."
    Break
}

$ec2ENV = Read-Host -Prompt "Please input EC2 environment(LIVE, STG, QA or POC)"
If($ec2ENV -eq "" -or ($ec2ENV -ne 'LIVE' -and $ec2ENV -ne 'STG' -and $ec2ENV -ne 'QA' -and $ec2ENV -ne 'POC'))
{
    Write-Warning "No input for EC2 environment or environment value is wrong, please input again."
    Break
}

$ec2Team = Read-Host -Prompt "Please input which team owns this EC2`r`n(BI | BSD | GDM | ITIS | PD | PSS | SF)"
If($ec2Team -eq "" -or ($ec2Team -ne 'BI' -and $ec2Team -ne 'BSD' -and $ec2Team -ne 'GDM' -and $ec2Team -ne 'ITIS' -and $ec2Team -ne 'PD' -and $ec2Team -ne 'PSS' -and $ec2Team -ne 'SF'))
{
    Write-Warning "No input for EC2 team or team value is wrong, please input again."
    Break
}

$ec2Purpose = Read-Host -Prompt "Please input purpose for this EC2"
If($ec2Purpose -eq "")
{
    Write-Warning "No input for purpose, please add it later!"
}

$ec2Project = Read-Host -Prompt "Please input project for this EC2"
If($ec2Project -eq "")
{
    Write-Warning "No input for project, please add it later!"
}

$ec2TagName = @{ Key="Name"; Value=$ec2Name }
$ec2TagENV = @{ Key="ENV"; Value=$ec2ENV }
$ec2TagTeam = @{ Key="TEAM"; Value=$ec2Team }
$ec2TagPurpose = @{ Key="PURPOSE"; Value=$ec2Purpose }
$ec2TagProject = @{ Key="PROJECT"; Value=$ec2Project }

$ec2TagSpec1 = New-Object Amazon.EC2.Model.TagSpecification
$ec2TagSpec1.ResourceType = "instance"
$ec2TagSpec1.Tags.Add($ec2TagName)

$ec2TagSpec2 = New-Object Amazon.EC2.Model.TagSpecification
$ec2TagSpec2.ResourceType = "instance"
$ec2TagSpec2.Tags.Add($ec2TagENV)

$ec2TagSpec3 = New-Object Amazon.EC2.Model.TagSpecification
$ec2TagSpec3.ResourceType = "instance"
$ec2TagSpec3.Tags.Add($ec2TagTeam)

$ec2TagSpec4 = New-Object Amazon.EC2.Model.TagSpecification
$ec2TagSpec4.ResourceType = "instance"
$ec2TagSpec4.Tags.Add($ec2TagPurpose)

$ec2TagSpec5 = New-Object Amazon.EC2.Model.TagSpecification
$ec2TagSpec5.ResourceType = "instance"
$ec2TagSpec5.Tags.Add($ec2TagProject)

Return $ec2TagSpec1, $ec2TagSpec2, $ec2TagSpec3, $ec2TagSpec4, $ec2TagSpec5