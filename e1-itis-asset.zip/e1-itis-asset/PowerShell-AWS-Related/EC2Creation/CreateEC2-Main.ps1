####################################################################################################
# This script is main script to launch a new EC2 instance in AWS
# Example:
# .\CreateEC2-Main.ps1
####################################################################################################

#Confirm AWS profile name and region
Param (
    [Parameter(Mandatory = $True, Position = 0)]
    [string] $awsProfile,
    
    [Parameter(Mandatory = $True, Position = 1)]
    [string] $awsRegion
)

Function ConfirmAMI
{
    .\Get-AmazonAMI.ps1
}

Function ConfirmEC2Type
{
    .\Determine-EC2Type.ps1
}

Function ConfirmSubnet
{
    .\Determine-EC2Subnet.ps1
}

Function ConfirmPublicIP
{
    .\AssociatePublicIP.ps1
}

Function ConfirmKey
{
    .\Determine-EC2Key.ps1
}

Function ConfirmUserdata
{
    .\Convert-Userdata.ps1
}

Function ConfirmTag
{
    .\Determine-EC2Tag.ps1
}

Function ConfirmIAM
{
    .\Determine-EC2IAM.ps1
}

Function ConfirmEBS
{
    .\Determine-EC2EBS.ps1
}

$ec2AMIID = ConfirmAMI
$ec2Type = ConfirmEC2Type
$ec2Subnet = ConfirmSubnet
$ec2PublicIP = ConfirmPublicIP
$ec2Key = ConfirmKey
$ec2Userdata = ConfirmUserdata
$ec2Tag = ConfirmTag
$ec2IAM = ConfirmIAM
$ec2EBS = ConfirmEBS
$ec2VPC = (Get-EC2Subnet -SubnetId $ec2Subnet -ProfileName $awsProfile -Region $awsRegion).VpcId

Function ConfirmSG
{
    .\Determine-EC2SG.ps1
}

$ec2SG = ConfirmSG

Write-Host "Plese confirm below information before EC2 creation:" -ForegroundColor Green
Write-Host "EC2 AMI ID: "$ec2AMIID
Write-Host "EC2 Type: "$ec2Type
Write-Host "EC2 Subnet: "$ec2Subnet
Write-Host "Public IP: "$ec2PublicIP
Write-Host "Keypair: "$ec2Key
Write-Host "IAM Role: "$ec2IAM
Write-Host "EC2 Security Group: "$ec2SG

$infoConfirmed = Read-Host -Prompt "Ready to launch(Y or N)?"

If($infoConfirmed -eq 'Y')
{
    New-EC2Instance -ProfileName $awsProfile -Region $awsRegion -BlockDeviceMapping $ec2EBS -ImageId $ec2AMIID -AssociatePublicIp $ec2PublicIP -KeyName $ec2Key -SecurityGroupId $ec2SG -UserData $ec2Userdata -InstanceType $ec2Type -SubnetId $ec2Subnet -InstanceProfile_Name $ec2IAM
}
Elseif($infoConfirmed -eq 'N')
{
    Write-Host "Please double confirm information and rerun this script again."
    Break
}