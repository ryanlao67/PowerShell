Param (
    [Parameter(Mandatory = $True, Position = 0)]
    [string] $awsProfile,
    
    [Parameter(Mandatory = $True, Position = 1)]
    [string] $awsRegion,

    [Parameter(Mandatory = $True, Position = 2)]
    [string] $instList,

    [Parameter(Mandatory = $False, Position = 3)]
    [string] $amiDscp,

    [Parameter(Mandatory = $True, Position = 4)]
    [string] $amiList
)

$ec2ImageList = @()

Foreach ($instID in Get-Content $instList)
{
    $instInfoRaw = (Get-EC2Instance -InstanceId $instID -ProfileName $awsProfile -Region $awsRegion).Instances
    $amiNameRaw = ($instInfoRaw.Tags | Where {$_.Key -ieq 'Name'}).Value
    $timeTag = Get-Date -Format "yyyy-MM-dd"
    $amiName = $amiNameRaw + "-AMI-" + $timeTag
    $amiID = New-EC2Image `
        -InstanceId $instID `
        -ProfileName $awsProfile `
        -Region $awsRegion `
        -Name $amiName `
        -Description $amiDscp `
        -NoReboot:$TRUE
    New-EC2Tag -ProfileName $awsProfile `
        -Region $awsRegion `
        -Resource $amiID `
        -Tags @( @{ Key = "Name" ; Value = $amiName}, @{ Key = "Description"; Value = $amiDscp } )
    $ec2Image = (Get-EC2Image -ImageId $amiID -ProfileName $awsProfile -Region $awsRegion).ImageId
    $ec2ImageList += $ec2Image
}

$ec2ImageList | Set-Content $amiList