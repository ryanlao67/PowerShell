﻿$userDataString = @‘

‘@


$EncodeUserData = [System.Text.Encoding]::UTF8.GetBytes($userDataString)
$userData = [System.Convert]::ToBase64String($EncodeUserData)
$shortTime = Get-Date -Format "yyyy-MM-dd" # Shorter date for the name tag
$ServerNames = @("CNE1PRDOCP-A01","SGE1PRDOCP-A01","CNE1PRDTBV3-W01","SGE1PRDTBV3-W01")
#$ServerNames = @(“SGE1PRDOMNI-SS2”,”SGE1PRDOMNI-JC2”,”SGE1PRDOMNI-OP2”,”SGE1PRDOMNI-F2”,”SGE1PRDOMNI-FI2”,”SGE1PRDOMNI-NF2”,“CNE1PRDOMNI-OP2”,”CNE1PRDOMNI-JC2”,”CNE1PRDOMNI-SS2”,”CNE1PRDOMNI-F2”,”CNE1PRDOMNI-FI2”,”CNE1PRDESB-A02”,”CNE1PRDOMNI-NF2”)
#$ServerNames = @("CNE1STGOMNI-OP1","CNE1STGOMNI-NF1","CNE1STGOMNI-JC1","CNE1STGOMNI-FI1", "CNE1STGOMNI-F1","CNE1STGOMNI-SS2","CNE1STGESB-A01","SGE1STGOMNI-NF1","SGE1STGOMNI-JC1","SGE1STGOMNI-F2","SGE1STGOMNI-F1","SGE1STGOMNI-SSO","SGE1STGESB-A01","SGE1STGOMNI-OP1")
#$ServerNames = @("CNE1PRDOSP-A01","SGE1PRDOSP-A01","CNE1PRDTPI-W01","SGE1PRDTPI-W01","CNE1PRDTBV3-W01","SGE1PRDTBV3-W01")
foreach ($ServerName in $ServerNames) 
    {
     $name = $ServerName+ "_" + $shortTime
     if($ServerName.StartsWith(‘CN’))
     {
    $Profilename = ‘awscn’
    $Region = 'cn-north-1'
     }
     else
     {
    $Profilename = ‘awsgbl’
    $Region = 'ap-southeast-1'
     }
    
    $instanceID = Get-EC2Instance -ProfileName $Profilename -Region $Region -Filter @{name='tag:Name'; values=$ServerName} | Select -ExpandProperty instances #Get instance ID
        
    $AssociatePublicIpAddress = $False

    if($instanceID.PublicIPAddress.Length -gt 0)
    {
    $AssociatePublicIpAddress = $True
    }

    $InstanceType = Get-EC2Instance -ProfileName $Profilename -Region $Region -InstanceId $instanceID.InstanceId | Select -ExpandProperty instances
    $KeyName = Get-EC2Instance -ProfileName $Profilename -Region $Region -InstanceId $instanceID.InstanceId | Select -ExpandProperty instances
    $IAMRole = Get-EC2Instance -ProfileName $Profilename -Region $Region -InstanceId $instanceID.InstanceId | Select -ExpandProperty instances
    $AutoScalingGroupName = Get-ASAutoScalingInstance -ProfileName $Profilename -Region $Region -InstanceId $instanceID.InstanceId
    $SpotPriceLC  = (Get-ASLaunchConfiguration -ProfileName $Profilename -Region $Region -MaxRecord 1) | Where-Object {$_.LaunchConfigurationName -like "*$ServerName*"} 
    $SpotPrice = $SpotPriceLC.SpotPrice
    $IAMRole = $SpotPriceLC.IamInstanceProfile

    $SecurityGroups = Get-EC2Instance -ProfileName $Profilename -Region $Region -InstanceId $instanceID.InstanceId | Select -ExpandProperty instances 
    $SecurityGroupId = @($SecurityGroups.SecurityGroups)

    $SecurityGroupArray = @()

    for($i=0;$i -lt $SecurityGroupId.count; $i++) 
    {
        $SecurityGroupArray += $SecurityGroupId[$i].GroupId
    }

    $amiId = New-EC2Image -Description $name -InstanceId $instanceID.InstanceId -Name $name -NoReboot $true -ProfileName $Profilename -Region $Region #User Data script to configure instance

    Start-Sleep -Seconds 25

    New-ASLaunchConfiguration -LaunchConfigurationName $name -ImageId $amiId -InstanceType $InstanceType.InstanceType -SecurityGroup $SecurityGroupArray -KeyName $KeyName.KeyName -UserData $userData -AssociatePublicIpAddress $AssociatePublicIpAddress -ProfileName $Profilename -Region $Region -IamInstanceProfile $IAMRole -SpotPrice $SpotPrice

    Start-Sleep -Seconds 2

    Update-ASAutoScalingGroup -AutoScalingGroupName $AutoScalingGroupName.AutoScalingGroupName -LaunchConfigurationName $name -ProfileName $Profilename -Region $Region

    echo $ServerName
  }
