$awsProfile = 'awsgbl'
$awsRegion = 'ap-southeast-1'
$e1assetS3 = 'e1-osp'
$backupS3 = 'e1-assetsbackup'

$purgeDate = (Get-Date).AddDays(-7).ToString("yyyyMMdd")
$purgeDaily = 'E1Asset/daily/' + $purgeDate

$e1assetEvent = "E1Asset Backup"
If(!([System.Diagnostics.EventLog]::SourceExists($e1assetEvent)))
{
    New-EventLog -LogName Application -Source $e1assetEvent
}

$eventInfo = "8761"
$eventErr = "8762"

$e1assetPurgeKeys = (Get-S3Object -BucketName $backupS3 -KeyPrefix $purgeDaily -ProfileName $awsProfile -Region $awsRegion).Key
Foreach($e1assetPurgeKey in $e1assetPurgeKeys)
{
    Remove-S3Object -BucketName $backupS3 -Key $e1assetPurgeKey `
        -ProfileName $awsProfile `
        -Region $awsRegion `
        -Force | Out-Null
}
If($Error)
{
    Write-EventLog -Source "$e1assetEvent" -LogName "Application" -EntryType Error -EventID $eventErr -Message $Error[0].Exception
    Break
}
Else
{
    $timeSlot = Get-Date
    $eventMsg = "Purge old backup for E1Asset in SG successfully on $timeSlot"
    Write-EventLog -Source "$e1assetEvent" -LogName "Application" -EntryType Information -EventID $eventInfo -Message $eventMsg
}