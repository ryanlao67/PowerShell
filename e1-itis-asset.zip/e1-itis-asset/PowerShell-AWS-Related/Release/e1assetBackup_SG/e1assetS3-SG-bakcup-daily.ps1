$awsProfile = 'awsgbl'
$awsRegion = 'ap-southeast-1'
$e1assetS3 = 'e1-osp'
$backupS3 = 'e1-assetsbackup'

$bakDate = (Get-Date).ToString("yyyyMMdd")
$bakFolder = 'E1Asset/daily/' + $bakDate

$e1assetEvent = "E1Asset Backup"
If(!([System.Diagnostics.EventLog]::SourceExists($e1assetEvent)))
{
    New-EventLog -LogName Application -Source $e1assetEvent
}

$eventInfo = "8751"
$eventErr = "8752"

aws s3 cp "s3://$e1assetS3/" "s3://$backupS3/$bakFolder/" --recursive --profile $awsProfile --region $awsRegion | Out-Null

If($Error)
{
    Write-EventLog -Source "$e1assetEvent" -LogName "Application" -EntryType Error -EventID $eventErr -Message $Error[0].Exception
    Break
}
Else
{
    $timeSlot = Get-Date
    $eventMsg = "Backup for E1Asset in SG successfully on $timeSlot"
    Write-EventLog -Source "$e1assetEvent" -LogName "Application" -EntryType Information -EventID $eventInfo -Message $eventMsg
}