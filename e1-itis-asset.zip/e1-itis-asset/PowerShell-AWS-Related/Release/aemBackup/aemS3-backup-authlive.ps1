$awsProfile = 'awscn'
$awsRegion = 'cn-north-1'
$aemS3 = 'e1aembackup'
$backupS3 = 'e1-assetsbackup'

$bakDate = (Get-Date).ToString("yyyyMMdd")
$bakFolder = 'AEM/auth_live/daily/' + $bakDate

$aemEvent = "AEM Backup"
If(!([System.Diagnostics.EventLog]::SourceExists($aemEvent)))
{
    New-EventLog -LogName Application -Source $aemEvent
}

$eventInfo = "9751"
$eventErr = "9752"

aws s3 cp "s3://$aemS3/authlive/live/" "s3://$backupS3/$bakFolder/" --recursive --profile $awsProfile | Out-Null

If($Error)
{
    Write-EventLog -Source "$aemEvent" -LogName "Application" -EntryType Error -EventID $eventErr -Message $Error[0].Exception
    Break
}
Else
{
    $timeSlot = Get-Date
    $eventMsg = "Backup for authlive successfully on $timeSlot"
    Write-EventLog -Source "$aemEvent" -LogName "Application" -EntryType Information -EventID $eventInfo -Message $eventMsg
}