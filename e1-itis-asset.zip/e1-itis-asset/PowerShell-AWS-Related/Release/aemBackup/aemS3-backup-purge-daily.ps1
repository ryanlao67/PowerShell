$awsProfile = 'awscn'
$awsRegion = 'cn-north-1'
$aemS3 = 'e1aembackup'
$backupS3 = 'e1-assetsbackup'

$purgeDate = (Get-Date).AddDays(-7).ToString("yyyyMMdd")
$purgeDaily = 'daily/' + $purgeDate

$aemEvent = "AEM Backup"
If(!([System.Diagnostics.EventLog]::SourceExists($aemEvent)))
{
    New-EventLog -LogName Application -Source $aemEvent
}

$eventInfo = "9761"
$eventErr = "9762"

#Purge old backup for authlive
$authlivePurgeKeys = (Get-S3Object -BucketName $backupS3 -KeyPrefix "AEM/auth_live/$purgeDaily" -ProfileName $awsProfile -Region $awsRegion).Key
Foreach($authlivePurgeKey in $authlivePurgeKeys)
{
    Remove-S3Object -BucketName $backupS3 -Key $authlivePurgeKey `
        -ProfileName $awsProfile `
        -Region $awsRegion `
        -Force | Out-Null
}
If($Error)
{
    Write-EventLog -Source "$aemEvent" -LogName "Application" -EntryType Error -EventID $eventErr -Message $Error[0].Exception
    Break
}
Else
{
    $timeSlot = Get-Date
    $eventMsg = "Purge old backup for authlive successfully on $timeSlot"
    Write-EventLog -Source "$aemEvent" -LogName "Application" -EntryType Information -EventID $eventInfo -Message $eventMsg
}

#Purge old backup for authstg
$authstgPurgeKeys = (Get-S3Object -BucketName $backupS3 -KeyPrefix "AEM/auth_stg/$purgeDaily" -ProfileName $awsProfile -Region $awsRegion).Key
Foreach($authstgPurgeKey in $authstgPurgeKeys)
{
    Remove-S3Object -BucketName $backupS3 -Key $authstgPurgeKey `
        -ProfileName $awsProfile `
        -Region $awsRegion `
        -Force | Out-Null
}
If($Error)
{
    Write-EventLog -Source "$aemEvent" -LogName "Application" -EntryType Error -EventID $eventErr -Message $Error[0].Exception
    Break
}
Else
{
    $timeSlot = Get-Date
    $eventMsg = "Purge old backup for authstg successfully on $timeSlot"
    Write-EventLog -Source "$aemEvent" -LogName "Application" -EntryType Information -EventID $eventInfo -Message $eventMsg
}

#Purge old backup for publive
$publivePurgeKeys = (Get-S3Object -BucketName $backupS3 -KeyPrefix "AEM/pub_live/$purgeDaily" -ProfileName $awsProfile -Region $awsRegion).Key
Foreach($publivePurgeKey in $publivePurgeKeys)
{
    Remove-S3Object -BucketName $backupS3 -Key $publivePurgeKey `
        -ProfileName $awsProfile `
        -Region $awsRegion `
        -Force | Out-Null
}
If($Error)
{
    Write-EventLog -Source "$aemEvent" -LogName "Application" -EntryType Error -EventID $eventErr -Message $Error[0].Exception
    Break
}
Else
{
    $timeSlot = Get-Date
    $eventMsg = "Purge old backup for publive successfully on $timeSlot"
    Write-EventLog -Source "$aemEvent" -LogName "Application" -EntryType Information -EventID $eventInfo -Message $eventMsg
}

#Purge old backup for pubstg
$pubstgPurgeKeys = (Get-S3Object -BucketName $backupS3 -KeyPrefix "AEM/pub_stg/$purgeDaily" -ProfileName $awsProfile -Region $awsRegion).Key
Foreach($pubstgPurgeKey in $pubstgPurgeKeys)
{
    Remove-S3Object -BucketName $backupS3 -Key $pubstgPurgeKey `
        -ProfileName $awsProfile `
        -Region $awsRegion `
        -Force | Out-Null
}
If($Error)
{
    Write-EventLog -Source "$aemEvent" -LogName "Application" -EntryType Error -EventID $eventErr -Message $Error[0].Exception
    Break
}
Else
{
    $timeSlot = Get-Date
    $eventMsg = "Purge old backup for pubstg successfully on $timeSlot"
    Write-EventLog -Source "$aemEvent" -LogName "Application" -EntryType Information -EventID $eventInfo -Message $eventMsg
}