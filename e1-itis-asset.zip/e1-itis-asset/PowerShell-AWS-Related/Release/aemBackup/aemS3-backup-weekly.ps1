$awsProfile = 'awscn'
$awsRegion = 'cn-north-1'
$aemS3 = 'e1aembackup'
$backupS3 = 'e1-assetsbackup'

$bakDate = (Get-Date).ToString("yyyyMMdd")
$bakFolder = 'weekly/' + $bakDate

$aemEvent = "AEM Backup"
If(!([System.Diagnostics.EventLog]::SourceExists($aemEvent)))
{
    New-EventLog -LogName Application -Source $aemEvent
}

$eventInfo = "9753"
$eventErr = "9754"

#Backup authlive
aws s3 cp "s3://$aemS3/authlive/live/" "s3://$backupS3/AEM/auth_live/$bakFolder/" --recursive --profile $awsProfile | Out-Null

If($Error)
{
    Write-EventLog -Source "$aemEvent" -LogName "Application" -EntryType Error -EventID $eventErr -Message $Error[0].Exception
    Break
}
Else
{
    $timeSlot = Get-Date
    $eventMsg = "Backup for authlive successfully on $timeSlot"
    Write-EventLog -Source "$aemEvent" -LogName "Application" -EntryType Information -EventID $eventInfo -Message $eventMsg
}

#Backup authstg
aws s3 cp "s3://$aemS3/authstg/live/" "s3://$backupS3/AEM/auth_stg/$bakFolder/" --recursive --profile $awsProfile | Out-Null

If($Error)
{
    Write-EventLog -Source "$aemEvent" -LogName "Application" -EntryType Error -EventID $eventErr -Message $Error[0].Exception
    Break
}
Else
{
    $timeSlot = Get-Date
    $eventMsg = "Backup for authstg successfully on $timeSlot"
    Write-EventLog -Source "$aemEvent" -LogName "Application" -EntryType Information -EventID $eventInfo -Message $eventMsg
}

#Backup publive
aws s3 cp "s3://$aemS3/publive/live/" "s3://$backupS3/AEM/pub_live/$bakFolder/" --recursive --profile $awsProfile | Out-Null

If($Error)
{
    Write-EventLog -Source "$aemEvent" -LogName "Application" -EntryType Error -EventID $eventErr -Message $Error[0].Exception
    Break
}
Else
{
    $timeSlot = Get-Date
    $eventMsg = "Backup for publive successfully on $timeSlot"
    Write-EventLog -Source "$aemEvent" -LogName "Application" -EntryType Information -EventID $eventInfo -Message $eventMsg
}

#Backup pubstg
aws s3 cp "s3://$aemS3/pubstg/live/" "s3://$backupS3/AEM/pub_stg/$bakFolder/" --recursive --profile $awsProfile | Out-Null

If($Error)
{
    Write-EventLog -Source "$aemEvent" -LogName "Application" -EntryType Error -EventID $eventErr -Message $Error[0].Exception
    Break
}
Else
{
    $timeSlot = Get-Date
    $eventMsg = "Backup for pubstg successfully on $timeSlot"
    Write-EventLog -Source "$aemEvent" -LogName "Application" -EntryType Information -EventID $eventInfo -Message $eventMsg
}