﻿[array]$totalResult=$null
[array]$Regions=@("cn-north-1","ap-southeast-1")

foreach($region in $Regions)
{

    switch($region)
    { 
       'ap-southeast-1' {$profile="awsgbl"}
       'cn-north-1'    {$profile="awscn"}      
    }


    [array]$ELBs=Get-ELBLoadBalancer -profilename $profile  -region $Region | select -ExpandProperty LoadBalancerName 
           foreach($elb in $ELBs)
           {
              
              $ELBTags=(Get-ELBTags -LoadBalancerName $elb -ProfileName $profile  -Region $region).tags
              $elbEnv=($ELBTags | ? {$_.key -ieq "ENV"}).value
              $elbTeam=($ELBTags | ? {$_.key -ieq "TEAM"}).value

              $TempResult=$null
              $TempResult=Get-ELBLoadBalancer -LoadBalancerName $elb -profilename $profile  -region $Region

              $elbDNSName=$TempResult | select -ExpandProperty dnsname
             
              [array]$elbInstances=( $TempResult | select -ExpandProperty Instances).instanceID
              [string]$servers=$null
                     foreach($elbinstance in $elbInstances)
                      {      
                           [string]$elbinstanceID=$null
                           [string]$servername=$null 
                                                    
                           [string]$elbinstanceID=$elbinstance
                           $servername = (((Get-EC2Instance -InstanceId $elbinstance -ProfileName $Profile -Region $Region).Instances).tags | Where {$_.Key -ieq 'Name'}).Value
                          #[string]$servername=Get-EC2Tag -ProfileName $profile  -Region $Region | ? {$_.ResourceID -eq $elbinstance} | ?{$_.key -ieq "Name"} | select -ExpandProperty Value
                           [string]$servers+=$servername+";"+$elbinstanceID+";"+"`n"                     
                     
                      }

               #Output the result

               #"$elbEnv;$elbTeam;$elb;$elbDNSName;$servers" 
               $output = New-Object psobject
               $output | Add-Member NoteProperty  "Env"  $elbEnv
               $output | Add-Member NoteProperty  "Team"  $elbTeam
               $output | Add-Member NoteProperty  "ELB"   $ELB
               $output | Add-Member NoteProperty  "DNS"   $elbDNSName
               $output | Add-Member NoteProperty  "ELB-Instances"  $servers.trim()
               $output 
               [array]$totalResult+=$output                     
           
           
           }


}

#
#output the finally result
"ELB Result Getting Done !!!"
$totalResult | Export-Csv $HOME\desktop\ELB\ELBResultV3.csv -NoTypeInformation