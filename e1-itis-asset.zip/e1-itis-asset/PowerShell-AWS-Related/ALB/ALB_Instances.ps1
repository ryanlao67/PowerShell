﻿[array]$totalResult=$null
[array]$awsRegions=@("cn-north-1","ap-southeast-1")

foreach($awsregion in $awsRegions)
{

    switch($awsregion)
    { 
       'ap-southeast-1' {$awsprofile="awsgbl"}
       'cn-north-1'     {$awsprofile="awscn"}      
    }

   $albs = Get-ELB2LoadBalancer -ProfileName $awsprofile -Region $awsRegion 

   Foreach($alb in $albs)
   {
        $albArn = $alb.LoadBalancerArn
        $albName = $alb.LoadBalancerName

        $albEnv = ((Get-ELB2Tag -ResourceArn $albArn -ProfileName $awsProfile -Region $awsRegion).Tags | ? {$_.key -ieq "ENV"}).value
        $albTeam= ((Get-ELB2Tag -ResourceArn $albArn -ProfileName $awsProfile -Region $awsRegion).Tags | ? {$_.key -ieq "TEAM"}).value

        $albTargetGroups = Get-ELB2TargetGroup -LoadBalancerArn $albArn -ProfileName $awsProfile -Region $awsRegion
        Foreach ($albTargetGroup in $albTargetGroups)
        {
           
            $albTGName=$albTargetGroup.TargetGroupName
            $albTGArn = $albTargetGroup.TargetGroupARN
           
            $albTGInsts = Get-ELB2TargetHealth -TargetGroupArn $albTGArn -ProfileName $awsProfile -Region $awsRegion
            [string]$servers=$null
            Foreach($albTGInst in $albTGInsts)
                   {
                     $albTGInstance=$null
                     $ec2Inst=$null
                     $servername=$null

                     $albTGInstance = $albTGInst.Target.Id
                     $ec2Inst = (Get-EC2Instance -InstanceId $albTGInstance -ProfileName $awsProfile -Region $awsRegion).Instances
                     [string]$servername = ($ec2Inst.Tags | Where {$_.Key -ieq 'Name'}).Value
                     $servers+=$servername+";"+$albTGInstance+";"+"`n"
                    }

          $output = New-Object psobject
          $output | Add-Member NoteProperty  "Env"            $albEnv
          $output | Add-Member NoteProperty  "Team"           $albTeam
          $output | Add-Member NoteProperty  "ALB"            $albName
          $output | Add-Member NoteProperty  "TargetGroup"    $albTGName
          $output | Add-Member NoteProperty  "TG-Instances"   $servers.Trim()
          $output 
         [array]$totalResult+=$output 

        }
    }
}

#
#output the finally result
"ALB Result Getting Done !!!"
$totalResult| Export-Csv  $home\desktop\ELB\ALBResult.csv -NoTypeInformation
    


      