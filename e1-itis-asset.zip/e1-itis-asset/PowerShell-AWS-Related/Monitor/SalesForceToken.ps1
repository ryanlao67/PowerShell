$returnValue = curl.exe -s -w '%{http_code}' -X POST https://login.salesforce.com/services/oauth2/token -F client_secret=7407882411961062278 -F client_id=3MVG9ZL0ppGP5UrDWuA2_BdSn2yFCaKgJG2efR7mLJytMRJ4qE2a8BHZTCkgBe4uxwsrpJ0tOpQ8qUFGsv3x9 -F grant_type=password -F username=learning@ef.com -F password='$9c@0I3Q%9s*LQkYyS51lyvY8a26aOqLSqHu28CKXo7f'
$statusCode = $returnValue.Substring($returnValue.get_Length()-3)
$content = $returnValue.SubString(0,15)
If($statusCode -eq 200 -and $content -match "access_token")
{
    return 0
}
Else
{
    return 1
}