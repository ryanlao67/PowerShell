Param (
    [Parameter(Mandatory = $True, Position = 0)]
    [string] $awsProfile,
    
    [Parameter(Mandatory = $True, Position = 1)]
    [string] $awsRegion
)

$volType = Read-Host -Prompt "Please input volume type need to check(gp2, io1, st1, sc1 or standard)"
$ec2Volume = (Get-EC2Volume -ProfileName awssg -Region ap-southeast-1 | where {$_.VolumeType -eq $volType}).size
$ec2VolSum = $NULL
$ec2Volume | foreach {$ec2VolSum += $_}
$ec2VolCur = [String]([Math]::Round($ec2VolSum/1024, 2)) + " TiB"
$ec2VolCur