###################################################################################################
# This script can export at most 10000 records from AWS CloudWatch
# If long period needed, need run this script multiple times with smaller period
###################################################################################################

Param(
    [Parameter(Mandatory = $True, Position = 0)]
    [string] $awsProfile,

    [Parameter(Mandatory = $True, Position = 1)]
    [string] $awsRegion
)

$cwRaw = Get-CWLLogEvent `
    -LogStreamName <LogStreamName> `
    -LogGroupName <LogGroupName> `
    -StartTime 'Monday, December 18, 2017 4:00:00 PM' `
    -EndTime 'Monday, December 18, 2017 8:00:00 PM' `
    -Limit 10000 `
    -ProfileName $awsProfile `
    -Region $awsRegion

$cwOutput = $cwRaw.Events | Format-Table -Wrap | Out-File output.csv