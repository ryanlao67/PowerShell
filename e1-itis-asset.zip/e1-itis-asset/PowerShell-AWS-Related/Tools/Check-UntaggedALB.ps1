$awsRegions = Get-AWSRegion -IncludeChina

Foreach($awsRegion in $awsRegions.region)
{
    if($awsRegion.StartsWith("ap-southeast-1"))
    {
      $awsProfile = "awssg";
      $topicARN = "arn:aws:sns:ap-southeast-1:415204155249:OPSGENIE_AWS"
    }
    elseif($awsRegion.StartsWith("cn-"))
    {
      $awsProfile = "awscn";
      $topicARN = "arn:aws-cn:sns:cn-north-1:014301917773:OPSGENIE_AWS"
    }
    else
    {
        continue
    }

    $albList = Get-ELB2LoadBalancer -ProfileName $awsProfile -Region $awsRegion
    $albARNList = $albList.LoadBalancerArn 
    
    Foreach ($alb in $albList)
    {
        $albARN = $alb.LoadBalancerArn 
        $albTagList = (Get-ELB2Tag -ResourceArn $albARN -ProfileName $awsProfile -Region $awsRegion).Tags
        If(!$albTagList)
        {
            Write-Host $alb.LoadBalancerName
        }
    }
}