$adNode1 = "10.17.0.4"
$adNode2 = "10.17.0.14"
$e1AWSADGroup = "AWS-E1-*"

Function TestADNode
{

    If(((Test-Connection $adNode1 -ErrorAction SilentlyContinue).StatusCode | Measure-Object -Sum).Sum -eq 0)
    {
        $adTargetNode = $adNode1
    }
    Elseif(((Test-Connection $adNode2 -ErrorAction SilentlyContinue).StatusCode | Measure-Object -Sum).Sum -eq 0)
    {
        $adTargetNode = $adNode2
    }
    Else
    {
        Break
    }
    Return $adTargetNode
}

$targetNode = TestADNode

$awsE1Groups = (Get-ADGroup -Filter {Name -Like $e1AWSADGroup} -server $targetNode).Name

$accessListAll = @()
Foreach ($awsE1Group in $awsE1Groups)
{
    $awsUserLists = (Get-ADGroupMember $awsE1Group -server $targetNode).SamAccountName
    Foreach ($awsUserList in $awsUserLists)
    {
        $accessList = New-Object psobject
        $accessList | Add-Member NoteProperty "UserName" $awsUserList
        $accessList | Add-Member NoteProperty "GroupName" $awsE1Group
        If((Get-ADUser $awsUserList -server $targetNode).Enabled -eq 'True')
        {
            $accessList | Add-Member NoteProperty "Status" "Enabled"
        }
        Else
        {
            $accessList | Add-Member NoteProperty "Status" "Disabled"
        }
        $accessListAll += $accessList
    }
}

$accessListAll = $accessListAll | Sort-Object GroupName, UserName, Status

# Inventory Format
$htmlFormat = "<style>"
$htmlFormat = $htmlFormat + "BODY{font-family: Segoe UI; font-size: 14px;}"
$htmlFormat = $htmlFormat + "TABLE{border-width: 1px; border-style: solid; border-color: black; border-collapse: collapse;}"
$htmlFormat = $htmlFormat + "TH{border-width: 2px; padding: 2px; border-style: solid; border-color: black;}"
$htmlFormat = $htmlFormat + "TD{border-width: 1px; padding: 1px; border-style: solid; border-color: orange; white-space:nowrap;}"
$htmlFormat = $htmlFormat + "</style>"

$awsAccessListHTML = $accessListAll | ConvertTo-HTML -Head $htmlFormat -Body "<H2>AWS User Access List</H2>"

$awsAccessListHTML| Set-Content "D:\e1awsinventory\html\AWSAccessList.html"

Write-S3Object -BucketName "e1aws-inventory.ef.com" -File "D:\e1awsinventory\html\AWSAccessList.html" -ProfileName awsgbl -Region ap-southeast-1