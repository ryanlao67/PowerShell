<#
.SYNOPSIS
    For CD automation

.DESCRIPTION
    This script is for fetching all ALB/ELB infomation from AWS platform

.PARAMETER Configfile
    No needed for this

.EXAMPLE
    .\fetch-lbinfo.ps1 awscn cn-north-1"

.NOTES
    Author: Ryan Lao
#>

Param(
    [Parameter(Mandatory = $True, Position = 0)]
    [string] $awsProfile,

    [Parameter(Mandatory = $True, Position = 1)]
    [string] $awsRegion
)

$facing = Read-Host -Prompt "Please input the scheme for fetching(INT or EXT)"

Switch ($facing)
{
    INT {$lbScheme = 'internal'}
    EXT {$lbScheme = 'internet-facing'}
}

If($facing -ne 'INT' -and $facing -ne 'EXT')
{
    Write-Warning 'Scheme error, information cannot be fetched.'
    Break
}

$elbList = (Get-ELBLoadBalancer -ProfileName $awsProfile -Region $awsRegion | `
    Where {$_.scheme -eq $lbScheme} | `
    Sort-Object DNSName).DNSName

$albList = (Get-ELB2LoadBalancer -ProfileName $awsProfile -Region $awsRegion | `
    Where {$_.scheme -eq $lbScheme} | `
    Sort-Object DNSName).DNSName

Write-Host "------------------------------------------------------------"
Write-Host "ELB list as below:"
Write-Host "------------------------------------------------------------"
$elbList
Write-Host "------------------------------------------------------------"
Write-Host "ALB list as below:"
Write-Host "------------------------------------------------------------"
$albList
Write-Host "------------------------------------------------------------"