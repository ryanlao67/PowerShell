<#
.SYNOPSIS
    For inventory automation

.DESCRIPTION
    This script is for fetching all ALB infomation from AWS platform

.PARAMETER Configfile
    No needed for this

.EXAMPLE
    .\fetch-albinfo.ps1 awscn cn-north-1"

.NOTES
    Author: Ryan Lao
#>

Param(
    [Parameter(Mandatory = $True, Position = 0)]
    [string] $awsProfile,

    [Parameter(Mandatory = $True, Position = 1)]
    [string] $awsRegion
)

$awsProfile = 'awscn'
$awsRegion = 'cn-north-1'

$albInfoAll = Get-ELB2LoadBalancer -ProfileName $awsProfile -Region $awsRegion

$intALBInfo = $albInfoAll | Where {$_.Scheme -eq "internal"}

$extALBInfo = $albInfoAll | Where {$_.Scheme -eq "internet-facing"}

$ec2InstObjectAll = @()
$intALBTGObjectAll = @()
$intALBObjectAll = @()

Foreach ($intALB in $intALBInfo)
{
    $intALBObject = New-Object psobject
    $intALBArn = $intALB.LoadBalancerArn
    $intALBObject | Add-Member NoteProperty "DNS Name" $intALB.DNSName
    $intALBTargetGroup = Get-ELB2TargetGroup -LoadBalancerArn $intALBarn -ProfileName $awsProfile -Region $awsRegion
    Foreach ($intALBTG in $intALBTargetGroup)
    {
        $intALBTGObject = New-Object psobject
        $intALBTGObject | Add-Member NoteProperty "Target Group Name" $intALBTG.TargetGroupName
        $intALBTGObject | Add-Member NoteProperty "Target Group Port" $intALBTG.Port
        $intALBTGObject | Add-Member NoteProperty "Target Group Protocol" $intALBTG.Protocol
        $intALBTGObject | Add-Member NoteProperty "Health Check Path" $intALBTG.HealthCheckPath
        $intALBTGArn = $intALBTG.TargetGroupARN
        $intALBTGInst = Get-ELB2TargetHealth -TargetGroupArn $intALBTGArn -ProfileName $awsProfile -Region $awsRegion
        $intALBTGEC2 = $intALBTGInst.Target.Id
        Foreach ($intALBTGEC2Inst in $intALBTGEC2)
        {
            $ec2Inst = (Get-EC2Instance -InstanceID $intALBTGEC2Inst -ProfileName $awsProfile -Region $awsRegion).Instances
            $ec2Name = ($ec2Inst.Tags | Where {$_.Key -ieq 'Name'}).Value
            If ($ec2Inst.platform -ne 'Windows')
            {
                $ec2platform = 'Linux'
            }
            Else
            {
                $ec2platform = $ec2Inst.platform
            }
            $ec2output = $ec2Name + " | " + $ec2Inst.PrivateIpAddress + " | " + $ec2platform + "`r`n"
            $ec2outputAll += $ec2output
        }
        $intALBTGObjectAll += $intALBTG.TargetGroupName
        #$intALBTGObject | Add-Member NoteProperty "Instance Info" $ec2InstObjectAll
        #$intALBTGObjectAll += $intALBTGObject
    }
    #$intALBObject | Add-Member NoteProperty "Target Group Info" $intALBTGObjectAll
    #$intALBObjectAll += $intALBObject
}
$ec2outputAll
#$albHTML = $intALBObjectAll | ConvertTo-HTML
#$albHTML | Set-Content "C:\Users\ryan.lao\Desktop\test.html"