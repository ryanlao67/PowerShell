<powershell>
Start-Sleep -Seconds 60

$awsAuto = "AWS Automation"
If([System.Diagnostics.EventLog]::SourceExists($awsAuto))
{
    Continue;
}
Else
{
    New-EventLog -LogName Application -Source $awsAuto
}

$ec2PrivateIP = (Get-NetIPAddress | where {$_.AddressFamily -eq 'IPv4' -and $_.PrefixOrigin -ne 'WellKnown'}).IPAddress
If ($ec2PrivateIP -match '10.160.112' -or $ec2PrivateIP -match '10.160.113' -or $ec2PrivateIP -match '10.160.114' -or $ec2PrivateIP -match '10.160.115')
{
    $awsEnv = 'prd'
}
Elseif ($ec2PrivateIP -match '10.160.128' -or $ec2PrivateIP -match '10.160.129' -or $ec2PrivateIP -match '10.160.130' -or $ec2PrivateIP -match '10.160.131')
{
    $awsEnv = 'stg'
}
Elseif ($ec2PrivateIP -match '10.163.8' -or $ec2PrivateIP -match '10.163.9' -or $ec2PrivateIP -match '10.163.12' -or $ec2PrivateIP -match '10.163.13')
{
    $awsEnv = 'prd'
}
Elseif ($ec2PrivateIP -match '10.163.24' -or $ec2PrivateIP -match '10.163.25' -or $ec2PrivateIP -match '10.163.28' -or $ec2PrivateIP -match '10.163.29')
{
    $awsEnv = 'stg'
}
Else
{
    Break;
}
If ($awsEnv -eq 'prd')
{
    $domEnv = 'e1sd'
}
Elseif ($awsEnv -eq 'stg')
{
    $domEnv = 'e1ef'
}
Else
{
    Break;
}
$instanceId = (Invoke-WebRequest -uri "http://169.254.169.254/latest/meta-data/instance-id").Content
$ec2TagName = (Get-EC2Tag | Where-Object {$_.ResourceId -eq $instanceId -and $_.Key -eq 'NAME'}).Value
$ec2TagTeam = (Get-EC2Tag | Where-Object {$_.ResourceId -eq $instanceId -and $_.Key -eq 'TEAM'}).Value
$ec2TagDB = (Get-EC2Tag | Where-Object {$_.ResourceId -eq $instanceId -and $_.Key -eq 'DB'}).Value

Switch ($ec2TagTeam)
{
    ITIS {New-Item "C:\ServerOwner.txt" -ItemType File -ErrorAction SilentlyContinue | Out-Null; Set-Content "C:\ServerOwner.txt" "ITIS"}
    BI {New-Item "C:\ServerOwner.txt" -ItemType File -ErrorAction SilentlyContinue | Out-Null; Set-Content "C:\ServerOwner.txt" "BI"}
    BSD {New-Item "C:\ServerOwner.txt" -ItemType File -ErrorAction SilentlyContinue | Out-Null; Set-Content "C:\ServerOwner.txt" "BSD"}
    GDM {New-Item "C:\ServerOwner.txt" -ItemType File -ErrorAction SilentlyContinue | Out-Null; Set-Content "C:\ServerOwner.txt" "GDM"}
    PD {New-Item "C:\ServerOwner.txt" -ItemType File -ErrorAction SilentlyContinue | Out-Null; Set-Content "C:\ServerOwner.txt" "PD"}
    SF {New-Item "C:\ServerOwner.txt" -ItemType File -ErrorAction SilentlyContinue | Out-Null; Set-Content "C:\ServerOwner.txt" "SF"}
}

If($ec2TagDB)
{
    New-Item "C:\DBServer.txt" -ItemType File -ErrorAction SilentlyContinue | Out-Null; Set-Content "C:\DBServer.txt" "Yes"
}

$sysInfo = Get-WmiObject -Class Win32_ComputerSystem
If($sysInfo.partofdomain -eq $FALSE)
{
    $domName = $domEnv + '.com'
    $domAdmPasswd = "AddEF123!" | ConvertTo-SecureString -asPlainText -Force
    $domAdm = "$domEnv\joindomain"
    $domCred = New-Object System.Management.Automation.PSCredential($domAdm,$domAdmPasswd)
    Add-Computer -NewName $ec2TagName -Credential $domCred -DomainName $domName -ErrorAction Stop -Force -Restart
}
Else
{
    Break;
}
</powershell>
<persist>true</persist>