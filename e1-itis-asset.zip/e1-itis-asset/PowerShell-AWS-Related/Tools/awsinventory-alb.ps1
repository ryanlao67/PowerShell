$awsRegions = Get-AWSRegion -IncludeChina

$albList = @()
$albTGList = @()
$ec2Name = @()
$infoLineAll = @()

Foreach($awsRegion in $awsRegions.region)
{
    $awsProfile = "awsgbl"
    If($awsRegion.StartsWith("cn-"))
    {
        $awsProfile = "awscn"
    }
    $albLists = Get-ELB2LoadBalancer -ProfileName $awsProfile -Region $awsRegion
    Foreach($albList in $albLists)
    {
        $albArn = $albList.LoadBalancerArn
        $albState = $albList.state.code
        $albDNS = $albList.DNSName
        $albScheme = $albList.Scheme
        $albTag = ((Get-ELB2Tag -ResourceArn $albARN -ProfileName $awsProfile -Region $awsRegion).Tags | Where {$_.Key -ieq "TEAM"}).Value
        $albTGLists = Get-ELB2TargetGroup -LoadBalancerArn $albArn -ProfileName $awsProfile -Region $awsRegion
        Foreach($albTGList in $albTGLists)
        {
            $albTGArn = $albTGList.TargetGroupArn
            $albTGName = $albTGList.TargetGroupName
            $albTGPort = $albTGList.Port
            $albTarLists = Get-ELB2TargetHealth -TargetGroupArn $albTGArn -ProfileName $awsProfile -Region $awsRegion
            Foreach($albTarList in $albTarLists)
            {
                $ec2Tar = $albTarList.Target.Id
                $ec2TarHealth = $albTarList.TargetHealth.State
                $infoLine = New-Object psobject
                If($ec2Tar.StartsWith("i-"))
                {
                    $ec2Instance = Get-EC2Instance -InstanceId $ec2Tar -ProfileName $awsProfile -Region $awsRegion
                }
                Else
                {
                    $ec2Instance = Get-EC2Instance -Filter @{Name="private-ip-address";Value=$ec2Tar} -ProfileName $awsProfile -Region $awsRegion
                }
                $ec2Name = ($ec2Instance.Instances.Tags | Where {$_.Key -ieq 'Name'}).Value
                $ec2PrivateIP = $ec2Instance.Instances.PrivateIpAddress

                $infoLine | Add-Member NoteProperty "Status" $albState
                $infoLine | Add-Member NoteProperty "Region" $awsRegion
                $infoLine | Add-Member NoteProperty "Team" $albTag
                $infoLine | Add-Member NoteProperty "DNS" $albDNS
                $infoLine | Add-Member NoteProperty "Scheme" $albScheme
                $infoLine | Add-Member NoteProperty "TargetGroup" $albTGName
                $infoLine | Add-Member NoteProperty "Port" $albTGPort
                $infoLine | Add-Member NoteProperty "EC2Name" $ec2Name
                $infoLine | Add-Member NoteProperty "PrivateIP" $ec2PrivateIP
                $infoLine | Add-Member NoteProperty "Healthy" $ec2TarHealth
                $infoLineAll += $infoLine
            }
        }
    }
}

$infoLineAll = $infoLineAll | Sort-Object Team, Region, Scheme, DNS, TargetGroup

# Inventory Format
$htmlFormat = "<style>"
$htmlFormat = $htmlFormat + "BODY{font-family: Segoe UI; font-size: 14px;}"
$htmlFormat = $htmlFormat + "TABLE{border-width: 1px; border-style: solid; border-color: black; border-collapse: collapse;}"
$htmlFormat = $htmlFormat + "TH{border-width: 2px; padding: 2px; border-style: solid; border-color: black;}"
$htmlFormat = $htmlFormat + "TD{border-width: 1px; padding: 1px; border-style: solid; border-color: orange; white-space:nowrap;}"
$htmlFormat = $htmlFormat + "</style>"

#$ec2InfoAll | ConvertTo-HTML -Head $htmlFormat -Body "<H2>EC2 Inventory</H2>" | Out-file "D:\AWS_Info\ec2.html"
$albHTML = $infoLineAll | ConvertTo-HTML -Head $htmlFormat -Body "<H2>Application ELB Inventory</H2>"

$albHTML | Set-Content "D:\e1awsinventory\html\albinventory.html"

Write-S3Object -BucketName "e1aws-inventory.ef.com" -File "D:\e1awsinventory\html\albinventory.html" -ProfileName awsgbl -Region ap-southeast-1

