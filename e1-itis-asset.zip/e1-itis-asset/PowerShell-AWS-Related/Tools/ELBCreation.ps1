﻿# Create HTTP Listener
$HTTPListener = New-Object Amazon.ElasticLoadBalancing.Model.Listener
$HTTPListener.Protocol = ‘http’
$httpListener.InstanceProtocol = "http"
$HTTPListener.InstancePort = 10005
$HTTPListener.LoadBalancerPort = 80

# Create HTTPS Listener
$HTTPSListener = New-Object Amazon.ElasticLoadBalancing.Model.Listener
$HTTPSListener.Protocol = ‘https’
$httpsListener.InstanceProtocol = "http"
$HTTPSListener.InstancePort = 10005
$HTTPSListener.LoadBalancerPort = 80
$HTTPSListener.SSLCertificateId = "arn:aws:iam::014301917773:server-certificate/EF_CN_2016"

# Configuration delatils
$LoadBalancerName = 'CNE1STGPS-W-ELB'
$SecurityGroupID = @('sg-ad7f97c9')
$InstanceId = @('i-f588a6cd')
$Scheme = 'internet-facing'
$HealthCheck_Target = 'HTTP:10005/'
$Subnets = @(‘subnet-b6344dd3’, ‘subnet-1b3efa6c’)
$IdleTimeout = '60'
$S3BucketName = 'e1-elb-logs'
$S3BucketPrefix = 'elbs/CNE1STGPS-W-ELB'

# Create Load Balancer
New-ELBLoadBalancer -ProfileName awschina -Region cn-north-1 -LoadBalancerName $LoadBalancerName -Listeners $HTTPListener -SecurityGroups $SecurityGroupID -Subnets $Subnets -Scheme $Scheme

# Associate Instances with Load Balancer
Register-ELBInstanceWithLoadBalancer -ProfileName awschina -Region cn-north-1 -LoadBalancerName $LoadBalancerName -Instances $InstanceId

# Configure healthcheck
Set-ELBHealthCheck -ProfileName awschina -Region cn-north-1 -LoadBalancerName $LoadBalancerName -HealthCheck_HealthyThreshold '10' -HealthCheck_UnhealthyThreshold '2' -HealthCheck_Target $HealthCheck_Target -HealthCheck_Interval '30' -HealthCheck_Timeout '5'

# Edit Load Balancer Attributes
Edit-ELBLoadBalancerAttribute -ProfileName awschina -Region cn-north-1 -LoadBalancerName $LoadBalancerName -ConnectionSettings_IdleTimeout $IdleTimeout -AccessLog_Enabled $true -AccessLog_S3BucketName $S3BucketName -AccessLog_S3BucketPrefix $S3BucketPrefix 

# Add Load Balancer Tags
Add-ELBTags -ProfileName awschina -Region cn-north-1 -LoadBalancerName $LoadBalancerName -Tag @{ Key="TEAM";Value="PD" },@{ Key="Name";Value="$LoadBalancerName"}