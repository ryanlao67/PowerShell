$awsRegions = Get-AWSRegion -IncludeChina
$teamNULL_PROD = ""
$teamBI_PROD = ""
$teamBSD_PROD = ""
$teamGDM_PROD = ""
$teamITIS_PROD = ""
$teamPD_PROD = ""
$teamSF_PROD = ""

Foreach($awsRegion in $awsRegions.region)
{
    if($awsRegion.StartsWith("ap-southeast-1"))
    {
      $awsProfile = "awssg";
      $topicARN = "arn:aws:sns:ap-southeast-1:415204155249:OPSGENIE_AWS"
    }
    elseif($awsRegion.StartsWith("cn-"))
    {
      $awsProfile = "awscn";
      $topicARN = "arn:aws-cn:sns:cn-north-1:014301917773:OPSGENIE_AWS"
    }
    else
    {
        continue
    }

    $albs = Get-ELB2LoadBalancer -ProfileName $awsProfile -Region $awsRegion
    $albAlarms = Get-CWAlarm -ProfileName $awsProfile -Region $awsRegion | Where {$_.Namespace -eq "AWS/ELB"}

    $dimension1 = New-Object Amazon.CloudWatch.Model.Dimension
    $dimension1.set_Name("LoadBalancerName")

    $htmlLine = ""

    Foreach($alb in $albs)
    {
        $healthTargetHostCount = 0
        $albTargetGroups = Get-ELB2TargetGroup -LoadBalancerArn $alb.LoadBalancerArn -ProfileName $awsProfile -Region $awsRegion
        Foreach($albTargetGroup in $albTargetGroups)
        {
            $albTargetInstanceHealth = (Get-ELB2TargetHealth -TargetGroupArn $albTargetGroup.TargetGroupArn -ProfileName $awsProfile -Region $awsRegion).TargetHealth

            Foreach ($targetHealth in $albTargetInstanceHealth.State)
            {
                If($targetHealth -eq "healthy")
                {
                    $healthTargetHostCount += 1
                }
            }
            If($healthTargetHostCount -ne $albTargetInstanceHealth.Count)
            {
                $htmlLine = $($htmlLine + "<tr><td colspan=2><img src=stopped.png height=16 width=16>" + $healthTargetHostCount.ToString() + " out of " + $albTargetInstanceHealth.Count.ToString() + "healthy</td>")
            }
            Else
            {
                $htmlLine = $($htmlLine + "<tr><td colspan=2><img src=running.png height=16 width=16>" + $healthTargetHostCount.ToString() + " out of " + $albTargetInstanceHealth.Count.ToString() + " healthy</td>")
            }
            $htmlLine = $($htmlLine + "<td>" + $albTargetGroup.TargetGroupName + "</td>")
            $htmlLine = $($htmlLine + "<td>" + $alb.DNSName + "</td>")
            $htmlLine = $($htmlLine + "<td>" + $alb.Scheme + "</td>")
        }
        $albName = $alb.LoadBalancerName

        $albAlarmWarningHighLatency = ($albAlarms | Where {$_.AlarmName -match $("\[Warning\]\["+$team+"\] High-ELB-Latency \(" + $albName +"\)")})
        $albAlarmCriticalZeroHealthyHosts = ($albAlarms | Where {$_.AlarmName -match $("\[High\]\["+$team+"\] ELB-Zero-Healthy-Hosts \(" + $albName +"\)")})
        $albAlarmWarningUnHealthyHosts = ($albAlarms | Where {$_.AlarmName -match $("\[Warning\]\["+$team+"\] ELB-UnHealthy-Hosts \(" + $albName +"\)")})
        $albAlarmCriticalHighQueueLength = ($albAlarms | Where {$_.AlarmName -match $("\[High\]\["+$team+"\] ELB-High-Queue-Length \(" + $albName +"\)")})
        $albAlarmWarningHighQueueLength = ($albAlarms | Where {$_.AlarmName -like $("\[Warning\]\["+$team+"\] ELB-High-Queue-Length \(" + $albName +"\)")})
        $albAlarmCriticalMaxQueueLengthReached = ($albAlarms | Where {$_.AlarmName -match $("\[High\]\["+$team+"\] ELB-Max-Queue-Length-Reached \(" + $albName +"\)")})
        $albAlarmWarningRequestsFailing = ($albAlarms | Where {$_.AlarmName -match $("\[Warning\]\["+$team+"\] ELB-Requests-Failing \(" + $albName +"\)")})
        $albAlarmCriticalRequestsFailing = ($albAlarms | Where {$_.AlarmName -match $("\[High\]\["+$team+"\] ELB-Requests-Failing \(" + $albName +"\)")})
        $dimension1.set_Value($elbName)

        $env = ""
        $team = ""
        $subteam = ""

        $tagKeys = @("ENV", "SUBTEAM", "TEAM");
        $tags = ((Get-ELB2Tag -ResourceArn $alb.LoadBalancerArn -ProfileName $awsProfile -Region $awsRegion).Tags | Where {$_.Key -in $tagKeys})

        If($tags.Count -ge 2)
        {
            $tags = $tags | Sort-Object @{Expression={$_.Key}; Ascending=$true}
            $env = $tags[0].Value
            If($tags.Count -eq 3)
            {
                $subteam = $tags[1].Value
                $team = $tags[2].Value
            }
            Else
            {
                $team = $tags[1].Value
            }
        }

        If($team -ne "BI" -and $team -ne "BSD" -and $team -ne "GDM" -and $team -ne "PD" -and $team -ne "SF")
        {
            $team = "ITIS"
        }
        If($subteam)
        {
            $CWtopicARN = New-SNSTopic -Name $("E1" + $subteam) -ProfileName $awsProfile -Region $awsRegion
            $alarmPrefixTeam = $subteam.Replace("_","-")
            If($subteam -eq "BSD_LEARNING" -or $subteam -eq "BSD_ODIN")
            {
                $alarmPrefixTeam = "BSD-OMNI"
            }
            Elseif($subteam -eq "BSD_FOUNDATION" -or $subteam -eq "BSD_EFP")
            {
                $alarmPrefixTeam ="BSD-SHS"
            }
        }
        Else
        {
            $CWtopicARN = New-SNSTopic -Name $("E1" + $team + "_APP_AWS_Warning") -ProfileName $awsProfile -Region $awsRegion
            $alarmPrefixTeam = $team
        }

        If($albAlarmWarningHighLatency.Count -eq 0)
        {
            If($alb.CreatedTime -lt (Get-Date).AddDays(-15) -and $env -eq "PRD")
            {
                $latencyLimit = 3.0
                If($team -eq "PD")
                {
                    $latencyLimit = 6.0
                }
                Elseif($albName -eq "SGE1PRDBIRS01-ELB")
                {
                    $latencyLimit = 15.0
                }
                #Write-CWMetricAlarm -AlarmName $("[Warning]["+$team+"] High-ELB-Latency (" + $albName + ")") -AlarmDescription "Created by PowerShell script" -Namespace "AWS/ELB" -MetricName Latency -Dimension $dimension1 -AlarmActions $CWtopicARN -ComparisonOperator GreaterThanOrEqualToThreshold -EvaluationPeriods 6 -Period 300 -Statistic Average -Threshold $latencyLimit -ProfileName $awsProfile -Region $awsRegion

                echo albName
                $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>");
            }
            Else
            {
                $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=close_red.png height=20 width=20/></td>");
            }
        }
        Else
        {
            $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>");
        }

        If($albAlarmCriticalZeroHealthyHosts.Count -eq 0)
        {
            If($alb.CreatedTime -lt (Get-Date).AddDays(-15) -and $env -eq "PRD")
            {
                #Write-CWMetricAlarm -AlarmName $("[High]["+$alarmPrefixTeam+"] ELB-Zero-Healthy-Hosts (" + $albName + ")") -AlarmDescription "Created by PowerShell script" -Namespace "AWS/ELB" -MetricName HealthyHostCount -Dimension $dimension1 -AlarmActions $topicARN -ComparisonOperator LessThanOrEqualToThreshold -EvaluationPeriods 3 -Period 60 -Statistic Average -Threshold 0 -ProfileName $awsProfile -Region $awsRegion

                echo $albName
                $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>");
            }
            Else
            {
                $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=close_red.png height=20 width=20/></td>");
            }
        }
        Else
        {
            $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>");
        }

        If($albAlarmWarningUnHealthyHosts.Count -eq 0)
        {
            If($alb.CreatedTime -lt (Get-Date).AddDays(-15) -and $env -eq "PRD")
            {
                #Write-CWMetricAlarm -AlarmName $("[Warning]["+$team+"] ELB-UnHealthy-Hosts (" + $albName + ")") -AlarmDescription "Created by PowerShell script" -Namespace "AWS/ELB" -MetricName UnHealthyHostCount -Dimension $dimension1 -AlarmActions $CWtopicARN -ComparisonOperator GreaterThanOrEqualToThreshold -EvaluationPeriods 3 -Period 300 -Statistic Average -Threshold 1 -ProfileName $awsProfile -Region $awsRegion

                echo $albName
                $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>");
            }
            Else
            {
                $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=close_red.png height=20 width=20/></td>");
            }
        }
        Else
        {
            $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>");
        }

        If($albAlarmCriticalHighQueueLength.Count -eq 0)
        {
            If($alb.CreatedTime -lt (Get-Date).AddDays(-15) -and $env -eq "PRD")
            {
                #Write-CWMetricAlarm -AlarmName $("[High]["+$alarmPrefixTeam+"] ELB-High-Queue-Length (" + $albName + ")") -AlarmDescription "Created by PowerShell script" -Namespace "AWS/ELB" -MetricName SurgeQueueLength -Dimension $dimension1 -AlarmActions $topicARN -ComparisonOperator GreaterThanOrEqualToThreshold -EvaluationPeriods 3 -Period 300 -Statistic Average -Threshold 20 -ProfileName $awsProfile -Region $awsRegion

                echo $albName
                $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>");
            }
            Else
            {
                $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=close_red.png height=20 width=20/></td>");
            }
        }
        Else
        {
            $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>");
        }

        If($albAlarmWarningHighQueueLength.Count -eq 0)
        {
            If($alb.CreatedTime -lt (Get-Date).AddDays(-15) -and $env -eq "PRD")
            {
                #Write-CWMetricAlarm -AlarmName $("[Warning]["+$team+"] ELB-High-Queue-Length (" + $albName + ")") -AlarmDescription "Created by PowerShell script" -Namespace "AWS/ELB" -MetricName SurgeQueueLength -Dimension $dimension1 -AlarmActions $CWtopicARN -ComparisonOperator GreaterThanOrEqualToThreshold -EvaluationPeriods 2 -Period 300 -Statistic Average -Threshold 10 -ProfileName $awsProfile -Region $awsRegion

                echo $albName
                $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>");
            }
            Else
            {
                $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=close_red.png height=20 width=20/></td>");
            }
        }
        Else
        {
            $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>");
        }

        If($elbAlarmCriticalMaxQueueLengthReached.Count -eq 0)
        {
            If($alb.CreatedTime -lt (Get-Date).AddDays(-15) -and $env -eq "PRD")
            {
                #Write-CWMetricAlarm -AlarmName $("[High]["+$alarmPrefixTeam+"] ELB-Max-Queue-Length-Reached (" + $albName + ")") -AlarmDescription "Created by PowerShell script" -Namespace "AWS/ELB" -MetricName SpilloverCount -Dimension $dimension1 -AlarmActions $topicARN -ComparisonOperator GreaterThanOrEqualToThreshold -EvaluationPeriods 3 -Period 60 -Statistic Sum -Threshold 1 -ProfileName $awsProfile -Region $awsRegion

                echo $albName
                $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>");
            }
            Else
            {
                $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=close_red.png height=20 width=20/></td>");
            }
        }
        Else
        {
            $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>");
        }

        If($albAlarmWarningRequestsFailing.Count -eq 0)
        {
            If($alb.CreatedTime -lt (Get-Date).AddDays(-15) -and $env -eq "PRD")
            {
                $faileRequestLimit = 7
                #If($elb.LoadBalancerName -eq "SGE1PRDBIRS01-ELB" -or $elb.LoadBalancerName -eq "SGE1PRDODIN-BGS-ELB-INT")
                #{
                #    $faileRequestLimit = 25.0
                #}
                #Write-CWMetricAlarm -AlarmName $("[Warning]["+$team+"] ELB-Requests-Failing (" + $albName + ")") -AlarmDescription "Created by PowerShell script" -Namespace "AWS/ELB" -MetricName HTTPCode_ELB_5XX -Dimension $dimension1 -AlarmActions $CWtopicARN -ComparisonOperator GreaterThanOrEqualToThreshold -EvaluationPeriods 3 -Period 60 -Statistic Sum -Threshold $faileRequestLimit -ProfileName $awsProfile -Region $awsRegion

                echo $albName
                $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>");
            }
            Else
            {
                $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=close_red.png height=20 width=20/></td>");
            }
        }
        Else
        {
            $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>");
        }

        If($albAlarmCriticalRequestsFailing.Count -eq 0)
        {
            If($alb.CreatedTime -lt (Get-Date).AddDays(-15) -and $env -eq "PRD")
            {
                $faileRequestLimit = 50
                #Write-CWMetricAlarm -AlarmName $("[High]["+$alarmPrefixTeam+"] ELB-Requests-Failing (" + $albName + ")") -AlarmDescription "Created by PowerShell script" -Namespace "AWS/ELB" -MetricName HTTPCode_ELB_5XX -Dimension $dimension1 -AlarmActions $topicARN -ComparisonOperator GreaterThanOrEqualToThreshold -EvaluationPeriods 3 -Period 60 -Statistic Sum -Threshold $faileRequestLimit -ProfileName $awsProfile -Region $awsRegion

                echo $albName
                $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>");
            }
            Else
            {
                $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=close_red.png height=20 width=20/></td>");
            }
        }
        Else
        {
            $htmlLine = $($htmlLine + "<td align=center valign=middle><img src=tick_green.png height=20 width=20/></td>");
        }

        $tagKeys = @("ENV", "TEAM");
        $tags = ((Get-ELB2Tag -ResourceArn $alb.LoadBalancerArn -ProfileName $awsProfile -Region $awsRegion).Tags | Where {$_.Key -in $tagKeys})

        If($tags.Count -eq 2)
        {
            $tags = $tags | Sort-Object @{Expression={$_.Key}; Ascending=$true}
            If($tags[0].Value -eq "PRD")
            {
                If($tags[1].Value -eq "BI")
                {
                    $teamBI_PROD = $($teamBI_PROD + $htmlLine);
                }
                Elseif($tags[1].Value -eq "BSD")
                {
                    $teamBSD_PROD = $($teamBSD_PROD + $htmlLine);
                }
                Elseif($tags[1].Value -eq "GDM")
                {
                    $teamGDM_PROD = $($teamGDM_PROD + $htmlLine);
                }
                Elseif($tags[1].Value -eq "ITIS")
                {
                    $teamITIS_PROD = $($teamITIS_PROD + $htmlLine);
                }
                Elseif($tags[1].Value -eq "PD")
                {
                    $teamPD_PROD = $($teamPD_PROD + $htmlLine);
                }
                Elseif($tags[1].Value -eq "SF")
                {
                    $teamSF_PROD = $($teamSF_PROD + $htmlLine);
                }
                Else
                {
                    $teamNULL_PROD = $($teamNULL_PROD + $htmlLine);
                }
            }
        }
    }
}

$html = $("<html><body>Last Updated (UTC) - " + (Get-Date).ToUniversalTime() + "<table border=1 width=100%>")
$metricsColums = "<td><b>Warning-High-Latency</b></td> <td><b>Critical-Zero-Healthy-Hosts</b></td> <td><b>Warning-UnHealthy-Hosts</b></td> <td><b>Critical-High-Queue-Length</b></td> <td><b>Warning-High-Queue-Length</b></td> <td><b>Critical-Max-Queue-Length-Reached</b></td> <td><b>Warning-Requests-Failing</b></td> <td><b>Critical-Requests-Failing</b></td>"

If($teamNULL_PROD.Length -gt 0)
{
    $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM NULL</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>")
    $html =  $($html + $teamNULL_PROD + "<tr></tr>")
}
If($teamBI_PROD.Length -gt 0)
{
    $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM BI</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>")
    $html =  $($html + $teamBI_PROD + "<tr></tr>")
}
If($teamBSD_PROD.Length -gt 0)
{
    $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM BSD</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>")
    $html =  $($html + $teamBSD_PROD + "<tr></tr>")
}
If($teamGDM_PROD.Length -gt 0)
{
    $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM GDM</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>")
    $html =  $($html + $teamGDM_PROD + "<tr></tr>")
}
If($teamITIS_PROD.Length -gt 0)
{
    $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM ITIS</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>")
    $html =  $($html + $teamITIS_PROD + "<tr></tr>")
}
If($teamPD_PROD.Length -gt 0)
{
    $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM PD</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>")
    $html =  $($html + $teamPD_PROD + "<tr></tr>")
}
If($teamSF_PROD.Length -gt 0)
{
    $html =  $($html + "<tr bgcolor=silver><td colspan=12>" + "<b>TEAM SalesForce</b>" + "</td></tr><tr bgcolor=silver><td colspan=4></td>"+ $metricsColums + "</tr>")
    $html =  $($html + $teamSF_PROD + "<tr></tr>")
}

$html = $($html + "</table></body></html>")

$html | Set-Content 'cw-elb.html'
