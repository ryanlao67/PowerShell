# Get EC2 Infomation
$instanceId = (Invoke-WebRequest -uri "http://169.254.169.254/latest/meta-data/instance-id").Content
$ec2TagName =  (Get-EC2Tag | Where-Object {$_.ResourceId -eq $instanceId -and $_.Key -eq 'NAME'}).Value
$ec2TagEnv = (Get-EC2Tag | Where-Object {$_.ResourceId -eq $instanceId -and $_.Key -eq 'ENV'}).Value
$ec2TagProj = (Get-EC2Tag | Where-Object {$_.ResourceId -eq $instanceId -and $_.Key -eq 'PROJECT'}).Value

# S3 Operation
$iamRole = (Invoke-WebRequest -URI "http://169.254.169.254/latest/meta-data/iam/security-credentials").Content
$iamInfo = (Invoke-WebRequest -URI "http://169.254.169.254/latest/meta-data/iam/security-credentials/$iamRole").Content | ConvertFrom-Json

# Pull latest application package
If (Test-Path "C:\Temp")
{
    Remove-Item C:\Temp\ -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
}
Sleep 2
New-Item C:\Temp -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
Read-S3Object -BucketName e1-cicd-release -Prefix $ec2TagEnv/$ec2TagProj/LATEST -AccessKey $IAMInfo.AccessKeyId -SecretKey $IAMInfo.SecretAccessKey -SessionToken $IAMInfo.Token -Region ap-southeast-1 -Folder "C:\Temp"
$appFile = (Get-ChildItem C:\Temp).FullName
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::ExtractToDirectory($appFile, "C:\Temp\$ec2TagProj\")

# Push to target location
$longDate = (Get-Date).ToString("yyyyMMddhhmm")
$rollBackFolder = $ec2TagProj + "_" + $longDate
If (Test-Path "D:\")
{
    If (Test-Path "D:\$ec2TagProj")
    {
        Copy-Item "D:\$ec2TagProj\" "D:\$rollBackFolder\" -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
        Copy-Item "C:\Temp\$ec2TagProj\*" "D:\$ec2TagProj" -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
    }
    
}
ElseIf (Test-Path "C:\$ec2TagProj")
{
    Copy-Item "C:\$ec2TagProj\" "C:\$rollBackFolder\" -Recurse -ErrorAction SilentlyContinue | Out-Null
    Copy-Item "C:\Temp\$ec2TagProj\*" "C:\$ec2TagProj" -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
}
Else
{
    Copy-Item "C:\Temp\$ec2TagProj\" "C:\$ec2TagProj" -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
}
Sleep 5

# Reset new application and basic smoke
IISReset



Remove-Item C:\Temp\ -Force -Recurse -ErrorAction SilentlyContinue | Out-Null