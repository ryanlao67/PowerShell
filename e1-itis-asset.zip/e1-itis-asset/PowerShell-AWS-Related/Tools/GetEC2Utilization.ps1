Param (
    [Parameter(Mandatory = $True, Position = 0)]
    [string] $awsProfile,
    
    [Parameter(Mandatory = $True, Position = 1)]
    [string] $awsRegion
)

Import-Module AWSPowerShell

$ec2Subnets = Get-EC2Subnet -ProfileName $awsProfile -Region $awsRegion
$ec2instances = (Get-EC2Instance -ProfileName $awsProfile -Region $awsRegion).instances
$result =@()
foreach ($ec2instance in $ec2instances)
{
    $ec2Name = ($ec2instance.tags | Where-Object -Property key -eq 'Name').Value
    $ec2ENV = ($ec2instance.tags | Where-Object -Property key -eq 'ENV').Value
    $ec2TEAM = ($ec2instance.tags | Where-Object -Property key -eq 'TEAM').Value
    $ec2ReservedID = ($ec2instance.tags | Where-Object -Property key -eq 'Reserved ID').Value
    $ec2InstanceId = $ec2instance.instanceid
    $ec2InstanceType = $ec2instance.InstanceType
    $ec2PrivateIP = $ec2instance.PrivateIpAddress
    $ec2PublicIP = $ec2instance.PublicIpAddress
    $ec2Platform = $ec2instance.Platform
    $cpuUtilAVG = (Get-CWMetricStatistics -Dimension @{Name = "InstanceId"; Value = $ec2InstanceId} `
        -MetricName CPUUtilization `
        -ProfileName $awsProfile `
        -Region $awsRegion `
        -StartTime (Get-Date).AddDays(-3) `
        -EndTime (Get-Date) -Namespace "AWS/EC2" `
        -Period 259200 -Statistic Average)
    $cpuUtilMAX = (Get-CWMetricStatistics -Dimension @{Name = "InstanceId"; Value = $ec2InstanceId} `
        -MetricName CPUUtilization `
        -ProfileName $awsProfile `
        -Region $awsRegion `
        -StartTime (Get-Date).AddDays(-3) `
        -EndTime (Get-Date) `
        -Namespace "AWS/EC2" `
        -Period 259200 `
        -Statistic Maximum)
    $cpuCreditBalanceAVG = (Get-CWMetricStatistics -Dimension @{Name = "InstanceId"; Value = $ec2InstanceId} `
        -MetricName CPUCreditBalance `
        -ProfileName $awsProfile `
        -Region $awsRegion `
        -StartTime (Get-Date).AddDays(-3) `
        -EndTime (Get-Date) `
        -Namespace "AWS/EC2" `
        -Period 259200 `
        -Statistic Average)
    $cpuCreditUsageAVG = (Get-CWMetricStatistics -Dimension @{Name = "InstanceId"; Value = $ec2InstanceId} `
        -MetricName CPUCreditUsage `
        -ProfileName $awsProfile `
        -Region $awsRegion `
        -StartTime (Get-Date).AddDays(-3) `
        -EndTime (Get-Date) `
        -Namespace "AWS/EC2" `
        -Period 259200 `
        -Statistic Average)
    $avgCPUUtilization = $cpuUtilAVG.Datapoints.Average
    $maxCPUUtilization = $cpuUtilMAX.Datapoints.Maximum
    $avgCPUCreditBalance = $cpuCreditBalanceAvg.Datapoints.Average
    $avgCPUCreditUsage = $cpuCreditUsageAvg.Datapoints.Average

    $outPut = New-Object -TypeName System.Management.Automation.PSObject -Property ([ordered]@{
        'Instance Name' = $ec2Name
        'InstanceID' = $ec2InstanceId
        'ReservedID' = $ec2ReservedID
        'InstanceType' = $ec2InstanceType
        'PrivateIpAddress' = $ec2PrivateIP
        'PublicIP' = $ec2PublicIP
        'Platform' = $ec2Platform
        'TEAM' = $ec2TEAM
        'ENV' = $ec2ENV
        'AvgCPUUtilization' = $avgCPUUtilization
        'MaxCPUUtilization' = $maxCPUUtilization
        'AvgCPUCreditBalance' = $avgCPUCreditBalance
        'AvgCPUCreditUsage' = $avgCPUCreditUsage           
    })
    $result += $outPut
}
$result | Out-GridView