Param (
    [Parameter(Mandatory = $True, Position = 0)]
    [string] $awsProfile,
    
    [Parameter(Mandatory = $True, Position = 1)]
    [string] $awsRegion
)

$ec2infoall = (Get-EC2Instance -ProfileName $awsProfile -Region $awsRegion).Instances | Where {$_.State.Name -eq "Running"}

$ec2running = @{}
Foreach ($ec2info in $ec2infoall)
{
    $placement = $ec2info.Placement.AvailabilityZone
    $ec2Type = $ec2info.InstanceType
    $ec2runkey = "($ec2Type, $placement)"
    $ec2running["$ec2runkey"]++
}

$ec2running = $ec2running.GetEnumerator() | sort -Property Name

$ec2running