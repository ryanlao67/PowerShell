# Import AWS pricing Information
$priceInfo = Get-Content -Raw -Path .\AWSPricing.json | Out-String | ConvertFrom-Json

# Collect Information
$regionInfo = Read-Host -Prompt "Please confirm AWS region(CN/SG)"

Switch ($regionInfo)
{
    CN {$awsRegion = 'AWSCN'}
    SG {$awsRegion = 'AWSSG'}
}