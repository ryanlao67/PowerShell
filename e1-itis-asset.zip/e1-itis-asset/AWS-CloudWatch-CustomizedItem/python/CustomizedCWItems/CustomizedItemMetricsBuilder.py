# -*- encoding:utf-8 -*-
# CustomizedCWItems.py
# Using for data generating for customized items.
#
# ver-0.0.1, 2017/03/29, Author: bob.yeh@ef.com
# First init.
# Todo: need to load the configurations for each different region/machine.
#
# ver-0.0.2, 2017/04/05, Author: bob.yeh@ef.com
# Change the nameing rule to support different region running case
# gM for both
# gMsg for AWS-Global-SG: ap-southeast-1
# gMcn for AWSCN-Beijing: cn-north-1

from CustomizedNetworkUtils import CustomizedNetworkUtils as CNU

_sf_host = 'ap1.salesforce.com'
_sf_http = 'http://ap1.salesforce.com'
_sf_https =  'https://ap1.salesforce.com'

_zd_host = 'e1helpcenter.zendesk.com'
_zd_http = 'http://e1helpcenter.zendesk.com'
_zd_https = 'https://e1helpcenter.zendesk.com'
_sg_proxy = '10.160.114.182'

_sh_jenkins = 'http://10.17.7.201:8080'

_odinplus = 'odinplus-services.ef.com'
_dns_usb = '10.43.46.62'
_dns_shdc = '10.17.0.14'
_dns_sgdc02 = '10.160.113.132'
_dns_sgdc01 = '10.160.112.144'
_dns_sgrodc = '10.160.112.111'
_dns_sgdc01_stg = '10.160.128.28'
_dns_sgdc02_stg = '10.160.129.180'
_dns_cndc01 = '10.163.8.184'
_dns_cndc02 = '10.163.12.246'


class CustomizedItemMetricsBuilder(object):

    def __init__(self):
        return

    def gMcn_nslookup_salesforce(self):
        """
        will call the nslookup to check if the dns record can be resolved or not
        if not, means the record been blocked by GFW? mostly will happend in AWSCN-BJS
        """
        metrics = {'SalesforceDNSAvailable':CNU.get_dns_availability(_sf_host)}
        return metrics

    def gM_head_sf_latency(self):
        """
        will use http/https channel to get the target url, and then measure the response latency
        """
        metrics = {'SalesforceHttpHeadLatency':CNU.head_url_latency(_sf_http),
                   'SalesforceHttpsHeadLatency':CNU.head_url_latency(_sf_https)}
        return metrics

    def gMcn_head_sf_proxy_latency(self):
        """
        will use http/https channel to get the target url, and then measure the response latency
        """
        metrics = {'SalesforceHttpHeadProxyLatency':CNU.head_url_latency(_sf_http,_sg_proxy),
                   'SalesforceHttpsHeadProxyLatency':CNU.head_url_latency(_sf_https,_sg_proxy)}
        return metrics

    def gM_get_sf_latency(self):
        """
        will use http/https channel to get the target url, and then measure the response latency
        """
        metrics = {'SalesforceHttpGetLatency':CNU.get_url_latency(_sf_http),
                   'SalesforceHttpsGetLatency':CNU.get_url_latency(_sf_https)}
        return metrics

    def gM_get_shdc_jks_latency(self):
        """
        will use http/https channel to get the target url, and then measure the response latency
        """
        metrics = {'ShanghaiDCJenkinsLatency':CNU.get_url_latency(_sh_jenkins)}
        return metrics

    def gMcn_nslookup_zendesk(self):
        metrics = {'ZendeskDNSAvailable':CNU.get_dns_availability(_zd_host)}
        return metrics

    def gM_get_zd_latency(self):
        metrics = {'ZendeskHttpGetLatency':CNU.get_url_latency(_zd_http),
                   'ZendeskHttpsGetLatency':CNU.get_url_latency(_zd_https)}
        return metrics

    def gM_head_zd_latency(self):
        metrics = {'ZendeskHttpHeadLatency':CNU.head_url_latency(_zd_http),
                   'ZendeskHttpsHeadLatency':CNU.head_url_latency(_zd_https)}
        return metrics

    def gM_get_odinplus_from_dns(self):
        metrics = { 'OdinPlusDnsResolve.USB':CNU.nslookup_server(_odinplus,_dns_usb),
                    'OdinPlusDnsResolve.SHDC':CNU.nslookup_server(_odinplus,_dns_shdc)}
        return metrics

    def gMsg_get_odinplus_from_dns(self):
        metrics = { 'OdinPlusDnsResolve.SGDC02':CNU.nslookup_server(_odinplus,_dns_sgdc02),
                    'OdinPlusDnsResolve.SGDC01':CNU.nslookup_server(_odinplus,_dns_sgdc01),
                    'OdinPlusDnsResolve.SGRODC':CNU.nslookup_server(_odinplus,_dns_sgrodc),
                    'OdinPlusDnsResolve.SGDC01STG':CNU.nslookup_server(_odinplus,_dns_sgdc01_stg),
                    'OdinPlusDnsResolve.SGDC02STG':CNU.nslookup_server(_odinplus,_dns_sgdc02_stg)}
        return metrics

    def gMcn_get_odinplus_from_dns(self):
        metrics = { 'OdinPlusDnsResolve.CNDC02':CNU.nslookup_server(_odinplus,_dns_cndc02),
                    'OdinPlusDnsResolve.CNDC01':CNU.nslookup_server(_odinplus,_dns_cndc01)}
        return metrics
