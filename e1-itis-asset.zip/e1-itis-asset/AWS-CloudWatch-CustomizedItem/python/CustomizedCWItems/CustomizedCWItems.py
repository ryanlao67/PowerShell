# -*- encoding:utf-8 -*-
# CustomizedCWItems.py
# Using for calling the metrics data generation and post to CW endpoint
#
# ver-0.0.1, 2017/03/29, Author: bob.yeh@ef.com
# First init.

from boto.ec2 import cloudwatch
from boto.utils import get_instance_metadata
from CustomizedItemMetricsBuilder import CustomizedItemMetricsBuilder as MBuilder

_r_sg = 'ap-southeast-1'
_r_cn = 'cn-north-1'

class CloudwatchMetricWriter(object):

    CW_NAMESPACE = "CustomizedCW"

    def __init__(self):
	metadata = get_instance_metadata()
	if _r_cn in metadata['local-hostname']:
            region = _r_cn 
        else:
            region = _r_sg
        self.connection = cloudwatch.connect_to_region(region)
        self.instance_id = metadata['instance-id']
        self.region = region

    def send_metrics(self, metrics, unit):
        print metrics
        if metrics is not None:
            self.connection.put_metric_data(self.CW_NAMESPACE, metrics.keys(),
                                        metrics.values(), unit=unit,
                                        dimensions={"InstanceId": self.instance_id})
        
    def send_all_metrics_values(self):
        bdr = MBuilder()        
        for method in dir(bdr):
            if callable(getattr(bdr,method)):
                if "gM_" in method or\
                   "gMsg_" in method and self.region == _r_sg or \
                   "gMcn_" in method and self.region == _r_cn:
                    proceed = getattr(bdr,method)       
                    metrics = proceed()
                    self.send_metrics(metrics=metrics, unit="None")
        return True

    def run(self):
        self.send_all_metrics_values()
