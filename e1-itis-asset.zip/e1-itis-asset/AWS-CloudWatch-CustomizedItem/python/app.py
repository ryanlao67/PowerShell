from CustomizedCWItems.CustomizedCWItems import CloudwatchMetricWriter as CW


if __name__ == "__main__":
		CW().run()
