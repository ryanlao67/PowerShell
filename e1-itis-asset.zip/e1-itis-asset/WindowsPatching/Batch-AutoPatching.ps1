﻿Param([validateset("CNLIVE","CNNONLIVE","SGLIVE","SGNONLIVE")][string]$Environment,$serverList,$Argument)

#handle serverlist
"Importing server list..."
#handle serverlist

Function SerListCheck ()
{
    param ([array]$ServerList)
    if ($ServerList[0] -like "*.txt")
    {
        if(test-path $ServerList[0])
        {
            [array]$Servers = gc $ServerList[0]
        }
        else
        {
            write-host "Your server list path is not existing: $ServerList" -foregroundcolor yellow
            break;
        }
    }
    else
    {
    [array]$Servers=$ServerList
    }
    if ($Servers[0] -like "")
    {
        write-host "Server list is nulll, please input server(s) or server list." -foregroundcolor yellow
        break;
    }
    else
    {
        return $Servers;
    }
}

#serverlist handling function invoke
[array]$Servers= SerListCheck $ServerList


switch ($Environment)
{
    "CNLIVE" {$DU= "CNE1WSUS02.e1sd.com";$WSUSBitsPath="\\$DU\Scripts\Patching\AutoPatching.ps1"}
    "CNNONLIVE" {$DU= "CNE1WSUS01.e1ef.com";$WSUSBitsPath="\\$DU\Scripts\Patching\AutoPatching.ps1"}
    "SGLIVE" {$DU= "SGE1WSUS01.e1sd.com";$WSUSBitsPath="\\$DU\Scripts\Patching\AutoPatching.ps1"}
    "SGNONLIVE" {$DU= "SGE1WSUS02.e1ef.com";$WSUSBitsPath="\\$DU\Scripts\Patching\AutoPatching.ps1"}
    "Manually assign bits path" {$WSUSBitsPath= Read-Host "Please type the wsus script bits UNC path" }
}
"WSUS script bits UNC path we are using:" | Write-Host -ForegroundColor Yellow
$WSUSBitsPath
$result = @{}
"Triggering wsus jobs against server list..." | Write-Host -ForegroundColor Yellow


[array]$failedServers=$null
$WSUSJob= $servers | % {
    if (!(test-path "\\$_\C$\temp\"))
    {
        $MD_R=md -Path "\\$_\C$\temp\" -ErrorAction SilentlyContinue -ErrorVariable ERR
    }
    if ($ERR -ine $null)
    {
        "Temp Path Creat Failed, please do it manually and rerun: \\$_\C$\temp\" |write-host -ForegroundColor Red
         $failedServers+=$_
     }
    $wsuspath = "\\$_\C$\temp\AutoPatching.ps1"
    $s="$_"
    try {
        copy-item "$WSUSBitsPath" "$wsuspath" -ErrorAction SilentlyContinue;
    }
    catch {}
    if (test-path "$wsuspath")
    {
        if ($Argument)
        {
            $WSUSjob= psexec /accepteula -d -s -h \\$_ powershell -ExecutionPolicy Bypass -File "$wsuspath" $Argument 2>&1 | Out-String
        }
        else
        {
            $WSUSjob= psexec /accepteula -d -s -h \\$_ powershell -ExecutionPolicy Bypass -File "$wsuspath" 2>&1 | Out-String
        }
        if ($WSUSjob -match "started on $_ with process ID")
        {
            $JobString= $WSUSjob |findstr "ID"
            $result =$result | select @{name="ServerName";expression={"$s"}},@{name="Job Status";expression={"$JobString"}}
        }
        else
        {
            $result =$result | select @{name="ServerName";expression={"$s"}},@{name="Job Status";expression={"Job Sent failed."}}
        }
        return $result
    }
    else
    {
        $result = $result | select @{name="ServerName";expression={"$s"}},@{name="Job Status";expression={"Bits copy failed."}}
        return $result
    }
}

""
"Job Result:"
$WSUSJob | out-string | write-host
$failedjob= $WSUSJob | ? {$_.("Job Status") -notmatch "powershell started on"}
"Pay attention to the failed jobs below:" | out-string | write-host -foregroundcolor Red
if (($failedjob |out-string ) -notlike $null)
{
    $failedjob | out-string | write-host -foregroundcolor Red
}
else
{
    "No failed jobs." | write-host -foregroundcolor Green
}

write-host "failed to connect servers"
$failedServers
