﻿#Script workflow
#Step-1:Verity the patching result 
#Step-2:Base on the patching result, find out servers that need reboot, reboot them
#Step-3:Auto Re-patch those rebooted servers, and then repeat step1-3 until all servers patch successfully


param([string]$serverlist)

do {

###############################Step-1:Patching Result validation#####################################

[array]$allservers=gc $serverlist


[array]$goodservers=$null
[array]$badservers=$null


#filter the reachable&unreachable severs
foreach($s in $allservers)
{
   if(Test-Path \\$s\c$ -ErrorAction SilentlyContinue)
    {$goodservers+=$s}
   else
    { $badservers+=$s  }
    
 }
 

[array]$PatchingResult=$null
foreach($server in $goodservers)
{ 
  $latestFolder=$null
  $Returncode=$null
  $writetime=$null
  $OSVersion=$null

  $OSVersion=icm -computername $server -ScriptBlock {
  $OSinfo=gwmi -Class win32_operatingsystem
  $os=$osinfo | Select-Object -ExpandProperty caption
  $OS
  }


  
  $latestFolder=dir \\$server\c$\wsuslog | Sort-Object LastWriteTime -Descending | Select-Object -First 1 | select -ExpandProperty name
  if(Test-Path "\\$server\c$\wsuslog\$latestFolder\ResultCode")
  { 
  $Returncode=gc "\\$server\c$\wsuslog\$latestFolder\ResultCode"
  $writetime=(dir  \\$server\c$\wsuslog\$latestFolder\ResultCode | select -ExpandProperty  Lastwritetime).tostring("yyyyMMdd-hh:mm:ss")
  }
  else
  {
   $Returncode="Ongoing"
   $writetime="Ongoing"
    }
  

  switch ($Returncode)
  {
      '0' {$result="SuccessNoNeedReboot"}
      '1' {$result="SuccessNeedReboot"}
      '2' {$result="PatialSuccessNoNeedReboot, not all updates are installed"}
      '3' {$result="PatialSuccessNeedReboot, not all updates are installed"}
      '4' {$result="NeedRebootBeforePatch"}
      '5' {$result="NoConnectToServer"}
      '6' {$result="NoUpdatesFound"}
      '7' {$result="InstallFailed, updates are found, but none of them is installed"}
      '8' {$result="NoInstall, user specify ListOnly or DownloadOnly"}
      '9' {$result="Exception occurred polling WSUS server"}
      "Ongoing"   {$result="Ongoing"}
       
     
  }

  #output the result
  "$server;$OSVersion;$result;$writetime"
   $temp="$server;$OSVersion;$result;$writetime"
   $PatchingResult+=$temp
  
}
Write-Host `n

#out the all Result
"=======Output Result=============="
$PatchingResult

#save result to Desktop\PatchResult.txt
$PatchingResult | Out-File $home\desktop\PatchResult.txt
Write-Host "Patching Result was dropped on your desktop\patchresult.txt"  -ForegroundColor Green

Write-Host `n
#output the unreachable servers
if($badservers)
{
 Write-Warning "==Below Unreachable Servers were dropped on Desktop\unReachable.txt,please manually check them=========="
 $badservers | Out-File $home\desktop\unReachable.txt
 $badservers
 write-host "**************************"  -ForegroundColor Green
 Write-Host `n
 Write-Host `n
 Write-Host `n
}


###############################Step-2:Reboot Servers#####################################

#Analyse the patching result log
[array]$NeedRebootServers=$null
[array]$ongoingServers=$null
foreach($line in $PatchingResult)
{
    
    if ( ($line -notlike "*SuccessNoNeedReboot*") -and ($line -notlike "*NoUpdatesFound*") -and ($line -notlike "*Ongoing*") )
      {        
           $NeedReboot=$line.split(";")[0]
           $RebootReason=$line.split(";")[2]
           "$NeedReboot;$RebootReason"
           $NeedRebootServers+=$NeedReboot
       }

    if ($line -like "*Ongoing*")
    {
        $ongoingServers+=$line.split(";")[0]    
    }


}

if($NeedRebootServers)
{
  #output the Need reboot servers to NeedReboot.txt
  $NeedRebootServers | Out-File $home\desktop\needreboot.txt



Write-Host "Above servers need reboot" -ForegroundColor Green
Write-Host `n
write-host `n


#output need reboot servers in console
Write-Host "We are going to reboot below servers" -ForegroundColor Green
$NeedRebootServers
Write-Host `n
write-host `n

Write-Host "*******Rebooting*************"  -ForegroundColor Green
#going to reboot and sleep for 8 minutes
icm -ComputerName $NeedRebootServers -ScriptBlock {
"$env:computername is rebooting"
Restart-Computer -force
}


#sleeping for 8 minutes
Write-Host "Waiting server reboot for 8 minuets" -ForegroundColor Green
Start-Sleep -Seconds 480


}

###################################Step-3:Repatch those rebooted Servers#################################

foreach($rebootedserver in $NeedRebootServers)
  {
      $WSUSjob=$null
      $WSUSjob= psexec /accepteula -d -s -h \\$rebootedserver powershell -ExecutionPolicy Bypass -File "\\$rebootedserver\C$\temp\AutoPatching.ps1" 2>&1 | Out-String

      if ($WSUSjob -match "started on $rebootedserver with process ID")
        {
            $JobString= $WSUSjob |findstr "ID"
            "$rebootedserver;$JobString"            
        }
        else
        {
           "$rebootedserver;job sent failure" 
        }
             
    }


if(($ongoingServers -eq $null) -and ($NeedRebootServers -eq $null) )
{$flag=$true}
else
{  
  #sleeping 3 minutes for reboot servers patching
  Write-Host "sleeping 3 minuets, then verify the patching result again" -ForegroundColor Green
  Start-Sleep -Seconds 180

  $flag=$false
}


}until($flag)
   

write-host "Patching is completed" -ForegroundColor Green
















