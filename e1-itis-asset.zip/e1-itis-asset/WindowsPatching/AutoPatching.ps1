# This script generates logs and return code in C:\wsuslog\
# Return Codes:
# 0 - SuccessNoNeedReboot
# 1 - SuccessNeedReboot
# 2 - PatialSuccessNoNeedReboot, not all updates are installed
# 3 - PatialSuccessNeedReboot, not all updates are installed
# 4 - NeedRebootBeforePatch
# 5 - NoConnectToServer
# 6 - NoUpdatesFound
# 7 - InstallFailed, updates are found, but none of them is installed
# 8 - NoInstall, user specify ListOnly or DownloadOnly
# 9 - Exception occurred polling WSUS server

# Usage 1: Install all available updates
# AutoPatching.ps1

# Usage 2: Install updates specified by KB number
# AutoPatching.ps1 -ONLYQFE KB3115257
# AutoPatching.ps1 -ONLYQFE {KB3115257 KB313463}

# Usage 3: Install KB specified updates and mandatory updates
# AutoPatching.ps1 -QFE {KB3115257 KB313463}

# Usage 4: Install without KB specified updates
# AutoPatching.ps1 -NOQFE KB3115257
# AutoPatching.ps1 -NOQFE {KB3115257 KB313463}

# Usage 5: Install updates update to release
# AutoPatching.ps1 -UTR 201112

# Usage 6: Install updates except SQL Server
# AutoPatching.ps1 -NOSQL

# Usage 7: List updates without download and install
# AutoPatching.ps1 -ListOnly

# Usage 8: Download updates without install
# AutoPatching.ps1 -DownloadOnly

# Usage 9: Install updates, if reboot is required after installation, auto reboot.
# AutoPatching.ps1 -AutoReboot


[CmdletBinding()]
Param
(
    #Mode options
    [Switch]$ListOnly,
    [Switch]$DownloadOnly,
    [Switch]$AutoReboot,

    #Patch options
    #Installs ONLY user supplied QFE(s)
    [String[]]$ONLYQFE,
    #Installs mandatory and user supplied QFEs
    [String[]]$QFE,
    #Installs without user supplied QFEs
    [String[]]$NOQFE,
    #Up to Release - Will only install QFE's up to and including the release date provided
    #Ex: 201112, 201602
    [String]$UTR,
    #Skip SQL QFEs
    [Switch]$NOSQL
)


#Global and const variables

$script:needReboot = $false
$script:curFoler = "C:\wsuslog\" + (Get-Date -f yyyyMMddHHmmss) + "\"
$script:logFile = $script:curFoler + "wsus.log"
$script:resultCodeFile = $script:curFoler + "ResultCode"
$script:logError = "Error"
$script:logTrace = "Trace"
$script:logWarning = "Warning"
$script:logException = "Exception"
$script:sqlServerFilter = "SQL Server"
$script:noneOrDefault = "N/A"
$script:noPermit = "You have no permission to perform this script."
$script:prepareEnv = "Prepare environment"
$script:checkReboot = "Check reboot status only for local instance"
$script:needRebooBeforePatch = "Reboot is required to continue"
$script:supportLocal = "Support local instance only, Continue..."
$script:getUpdates = "Get available updates"
$script:connectServer = "Connecting to server..."
$script:noConnect = "Probably you don't have connection to Windows Update server"
$script:noUpdates = "No updates found"
$script:prefoundUpdates = "Found [{0}] Updates:"
$script:updateInfo = 
"
       ----------------------------------------------------------------------------------------`n
       KBArticleID: {0}`n
       Title: {1}`n
       Description: {2}`n
       IsMandatory: {3}`n
       Type: {4}`n
       Size: {5}`n
       LastDeploymentChangeTime: {6}`n
       ----------------------------------------------------------------------------------------"
$script:argInfo = "Arg {0} is set to: {1}"
$script:updateNotApproved = "Exclude the update from candidates:`n" + $script:updateInfo
$script:argUTRInvalid = "UTR is invalid, ignore"
$script:taskNotPermitted = "Your security policy don't allow a non-administator identity to perform this task"
$script:startDownloading = "Downloading update: {0}"
$script:updateDownloaded = "Successfully downloaded update: {0}"
$script:updateDownloadFailed = "Failed to download update: {0}"
$script:startInstalling = "Installing update: {0}"
$script:installResultInfo = 
"
       Install Result:
       ----------------------------------------------------------------------------------------`n
       Update: {0}`n
       Status: {1}`n
       RequireReboot: {2}`n
       ----------------------------------------------------------------------------------------"
$script:rebooting = "Rebooting server..."
$script:manuallyReboot = "Reboot is required. Please do it manually."
$script:resultSummary =
"
       ----------------------------------------------------------------------------------------`n
       Result Summary: {0} updates found, {1} updates installed.`n
         ----------------------------------------------------------------------------------------"
#Result code
$script:resultCodeSuccessNoNeedReboot = "0"
$script:resultCodeSuccessNeedReboot = "1"
$script:resultCodePatialSuccessNoNeedReboot = "2"
$script:resultCodePatialSuccessNeedReboot = "3"
$script:resultCodeNeedRebootBeforePatch = "4"
$script:resultCodeNoConnectToServer = "5"
$script:resultCodeNoUpdatesFound = "6"
$script:resultCodeInstallFailed = "7"
$script:resultCodeNoInstall = "8"
$script:resultCodeExceptionOccurred = "9"

Function Write-Log
{
    param
    (
        [parameter(Mandatory=$true)]
        [string]$level,
        [parameter(Mandatory=$true)]
        [String]$content
    )
    #incase logfile gets deleted
    if(!(Test-Path $script:logFile))
    {
        New-Item $script:logFile -ItemType File -Force
    }
    $content += Get-Date -f " yyyy-MM-dd HH:mm:ss"
    switch ($level) 
    { 
        $script:logError {Write-Error $content}
        $script:logWarning {Write-Warning $content}
        $script:logTrace {Write-Verbose $content}
        $script:logException {Write-Error $content}
        default {Write-Verbose $content}
    }
    ([String]$level + ": " + $content) | Add-Content $script:logFile
}

Function Write-ResultCode
{
    param
    (
        [parameter(Mandatory=$true)]
        [string]$resultCode,
        [switch]$noexit
    )
    if(!(Test-Path $script:resultCodeFile))
    {
        New-Item $script:resultCodeFile -ItemType File -Force
    }
    $resultCode | Set-Content $script:resultCodeFile
    if(!$noexit)
    {
        exit
    }
}

Function Is-Admin
{
    [OutputType('Bool')]
    param()
    $User = [Security.Principal.WindowsIdentity]::GetCurrent()
    $IsAdmin = (New-Object Security.Principal.WindowsPrincipal $user).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
    return $IsAdmin
}

Function Prepare-Environment
{
    param()
    Write-Log $script:logTrace $script:prepareEnv
    Write-Log $script:logTrace $script:checkReboot
    Try
    {
        $objSystemInfo = New-Object -ComObject "Microsoft.Update.SystemInfo"
        If($objSystemInfo.RebootRequired)
        {
            Write-Log $script:logError $script:needRebooBeforePatch
            Write-ResultCode $script:resultCodeNeedRebootBeforePatch
        }
    }
    Catch
    {        
        Write-Log $script:logWarning $script:supportLocal
    }
}

Function Is-Sql
{
    [OutputType('Bool')]
    Param
    (
        [AllowNull()]
        $update
    )
    $IsSql = $false
    if($update.Title -match $script:sqlServerFilter)
    {
        $IsSql = $true
    }
    else
    {
        foreach($category in $update.Categories)
        {
            if(($category.Type -eq "ProductFamily") -and ($category.name -match $script:sqlServerFilter))
            {
                $IsSql = $true
                break
            }

            if($category.Type -eq "Product")
            {
                if(($category.Parent.Type -eq "ProductFamily") -and ($category.Parent.name -match $script:sqlServerFilter))
                {
                    $IsSql = $true
                    break
                }
            }
        }
    }
    return $IsSql
}

Function Match-KB
{
    [OutputType('Bool')]
    Param
    (
        [AllowNull()]
        $inputKBs,
        [AllowNull()]
        $updateKBs
    )
    $isMatched = $false
    #if no KB specified, all updates are good to go
    If($inputKBs -eq $null -or $inputKBs -eq "" -or $inputKBs.count -le 0)
    {
        $isMatched = $true
    }
    else
    {
        foreach($inputKB in $inputKBs)
        {
            foreach($updateKB in $updateKBs)
            {
                #if one KB is matched, return true
                if($inputKB -match $updateKB)
                {
                    $isMatched = $true
                    break
                }
            }
        }
    }
    return $isMatched
}

Function Get-Updates
{
    [OutputType('Microsoft.Update.UpdateColl')]
    Param()
    Write-Log $script:logTrace $script:getUpdates
    Write-Log $script:logTrace $script:connectServer
    try
    {
        $session = New-Object -ComObject "Microsoft.Update.Session"
        $searcher = $session.CreateUpdateSearcher()
        #Generate search conditions
        $conditions = [String]::Empty
        #Search
        $result = $searcher.Search($conditions)
        if(($result -eq $null) -or ([int]($result.Updates.count) -eq 0))
        {
            Write-log $script:logWarning $script:noUpdates
            Write-ResultCode $script:resultCodeNoUpdatesFound
        }
        $updateCandidates = New-Object -ComObject "Microsoft.Update.UpdateColl"
        $UpdatesExtraDataCollection = @{}
        Foreach($Update in $result.Updates)
        {
            $KB = [String]::Empty
            If(($Update.KBArticleIDs -ne "") -and ($Update.KBArticleIDs -ne $null) -and ($Update.KBArticleIDs -gt 0))
            {
                $KBCollection = @()
                foreach($KBArticleID in $Update.KBArticleIDs)
                {
                    $KBCollection += "KB" + $KBArticleID
                }
                $KB = [String]::Join(", ", $KBCollection)
            }
            Else
            {
                $KB = $script:noneOrDefault
            }   
            $type = "Unknown"
            if($Update.Type -eq 1)
            {
                $type = "Software"
            }
            if($Update.Type -eq 2)
            {
                $type = "Driver"
            }
            $size = [String]::Empty
            Switch($Update.MaxDownloadSize)
            {
                {[System.Math]::Round($_/1KB,0) -lt 1024} { $size = [String]([System.Math]::Round($_/1KB,0))+" KB"; break }
                {[System.Math]::Round($_/1MB,0) -lt 1024} { $size = [String]([System.Math]::Round($_/1MB,0))+" MB"; break }  
                {[System.Math]::Round($_/1GB,0) -lt 1024} { $size = [String]([System.Math]::Round($_/1GB,0))+" GB"; break }    
                {[System.Math]::Round($_/1TB,0) -lt 1024} { $size = [String]([System.Math]::Round($_/1TB,0))+" TB"; break }
                default { $size = "Unknown" }
            }
            #Filter updates via command args
            $UpdateApproved = $true
            If($ONLYQFE -ne $null)
            {                
                if(!(($KB -ne $script:noneOrDefault) -and (Match-KB $ONLYQFE $Update.KBArticleIDs)))
                {
                    $UpdateApproved = $false
                    Write-Log $script:logTrace ([String]::Format($script:argInfo,"ONLYQFE", ([String]::Join(",", $ONLYQFE))))
                }
            }
            else #ONLYQFE is exclusive from other args
            {
                If($QFE -ne $null)
                {                    
                    If(!($Update.IsMandatory) -and !(($KB -ne $script:noneOrDefault) -and (Match-KB $QFE $Update.KBArticleIDs)))
                    {
                        $UpdateApproved = $false
                        Write-Log $script:logTrace ([String]::Format($script:argInfo, "QFE", ([String]::Join(",", $QFE))))
                    }
                }
                If(($UTR -ne "") -and ($UTR -ne $null) -and ($UpdateApproved -eq $true))
                {
                    try
                    {
                        if($Update.LastDeploymentChangeTime -ne "")
                        {
                            $inputTime = [Datetime]::ParseExact($UTR, "yyyyMM", $null)
                            if(($Update.LastDeploymentChangeTime.year -gt $inputTime.year) -or
                               (($Update.LastDeploymentChangeTime.year -eq $inputTime.year) -and ($Update.LastDeploymentChangeTime.month -gt $inputTime.month)))
                               {
                                    $UpdateApproved = $false
                                    Write-Log $script:logTrace ([String]::Format($script:argInfo, "UTR", $UTR))
                               }
                        }
                    }
                    catch
                    {
                        Write-Warning $script:logTrace $script:argUTRInvalid
                        Write-Log $script:logException $_
                    }
                }
                If($NOSQL -and ($UpdateApproved -eq $true))
                {
                    #If this update relates to sql server, ignore it
                    if(Is-Sql($Update))
                    {
                        $UpdateApproved = $false
                        Write-Log $script:logTrace ([String]::Format($script:argInfo, "NOSQL", $NOSQL))
                    }
                }
            }
            #Exclude updates from $NOQFE
            if(($NOQFE -ne $null) -and ($updateApproved -eq $true))
            {                
                if(($KB -ne $script:noneOrDefault) -and (Match-KB $NOQFE $Update.KBArticleIDs))
                {
                    $UpdateApproved = $false
                    Write-Log $script:logTrace ([String]::Format($script:argInfo,"NOQFE", ([String]::Join(",", $NOQFE))))
                }
            }
            #Add approved update to candidate
            if($updateApproved -eq $true)
            {
                $updateCandidates.Add($Update) | Out-Null
                $UpdatesExtraDataCollection.Add($Update.Identity.UpdateID,@{KB = $KB; Type = $type; Size = $size})
            }
            else
            {
                Write-Log $script:logTrace ([String]::Format($script:updateNotApproved, 
                                                            $KB,
                                                            $Update.Title, 
                                                            $Update.Description, 
                                                            [String]$Update.IsMandatory, 
                                                            $type,
                                                            $size,
                                                            $Update.LastDeploymentChangeTime))
            }
        }
        $updateInfos = [string]::Empty
        Foreach($Update in $updateCandidates)
        {
            $updateInfos += ([String]::Format($script:updateInfo, 
                                              $UpdatesExtraDataCollection[$Update.Identity.UpdateID].KB, 
                                              $Update.Title, 
                                              $Update.Description, 
                                              [String]$Update.IsMandatory, 
                                              $UpdatesExtraDataCollection[$Update.Identity.UpdateID].Type, 
                                              $UpdatesExtraDataCollection[$Update.Identity.UpdateID].Size, 
                                              $Update.LastDeploymentChangeTime))
        }
        Write-Log $script:logTrace (([String]::Format($script:prefoundUpdates, $updateCandidates.count)) + $updateInfos)
        return $updateCandidates
    }
    Catch
    {
        If($_ -match "HRESULT: 0x80072EE2")
        {
            Write-Log $script:logError $script:noConnect
            write-log $script:logException $_
            Write-ResultCode $script:resultCodeNoConnectToServer
        }
        Write-Log $script:logException $_
        Write-ResultCode $script:resultCodeExceptionOccurred
    }
}

Function Download-Updates
{
    Param
    (
        [AllowNull()]
        $updatesToDownload
    )
    Try
    {
        if(($updatesToDownload -eq $null) -or ($updatesToDownload -eq ""))
        {
            return $null
        }
        $session = New-Object -ComObject "Microsoft.Update.Session"
        $updatesDownloaded = New-Object -ComObject "Microsoft.Update.UpdateColl"
        Foreach($Update in $updatesToDownload)
        {
            Write-Log $script:logTrace ([String]::Format($script:startDownloading, $Update.Title))
            $downloader = $session.CreateUpdateDownloader()
            $objCollectionTmp = New-Object -ComObject "Microsoft.Update.UpdateColl"
            $objCollectionTmp.Add($Update) | Out-Null
            $downloader.Updates = $objCollectionTmp
            $downloadResult = $downloader.Download()
            If($downloadResult.ResultCode -eq 2)
            {
                Write-Log $script:logTrace ([String]::Format($script:updateDownloaded, $Update.Title))
                $updatesDownloaded.Add($Update) | Out-Null
            }
            else
            {
                Write-Log $script:logWarning ([String]::Format($script:updateDownloadFailed, $Update.Title))
            }
        }
        return $updatesDownloaded
    }
    Catch
    {
        If($_ -match "HRESULT: 0x80240044")
        {
            write-log $script:logWarning $script:taskNotPermitted
        }
        write-log $script:logException $_
        Write-ResultCode $script:resultCodeExceptionOccurred
    }
}

Function Install-Updates
{
    Param
    (
        [AllowNull()]
        $updatesToInstall
    )
    Try
    {
        if(($updatesToInstall -eq $null) -or ($updatesToInstall -eq ""))
        {
            return $null
        }
        $session = New-Object -ComObject "Microsoft.Update.Session"
        $updatesInstalled = New-Object -ComObject "Microsoft.Update.UpdateColl"
        $curIndex = 0
        Foreach($Update in $updatesToInstall)
        {
            Write-Log $script:logTrace ([String]::Format($script:startInstalling, $Update.Title))
            $installer = $session.CreateUpdateInstaller()
            $objCollectionTmp = New-Object -ComObject "Microsoft.Update.UpdateColl"
            $objCollectionTmp.Add($Update) | Out-Null
            $installer.Updates = $objCollectionTmp
            $installResult = $installer.Install()
            if(!$script:needReboot)
            {
                $script:needReboot = $installResult.RebootRequired  
            }
            $Status = "Unknown"
            Switch -exact ($installResult.ResultCode)
            {
                0   { $Status = "NotStarted"}
                1   { $Status = "InProgress"}
                2   { $Status = "Installed"}
                3   { $Status = "InstalledWithErrors"}
                4   { $Status = "Failed"}
                5   { $Status = "Aborted"}
            }
            Write-Log $script:logTrace ([String]::Format($script:installResultInfo, $Update.Title, $Status, [String]($installResult.RebootRequired)))
            if($installResult.ResultCode -eq 2)
            {
                $updatesInstalled.Add($Update) | Out-Null
            }
        }
        return $updatesInstalled
    }
    Catch
    {
        If($_ -match "HRESULT: 0x80240044")
        {
            write-log $script:logWarning $script:taskNotPermitted
        }
        write-log $script:logException $_
        Write-ResultCode $script:resultCodeExceptionOccurred
    }
}

Function Handle-ResultCode
{
    Param
    (
        [AllowNull()]
        $searchedCount,
        [AllowNull()]
        $installedCount
    )
    Write-Log $script:logTrace ([String]::Format($script:resultSummary, [String]$searchedCount, [String]$installedCount))
    if($searchedCount -le 0)
    {
        Write-ResultCode $script:resultCodeNoUpdatesFound -noexit
    }
    else
    {
        if($installedCount -le 0)
        {
            Write-ResultCode $script:resultCodeInstallFailed -noexit
        }
        else
        {
            if($installedCount -eq $searchedCount)
            {
                if($script:needReboot)
                {
                    Write-ResultCode $script:resultCodeSuccessNeedReboot -noexit
                }
                else
                {
                    Write-ResultCode $script:resultCodeSuccessNoNeedReboot -noexit
                }
            }
            elseif($installedCount -lt $searchedCount)
            {
                if($script:needReboot)
                {
                    Write-ResultCode $script:resultCodePatialSuccessNeedReboot -noexit
                }
                else
                {
                    Write-ResultCode $script:resultCodePatialSuccessNoNeedReboot -noexit
                }
            }
        }
    }
}

Function Handle-Reboot
{
    If($script:needReboot)
    {
        If($AutoReboot)
        {
            Write-Log $script:logTrace ([String]::Format($script:argInfo, "AutoReboot", [String]$AutoReboot))
            Write-Log $script:logTrace $script:rebooting
            Restart-Computer -Force
        }
        else
        {
            Write-Log $script:logTrace $script:manuallyReboot
        }
    }
}

#Check if user is admin to run this script
if(!(Is-Admin))
{
    Write-Log $script:logError $script:noPermit
    Write-ResultCode $script:resultCodeInstallFailed
}

#Prepare environment
Prepare-Environment

#Search and filter updates
$searchedUpdateColl = Get-Updates
if($ListOnly)
{

    Write-ResultCode $script:resultCodeNoInstall
}

#Download updates
$downloadedUpdateColl = (Download-Updates $searchedUpdateColl)
if($DownloadOnly)
{
    Write-ResultCode $script:resultCodeNoInstall
}

#Install updates
$installedUpdateColl = (Install-Updates $downloadedUpdateColl)

#Handle result code
$sCount = 0
$iCount = 0
if(($searchedUpdateColl -ne $null) -and ($searchedUpdateColl -ne $null))
{
    if(($searchedUpdateColl.count -gt 0))
    {
        $sCount = $searchedUpdateColl.count
    }
    else
    {
        $sCount = 1
    }
}
if(($installedUpdateColl -ne $null) -and ($installedUpdateColl -ne $null))
{
    if(($searchedUpdateColl.count -gt 0))
    {
        $iCount = $installedUpdateColl.count
    }
    else
    {
        $iCount = 1
    }
}
Handle-ResultCode $sCount $iCount

#Handle reboot
Handle-Reboot
