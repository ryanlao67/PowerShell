﻿#This script is only used for patching result checking, none reboot and patch action.
#Parameter $serverlist is required when you are going to run this script.

param([string]$serverlist)
$allservers=gc $serverlist

[array]$goodservers=$null
[array]$badservers=$null


#filter the reachable&unreachable severs
foreach($s in $allservers)
{
   if(Test-Path \\$s\c$ -ErrorAction SilentlyContinue)
    {$goodservers+=$s}
   else
    { $badservers+=$s  }
    
 }
 

[array]$allResult=$null
foreach($server in $goodservers)
{ 
  $latestFolder=$null
  $Returncode=$null
  $writetime=$null
  $OSVersion=$null

  $OSVersion=icm -computername $server -ScriptBlock {
  $OSinfo=gwmi -Class win32_operatingsystem
  $os=$osinfo | Select-Object -ExpandProperty caption
  $OS
  }


  
  $latestFolder=dir \\$server\c$\wsuslog | Sort-Object LastWriteTime -Descending | Select-Object -First 1 | select -ExpandProperty name
  if(Test-Path "\\$server\c$\wsuslog\$latestFolder\ResultCode")
  { 
  $Returncode=gc "\\$server\c$\wsuslog\$latestFolder\ResultCode"
  $writetime=(dir  \\$server\c$\wsuslog\$latestFolder\ResultCode | select -ExpandProperty  Lastwritetime).tostring("yyyyMMdd-hh:mm:ss")
  }
  else
  {
   $Returncode="Ongoing"
   $writetime="Ongoing"
    }
  

  switch ($Returncode)
  {
      '0' {$result="SuccessNoNeedReboot"}
      '1' {$result="SuccessNeedReboot"}
      '2' {$result="PatialSuccessNoNeedReboot, not all updates are installed"}
      '3' {$result="PatialSuccessNeedReboot, not all updates are installed"}
      '4' {$result="NeedRebootBeforePatch"}
      '5' {$result="NoConnectToServer"}
      '6' {$result="NoUpdatesFound"}
      '7' {$result="InstallFailed, updates are found, but none of them is installed"}
      '8' {$result="NoInstall, user specify ListOnly or DownloadOnly"}
      '9' {$result="Exception occurred polling WSUS server"}
      "Ongoing"   {$result="Ongoing"}
       
     
  }

  #output the result
  "$server;$OSVersion;$result;$writetime"
   $temp="$server;$OSVersion;$result;$writetime"
   $allResult+=$temp
  
}
Write-Host `n

#out the all Result
"=======Output Result=============="
$allResult

#save result to Desktop\PatchResult.txt
$allResult | Out-File $home\desktop\PatchResult.txt
Write-Host "Patching Result was dropped on your desktop\patchresult.txt"  -ForegroundColor Green

Write-Host `n
#output the unreachable servers
if($badservers)
{
 Write-Warning "==Below Unreachable Servers were dropped on Desktop\unReachable.txt,please manually check them=========="
 $badservers | Out-File $home\desktop\unReachable.txt
 $badservers
 
}
