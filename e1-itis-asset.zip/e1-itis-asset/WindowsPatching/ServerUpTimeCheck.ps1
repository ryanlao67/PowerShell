﻿#Sometimes the server may not reboot successfully after we send the reboot command, to be ensure the server was really rebooted and up, we can use this script for checking.

param(
[string]$ServerNameORServerlist=""
)

if($ServerNameORServerlist -like "*txt*"){[array]$serverlist=gc $ServerNameORServerlist}
else{[array]$serverlist=$ServerNameORServerlist}



[array]$FailedServers=$null
[array]$Results=$null

foreach($server in $serverlist)
 {
   Try{ 
        $tempresult=$null
        $tempresult=icm -ComputerName $server -ScriptBlock {

        $LastBootUpTime = Get-WmiObject Win32_OperatingSystem | Select -ExpandProperty LastBootUpTime
        $date=[System.Management.ManagementDateTimeConverter]::ToDateTime($LastBootUpTime)

        $time=(Get-Date) - $date
        $hours=$time.hours
        $mins=$time.minutes
        $second=$time.seconds
        $uptime="$hours hours,$mins mins,$second seconds"
        $psobject=New-Object psobject
        $psobject|Add-Member noteproperty "ServerName"      $env:computername
        $psobject|Add-Member noteproperty "LastRebootTime"  $date  
        $psobject|Add-Member noteproperty "Uptime"          $uptime
        $psobject 
        
        } -ErrorAction Stop
       }
   Catch{[array]$FailedServers+=$server}

    $tempresult
    $Results+=$tempresult

  }

  if($FailedServers)
  {
  Write-Warning "Below Server are failed to connected"
  $FailedServers
  }


  Write-Host "********Server Up Time**********" -ForegroundColor Green
  $Results | ft