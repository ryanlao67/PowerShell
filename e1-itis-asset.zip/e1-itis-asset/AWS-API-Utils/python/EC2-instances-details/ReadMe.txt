#this script need aws configure file
#~/.aws/credentials
#[awscn]
#aws_access_key_id=XXXXXXXXXXXXXXXXXXXXXXX
#aws_secret_access_key=XXXXXXXXXXXXXXXXXXXXXXXXXXX
#[awssg]
#aws_access_key_id=XXXXXXXXXXXXXXXXXXXXXX
#aws_secret_access_key=XXXXXXXXXXXXXXXXXXXXXXXXXX

