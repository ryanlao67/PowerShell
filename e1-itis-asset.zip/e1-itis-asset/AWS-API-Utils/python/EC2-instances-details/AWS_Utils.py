
import boto3
import json
import sys

from botocore.exceptions import ClientError
from collections import defaultdict

#connect to AWS bj
cn_session = boto3.Session(profile_name='awscn', region_name='cn-north-1')
cn_ec2_resource = cn_session.resource('ec2')
cn_ec2_client = cn_session.client('ec2')
cn_ec2_instances = cn_ec2_resource.instances.all()

#connect to AWS sg
sg_session = boto3.Session(profile_name='awssg', region_name='ap-southeast-1')
sg_ec2_resource = sg_session.resource('ec2')
sg_ec2_client = sg_session.client('ec2')
sg_ec2_instances = sg_ec2_resource.instances.all()

def get_instance_information(cn_ec2_instances, ec2_client):
    ec2_info = {}
    for instance in cn_ec2_instances:
        ec2_info[instance.id] = {
            'Status': instance.state['Name'],
            'Platform': instance.platform,
            'Type': instance.instance_type,
            'Private IP': instance.private_ip_address,
            'Public IP': instance.public_ip_address,
            'SecurityGroup': instance.security_groups,
            #'Ports': get_security_groups_ports(cn_ec2_client.describe_security_groups(GroupIds=get_security_group_ids(instance)))
            'SecurityGroupDetails': get_security_groups_ports(ec2_client.describe_security_groups(GroupIds=get_security_group_ids(instance)))
        }

        for tag in instance.tags:
            if 'ENV' in tag['Key']:
                ec2_info[instance.id]['ENV'] = tag['Value']
            if 'Name' in tag['Key']:
                ec2_info[instance.id]['EC2Name'] = tag['Value']
            if 'TEAM' in tag['Key']:
                ec2_info[instance.id]['TEAM'] = tag['Value']
            if 'PURPOSE' in tag['Key']:
                ec2_info[instance.id]['PURPOSE'] = tag['Value']


    json_file = json.dumps(ec2_info)
    print(json_file)


def get_security_group_ids(instance):
    return [group['GroupId'] for group in instance.security_groups]


def get_security_groups_ports(security_groups):
    result = [{"GroupName": group['GroupName'], 'Ips': group['IpPermissions']} for group in security_groups['SecurityGroups']]
    return result


def dumps_json(json_object):
    return json.dumps(json_object)

get_instance_information(cn_ec2_instances, cn_ec2_client)
get_instance_information(sg_ec2_instances, sg_ec2_client)


