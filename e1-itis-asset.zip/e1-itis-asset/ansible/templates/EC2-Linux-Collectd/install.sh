#/bin/sh
sudo apt-get update
sudo apt-get install -y collectd
sudo ./setup.py
sudo cp collectd-cloudwatch.conf /etc/collectd/collectd.conf.d/
sudo cp collectd.conf /etc/collectd/
sudo cp processes-squid.conf /etc/collectd/collectd.conf.d/
sudo cp whitelist.conf /opt/collectd-plugins/cloudwatch/config/
sudo /etc/init.d/collectd restart
