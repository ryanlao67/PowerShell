from base64 import b64decode
from json import loads, dumps
from zlib import compress, decompress, MAX_WBITS
import urllib2

ES_VPCFLOW_LOG_URL = 'http://10.160.131.78:9200/default-vpc-flowlog/log/'

def lambda_handler(event, context):
    # TODO implement
    data = event.get('awslogs', {}).get('data')
    
    if not data:
        return
    records = loads(decompress(b64decode(data), 16 + MAX_WBITS))
    messages = []
    for log_event in records['logEvents']:
        messages.append("%s %s" % (log_event['timestamp'], log_event['message']))    
    
    for message in messages:
        post_msg_to_es(parse_flowlog_to_dic(message))
    return True

def parse_flowlog_to_dic(message):
    keys = "id version account-id interface-id srcaddr dstaddr srcport dstport protocol packets bytes start end action log-status".split()
    msgs = message.split()
    maps = {}
    for i in range(4,len(keys)):
        maps[keys[i]]=msgs[i]
    return maps

def post_msg_to_es(msg):
    print msg
    req = urllib2.Request(ES_VPCFLOW_LOG_URL)
    req.add_header('Content-Type', 'application/json')
    response = urllib2.urlopen(req, dumps(msg))
    print response