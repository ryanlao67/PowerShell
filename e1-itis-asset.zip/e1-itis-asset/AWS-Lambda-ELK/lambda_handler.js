const AWS = require('aws-sdk');
const http = require('https');
const zlib = require('zlib');

const esConfig = {
   hostName: process.env.esHost,
   hostPort: process.env.esPort,
   logIndex: process.env.logIndex
};
   
exports.handler = (event, context, callback) => {
   const payload = new Buffer(event.awslogs.data, 'base64');
   function parseEvent(logEvent, logGroupName, logStreamName) {
      var theMessage = logEvent.message.substring(0, logEvent.message.length - 1);
 
      var msgArr = theMessage.split(" ");
            return {
               message: theMessage,
               srcaddr: msgArr[3],
               dstaddr: msgArr[4],
               srcport: parseInt(msgArr[5]),
               dstport: parseInt(msgArr[6]),
               protocol: msgArr[7],
               packets: parseInt(msgArr[8]),
               bytes: parseInt(msgArr[9]),
               start: msgArr[10],
               end: msgArr[11],
               action: msgArr[12],
               logstatus: msgArr[13],
               logGroupName,
               logStreamName,
               "@timestamp": new Date(logEvent.timestamp).toISOString(),
            };
   }
 
   function postEventsToEs(parsedEvents) {
 
      const finalEvent = parsedEvents.map(JSON.stringify).join('\n');
      try {
         const options = {
            hostname: esConfig.hostName,
            port: esConfig.hostPort,
            path: `/${encodeURIComponent(esConfig.logIndex)}`,
            method: 'POST',
            headers: {
               'Content-Type': 'application/json',
               'Content-Length': finalEvent.length,
         },
      };
 
      const req = http.request(options, (res) => {
         res.on('data', (data) => {
            console.log(data);
            const result = JSON.parse(data.toString());
            if (result.response === 'ok') {
               callback(null, 'all events are sent to logzio');
            } else {
               console.log(result.response);
            }
         });

         res.on('end', () => {
            console.log('No more data in response.');
            callback();
         });
      });
 
      req.on('error', (err) => {
         console.log('problem with request:', err.toString());
         callback(err);
      });
 
      req.write(finalEvent);
      req.end();
      } 
      catch (ex) {
         console.log(ex.message);
         callback(ex.message);
      }
   }
 
   zlib.gunzip(payload, (error, result) => {
      if (error) {
         callback(error);
      } else {
         const resultParsed = JSON.parse(result.toString('ascii'));
         const parsedEvents = resultParsed.logEvents.map((logEvent) =>
            parseEvent(logEvent, resultParsed.logGroup, resultParsed.logStream));
         postEventsToEs(parsedEvents);
      }
   });
};
